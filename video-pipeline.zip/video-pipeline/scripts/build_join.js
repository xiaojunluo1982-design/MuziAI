#!/usr/bin/env node
/**
 * build_join.js —— 按 segments.json 精确拼接 + 段尾气口（通用 · 标准件）
 *
 * 【这个脚本存在的唯一理由：气口必须垫在「拼接」这一步】
 * 硬切的 joined 里，段间静音 = 0。之后再怎么调 trim_silence 的 --gap-min/--gap-max
 * 都留不出气口 —— 因为**没有静音可留**。于是段尾正好落在字尾上，字尾的收音/换气
 * 被剃掉，听起来就是「正常语气被剪了」。
 * 所以气口必须由上游 plan_cut_by_words.js 写进 segments.json
 * （seg.e = 末字终点 + 0.30~0.50s），本脚本按 seg.s/seg.e 原样 trim → concat，
 * 把气口一并带进成片。
 *
 * 🔴 本脚本会自检气口：segments 缺 gap 字段、或气口合计 ≈ 0 时直接 WARN 提示
 *    「你多半在用裸区间手写 segments」—— 把踩过的坑固化成机器检查，而不是靠人记得。
 *
 * 🔴 缩放默认**等比 + 黑边填充**（不变形）。要精确拉伸请显式加 --stretch。
 *
 * 用法：
 *   node build_join.js --in IMG_0024.MP4 --segments segments.json --out joined.mp4
 *   node build_join.js --in a.mp4 --segments s.json --out j.mp4 --scale 720:1280 --fps 30
 */
const fs = require('fs');
const path = require('path');
const { FFMPEG, run } = require('./_ff.js');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--')) {
    const k = process.argv[i].slice(2);
    args[k] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
  }
}
for (const k of ['in', 'segments', 'out']) if (!args[k]) { console.error('ERR 缺 --' + k); process.exit(2); }
if (!fs.existsSync(args['in'])) { console.error('ERR 素材不存在 ' + args['in']); process.exit(2); }

const segs = JSON.parse(fs.readFileSync(args.segments, 'utf8'));
if (!Array.isArray(segs) || !segs.length) { console.error('ERR segments 为空或不是数组'); process.exit(2); }

for (const g of segs) {
  if (typeof g.s !== 'number' || typeof g.e !== 'number' || g.e <= g.s) {
    console.error('ERR 段区间非法：' + JSON.stringify(g) + '（需要 s < e 的数字）');
    process.exit(2);
  }
}

// ── 气口自检：把「段尾垫气口」这条踩过的坑变成机器检查 ────────────────────
const missing = segs.filter((g) => typeof g.gap !== 'number').length;
const gaps = segs.slice(0, -1).map((g) => Number(g.gap) || 0);
const gapTotal = +gaps.reduce((m, x) => m + x, 0).toFixed(3);
if (missing) {
  console.warn('WARN ' + missing + ' 段缺 gap 字段 —— 你多半在用裸区间手写 segments。');
  console.warn('     裸区间的段尾落在字尾上，字尾收音/换气会被剃掉（听起来像「正常语气被剪了」）。');
  console.warn('     ✅ 请改用 plan_cut_by_words.js 生成 segments（seg.e = 末字终点 + 0.30~0.50s 气口）。');
} else if (segs.length > 1 && gapTotal < 0.05) {
  console.warn('WARN 段尾气口合计 ≈ 0：段间静音为 0，成片会像被硬切。确认是否漏了垫气口这一步。');
}

const scale = args.scale || null;
const stretch = !!args.stretch;
const fps = args.fps || null;
const crf = String(args.crf || 20);
const preset = args.preset || 'veryfast';
const n = segs.length;

const partsV = [], partsA = [], concatIn = [];
segs.forEach((g, i) => {
  partsV.push(`[0:v]trim=start=${g.s.toFixed(3)}:end=${g.e.toFixed(3)},setpts=PTS-STARTPTS[v${i}]`);
  partsA.push(`[0:a]atrim=start=${g.s.toFixed(3)}:end=${g.e.toFixed(3)},asetpts=PTS-STARTPTS[a${i}]`);
  concatIn.push(`[v${i}][a${i}]`);
});

const post = [];
if (fps) post.push('fps=' + fps);
if (scale) {
  if (stretch) {
    post.push('scale=' + scale);
  } else {
    post.push(`scale=${scale}:force_original_aspect_ratio=decrease`);
    post.push(`pad=${scale}:(ow-iw)/2:(oh-ih)/2:color=black`);
  }
}
post.push('setsar=1');

const fc = partsV.join(';') + ';' + partsA.join(';') + ';' +
  concatIn.join('') + `concat=n=${n}:v=1:a=1[vc][ac];[vc]${post.join(',')}[vout]`;

const out = path.resolve(args.out);
const cmd = [FFMPEG, '-y', '-v', 'error', '-i', args['in'],
  '-filter_complex', fc, '-map', '[vout]', '-map', '[ac]',
  '-c:v', 'libx264', '-crf', crf, '-preset', preset, '-pix_fmt', 'yuv420p',
  '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out];

const speech = segs.reduce((m, g) => m + (g.raw ? (g.raw[1] - g.raw[0]) : (g.e - g.s)), 0);
console.log(`段数 ${n}｜语音 ${speech.toFixed(2)}s + 气口 ${gapTotal.toFixed(2)}s = 预期成片 ${(speech + gapTotal).toFixed(2)}s`);
if (scale) console.log(`缩放 ${scale} ${stretch ? '(强制拉伸 — 会变形)' : '(等比 + 黑边填充 — 不变形)'}`);
console.log('执行 ffmpeg（trim + concat 一步完成）…');
const t0 = Date.now();
run(cmd[0], cmd.slice(1));
console.log(`已输出 ${out} (${(fs.statSync(out).size / 1048576).toFixed(1)} MB, ${((Date.now() - t0) / 1000).toFixed(0)}s)`);
