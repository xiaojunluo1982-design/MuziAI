#!/bin/bash
# ============================================================
# video-pipeline · 每日短视频生产流水线（账号无关，profile 驱动）
#
# 用法:
#   bash muziqi_pipeline.sh <stage> <工作目录> <内容包.json> [选项]
#
# stage:
#   check   只打印配置 + 检查素材（不提交任何任务，不扣积分）
#   part1   提交并轮询第 1 段
#   mosaic  从 part1 抽帧 + 脸部打码，生成 part2+ 的一致性参考帧
#   part23  提交并轮询第 2、3 段（带马赛克参考图）
#   build   拼接 3 段 + 烧字幕
#   cover   生成封面
#   qc      跑 preflight 素材阶段
#   all     part1 → mosaic → part23 → build → cover → qc
#
# 选项:
#   --desk      桌面俯拍机位（脸部偏下，码区下沿扩到高 45%）
#   --ss N      抽帧时间点，默认 3
#   --dry-run   只打印将要执行的命令，不真跑
#
# 归属: A 套 video-pipeline（2026-09-03 拍板：以 A 套为准，本脚本从 space-video/scripts/ 迁来）
# 规则源: 本 skill 的 profiles/<账号>.json（2026-09-04 解耦：不再跨 skill 读 space-video，
#         账号名也不再写死，用 --profile 指定，默认 muziqi）
#         读取兼容两种结构：优先 videoGeneration.fallback.*，回落 videoGeneration.*
# 已按本机已知坑修正：pwd -W 路径、动态 node 探测、dreamina 用 G:/ 路径、
#                    禁 --poll（手动 query_result）、终态判 fail、一段只提交一次
# ============================================================
set -u

# 中文输出与 python 读写统一用 UTF-8，否则 git-bash 下中文变乱码
export PYTHONIOENCODING=utf-8
export PYTHONUTF8=1
# bash → node 传中文参数坑：默认 MSYS 会把命令行转 codepage，让 node 收到 GBK 字节
# → A1 "找不到成片" 误判。强制 bash 与 node 进程都是 UTF-8。
export LC_ALL=C.UTF-8
export LANG=C.UTF-8

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -W 2>/dev/null || pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
# 2026-09-03 迁移：本脚本归 A 套 video-pipeline（执行层与校验层同处一地），
# 但规则源仍是 space-video/profiles/muziqi.json（唯一规则源，不复制分叉）
# 账号（2026-09-04 解耦）：--profile 指定，默认 muziqi；也支持环境变量 PROFILE 预设。
# CFG 的真实路径在下面参数解析完之后才拼（否则 --profile 来不及生效）。
PROFILE="${PROFILE:-muziqi}"

STAGE="${1:-check}"
WORK="${2:-}"
PKG="${3:-}"
shift 3 2>/dev/null || shift $# 2>/dev/null || true
DESK=0; SS=3; DRY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --profile) shift; PROFILE="${1:-muziqi}" ;;
    --desk) DESK=1 ;;
    --ss) shift; SS="${1:-3}" ;;
    --dry-run) DRY=1 ;;
  esac
  shift || true
done

# ---------- profile 路径（参数解析完再拼）----------
CFG="$SKILL_DIR/profiles/$PROFILE.json"

# ---------- 动态探测 node（坑：版本目录会被轮换）----------
NODE="$(command -v node 2>/dev/null || true)"
if [ -z "$NODE" ]; then
  for c in "$HOME"/.workbuddy/binaries/node/versions/*/node.exe; do
    [ -x "$c" ] && NODE="$c" && break
  done
fi
[ -z "$NODE" ] && { echo "FAIL 找不到 node"; exit 1; }

# Windows 形式的家目录（git-bash 的 $HOME 是 /c/Users/xxx，ffmpeg/字体配置要 C:/Users/xxx）
HOME_WIN="$(cd "$HOME" 2>/dev/null && pwd -W 2>/dev/null || echo "$HOME")"

PY="$(command -v python3 2>/dev/null || command -v python 2>/dev/null || true)"
[ -z "$PY" ] && { echo "FAIL 找不到 python"; exit 1; }

# ---------- 读 profile ----------
if [ ! -f "$CFG" ]; then echo "FAIL 缺 profile: $CFG"; exit 1; fi
eval "$("$PY" - "$CFG" <<'PYEOF'
import json, io, sys
d = json.load(io.open(sys.argv[1], encoding='utf-8'))
def w(s): return str(s or '').replace('\\', '/')
def g(o, k, default=''):
    x = o.get(k, default)
    return default if x is None else x
p  = d.get('paths', {})
vg = d.get('videoGeneration', {}) or {}
# 2026-09-04：兼容两种结构——优先 fallback.*（三层通道风格，resolution 是 720p 这种
# dreamina 能接受的值），回落平铺 videoGeneration.*（老结构）。换账号不用改脚本。
v  = vg.get('fallback', {}) or vg
df = d.get('defaults', {})
print('IDENT="%s"'        % w(g(p,  'identityImage')))
print('SCENE_DIR="%s"'    % w(g(p,  'sceneDir')))
print('MATERIAL_DIR="%s"' % w(g(p,  'materialDir')))
print('COVER_STYLE="%s"'  % g(df, 'coverStyle', 's7'))
print('COVER_FONT="%s"'   % g(df, 'coverFont', 'douyin'))
print('SESSION="%s"'      % g(v,  'session'))
print('MODEL="%s"'        % g(v,  'model'))
print('RATIO="%s"'        % g(v,  'ratio', '9:16'))
print('RES="%s"'          % g(v,  'resolution', '720p'))
PYEOF
)"
# 关键配置缺失要立刻报，不能静默降级（曾因 KeyError 让 ratio 为空 → 参数错）
if [ -z "${IDENT:-}" ] || [ -z "${SCENE_DIR:-}" ] || [ -z "${SESSION:-}" ] || [ -z "${MODEL:-}" ]; then
  echo "FAIL profile 关键字段缺失：IDENT/SCENE_DIR/SESSION/MODEL 不能有空。检查 $CFG"
  exit 1
fi

# ---------- 工作目录 ----------
[ -z "$WORK" ] && { echo "用法: bash muziqi_pipeline.sh <stage> <工作目录> <内容包.json> [--profile <账号>] [选项]"; exit 2; }
[ -d "$WORK" ] || { echo "FAIL 工作目录不存在: $WORK"; exit 1; }
WORK="$(cd "$WORK" && pwd -W 2>/dev/null || echo "$WORK")"
cd "$WORK" || exit 1

jget() { "$NODE" -e "try{const j=require('$1');const v=$2;console.log(v===undefined||v===null?'':v)}catch(e){console.log('')}" 2>/dev/null; }

# ---------- 从内容包读场景/标题/段数 ----------
SCENE_NAME=""; TITLE=""; SEG_N=3; DUR=15; COVER_L1=""; COVER_L2=""
if [ -n "$PKG" ] && [ -f "$PKG" ]; then
  eval "$("$PY" - "$PKG" <<'PYEOF'
import json, io, sys, re
d = json.load(io.open(sys.argv[1], encoding='utf-8'))
print('SCENE_NAME="%s"' % d.get('scene',''))
print('TITLE="%s"' % d.get('title',''))
ct = d.get('cover_title') or []
print('COVER_L1="%s"' % (ct[0] if len(ct)>0 else d.get('title','')[:8]))
print('COVER_L2="%s"' % (ct[1] if len(ct)>1 else ''))
PYEOF
)"
fi
if [ -f "$WORK/segments.json" ]; then
  SEG_N=$("$NODE" -e "try{const s=require('$WORK/segments.json');const a=Array.isArray(s)?s:(s.segments||s.list);console.log(a.length)}catch(e){console.log(3)}" 2>/dev/null)
  DUR=$("$NODE" -e "try{const s=require('$WORK/segments.json');const a=Array.isArray(s)?s:(s.segments||s.list);console.log(a[0].duration||15)}catch(e){console.log(15)}" 2>/dev/null)
fi
SCENE="$SCENE_DIR/$SCENE_NAME"
# 2026-09-07 修复：tr -d 按字节删除，全角标点的 UTF-8 尾字节会误删正文同字节汉字
# （例：，=EF BC 8C 删掉 慌=E6 85 8C 的 8C → 文件名乱码）。改用 node 按码点清洗。
OUTNAME="$("$NODE" -e "try{const j=require('$PKG');console.log(String(j.title||'').replace(/[，,。.！!？?、：:；;“”\"' ]/g,''))}catch(e){console.log('')}" 2>/dev/null)_完整版字幕_$(date +%m%d).mp4"

# ---------- 机位 → 马赛克区域 ----------
# 常规正面口播：宽 26%-74%(x=188,w=346)、高 4%-38%(y=52,h=436)
# 桌面俯拍脸更靠下：下沿扩到高 45%(h=524)
if [ "$DESK" = "1" ]; then CROP="346:524:188:52"; else CROP="346:436:188:52"; fi
CX="${CROP%%:*}"; REST="${CROP#*:}"; CY="${REST%%:*}"; REST2="${REST#*:}"; CW="${REST2%%:*}"; CH="${REST2#*:}"

run() { if [ "$DRY" = "1" ]; then echo "[dry-run] $*"; else eval "$@"; fi; }

echo "============================================================"
echo "video-pipeline · profile=$PROFILE · stage=$STAGE"
echo "  工作目录 : $WORK"
echo "  node     : $NODE"
echo "  身份图   : $IDENT"
echo "  场景图   : $SCENE"
echo "  会话/模型: $SESSION / $MODEL"
echo "  段数/时长: $SEG_N 段 × ${DUR}s   机位: $([ "$DESK" = 1 ] && echo 桌面俯拍 || echo 正面口播)"
echo "  成片名   : $OUTNAME"
echo "============================================================"

# ============================ check ============================
do_check() {
  local bad=0
  for f in "$IDENT" "$SCENE"; do
    if [ -s "$f" ]; then echo "[OK]   $(basename "$f")"; else echo "[FAIL] 缺 $f"; bad=1; fi
  done
  [ -f "$WORK/segments.json" ] && echo "[OK]   segments.json ($SEG_N 段)" || { echo "[FAIL] 缺 segments.json"; bad=1; }
  [ -f "$WORK/subtitles.ass" ] && echo "[OK]   subtitles.ass" || echo "[warn] 缺 subtitles.ass（build 阶段需要）"
  for i in $(seq 1 "$SEG_N"); do
    [ -s "$WORK/prompts/part$i.prompt.txt" ] && echo "[OK]   prompts/part$i.prompt.txt" || { echo "[FAIL] 缺 prompts/part$i.prompt.txt"; bad=1; }
  done
  [ "$bad" = "0" ] && echo ">>> check 通过，可以生成。" || echo ">>> check 未通过，先补齐再跑。"
  return $bad
}

# ============================ 提交 + 轮询 ============================
submit_one() {
  local L="$1"; shift
  local P="$WORK/prompts/$L.prompt.txt"
  [ -s "$P" ] || { echo "FAIL 缺 $P"; return 1; }
  if [ -s "$WORK/$L.mp4" ]; then echo "[$L] 已存在 $L.mp4，跳过提交（一段只生成一次）"; return 0; fi
  run "dreamina multimodal2video --image '$IDENT' --image '$SCENE' $* --prompt=\"\$(cat '$P')\" --duration $DUR --ratio $RATIO --video_resolution $RES --model_version $MODEL --session $SESSION > '$WORK/submit_$L.json' 2> '$WORK/submit_$L.err'"
  [ "$DRY" = "1" ] && return 0
  local SID; SID=$(jget "$WORK/submit_$L.json" "j.submit_id")
  [ -z "$SID" ] && { echo "FAIL $L 未拿到 submit_id"; head -20 "$WORK/submit_$L.err"; return 1; }
  echo "$L $SID" >> "$WORK/submit_ids.txt"
  echo "[$L] submit_id=$SID"
}

poll_one() {
  local L="$1" SID="$2"
  [ -z "$SID" ] && { echo "FAIL $L 无 submit_id"; return 1; }
  for i in $(seq 1 60); do
    dreamina query_result --submit_id="$SID" --download_dir "$WORK" > "$WORK/query_$L.json" 2> "$WORK/query_$L.err"
    local ST; ST=$(jget "$WORK/query_$L.json" "j.gen_status")
    echo "[$L #$i] $(date +%H:%M:%S) status=$ST"
    if [ "$ST" = "success" ]; then
      if [ -s "$WORK/${SID}_video_1.mp4" ]; then
        mv -f "$WORK/${SID}_video_1.mp4" "$WORK/$L.mp4"
        echo "[$L] OK -> $L.mp4 ($(stat -c%s "$WORK/$L.mp4") bytes)"; return 0
      fi
      echo "[$L] success 但没找到落盘文件"; ls -1 "$WORK" | grep "$SID" || true; return 1
    fi
    # 坑：dreamina 终态是 fail 不是 failed
    if [ "$ST" = "fail" ]; then
      echo "[$L] FAIL: $(jget "$WORK/query_$L.json" 'j.fail_reason')"; return 1
    fi
    sleep 20
  done
  echo "[$L] TIMEOUT"; return 1
}

# ============================ mosaic ============================
do_mosaic() {
  [ -s "$WORK/part1.mp4" ] || { echo "FAIL 缺 part1.mp4"; return 1; }
  # 坑：cv2 在本机不可用，一律用 ffmpeg 固定区域法
  ffmpeg -y -ss "$SS" -i "$WORK/part1.mp4" -frames:v 1 -q:v 2 "$WORK/part1_ref_raw.jpg" 2> "$WORK/mosaic_err.log"
  [ -s "$WORK/part1_ref_raw.jpg" ] || { echo "FAIL 抽帧失败"; tail -20 "$WORK/mosaic_err.log"; return 1; }
  echo "抽帧 OK: part1_ref_raw.jpg ($(stat -c%s "$WORK/part1_ref_raw.jpg") bytes)"
  ffmpeg -y -i "$WORK/part1_ref_raw.jpg" \
    -vf "split=2[a][b];[a]crop=${CW}:${CH}:${CX}:${CY},scale=23:35:flags=neighbor,scale=${CW}:${CH}:flags=neighbor[px];[b][px]overlay=${CX}:${CY}" \
    -q:v 2 "$WORK/mosaic_ref.jpg" 2>> "$WORK/mosaic_err.log"
  [ -s "$WORK/mosaic_ref.jpg" ] || { echo "FAIL 马赛克失败"; tail -20 "$WORK/mosaic_err.log"; return 1; }
  echo "马赛克 OK: mosaic_ref.jpg ($(stat -c%s "$WORK/mosaic_ref.jpg") bytes) crop=$CROP"
}

# ============================ build ============================
do_build() {
  for i in $(seq 1 "$SEG_N"); do
    [ -s "$WORK/part$i.mp4" ] || { echo "FAIL 缺 part$i.mp4"; return 1; }
  done
  # fontconfig 配置：优先环境变量，其次家目录，最后自动找一个存在的
  # （2026-09-16 修复：原写死 "C:/Users/<用户名>/fonts.conf" 占位符，换机器直接失效）
  FONTCONF="${FONTCONFIG_FILE:-$HOME_WIN/fonts.conf}"
  [ -f "$FONTCONF" ] || FONTCONF="$(ls -1 "$HOME_WIN"/fonts.conf "$HOME_WIN"/.fonts.conf 2>/dev/null | head -1)"
  if [ -n "$FONTCONF" ] && [ -f "$FONTCONF" ]; then export FONTCONFIG_FILE="$FONTCONF"; else echo "[warn] 未找到 fonts.conf，libass 可能回退系统字体（字幕字体不对但不报错）"; fi
  : > "$WORK/concat_list.txt"
  for i in $(seq 1 "$SEG_N"); do echo "file 'part$i.mp4'" >> "$WORK/concat_list.txt"; done
  # 铁律：concat 必须 v=1:a=1 保音轨
  ffmpeg -y -f concat -safe 0 -i "$WORK/concat_list.txt" \
    -filter_complex "[0:v]scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setsar=1,fps=30[v];[0:a]aresample=async=1[a]" \
    -map "[v]" -map "[a]" -c:v libx264 -preset medium -crf 20 -c:a aac -b:a 192k -shortest \
    "$WORK/concat_raw.mp4" 2> "$WORK/concat_err.log"
  [ -s "$WORK/concat_raw.mp4" ] || { echo "FAIL 拼接失败"; tail -20 "$WORK/concat_err.log"; return 1; }
  echo "拼接 OK: $(stat -c%s "$WORK/concat_raw.mp4") bytes"
  # 坑：ffmpeg 滤镜对绝对路径/中文/冒号极敏感 → 用相对文件名
  ( cd "$WORK" && ffmpeg -y -i concat_raw.mp4 -vf "subtitles=subtitles.ass" \
      -c:v libx264 -preset medium -crf 20 -c:a copy "$OUTNAME" 2> burn_err.log )
  [ -s "$WORK/$OUTNAME" ] || { echo "FAIL 烧字幕失败"; tail -20 "$WORK/burn_err.log"; return 1; }
  echo "成片 OK: $OUTNAME ($(stat -c%s "$WORK/$OUTNAME") bytes)"
  ffprobe -v error -show_entries format=duration -show_entries stream=codec_type,width,height \
    -of default=noprint_wrappers=1 "$WORK/$OUTNAME"
}

# ============================ cover ============================
do_cover() {
  local MAKECOVER="$SCRIPT_DIR/make_cover.py"
  # 2026-09-16 修复：原写死 "C:/Users/<用户名>/..." 占位符，改用动态家目录
  local PYCOVER="$HOME_WIN/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
  [ -x "$PYCOVER" ] || PYCOVER="$(command -v python3 2>/dev/null || command -v python 2>/dev/null || true)"
  [ -f "$MAKECOVER" ] || { echo "FAIL 找不到 make_cover.py: $MAKECOVER"; return 1; }
  if [ ! -s "$WORK/cover_base.jpg" ]; then
    ffmpeg -y -ss 5 -i "$WORK/part1.mp4" -frames:v 1 -q:v 2 "$WORK/cover_base.jpg" 2>/dev/null
  fi
  [ -s "$WORK/cover_base.jpg" ] || { echo "FAIL 缺封面底帧"; return 1; }
  "$PYCOVER" "$MAKECOVER" --base "$WORK/cover_base.jpg" --line1 "$COVER_L1" --line2 "$COVER_L2" \
    --style "$COVER_STYLE" --font "$COVER_FONT" \
    --out-png "$WORK/cover.png" --out-jpg "$WORK/cover_512k.jpg" 2>&1 | tail -5
  [ -s "$WORK/cover_512k.jpg" ] || { echo "FAIL 封面生成失败"; return 1; }
  echo "封面 OK: cover_512k.jpg ($(stat -c%s "$WORK/cover_512k.jpg") bytes)"
}

# ============================ qc ============================
do_qc() {
  local PF="$SCRIPT_DIR/preflight_check.js"
  [ -f "$PF" ] || { echo "FAIL 找不到 preflight_check.js"; return 1; }
  # preflight 用 process.cwd()/output/... 找台账/封面，必须从项目根跑（坑：2026-09-03 跑 G 项误判"今天没发"，根因就是 cwd 不对）
  local PROJ_ROOT="$(cd "$WORK/../../.." 2>/dev/null && pwd -W 2>/dev/null || cd "$WORK/../../.." && pwd)"
  [ -d "$PROJ_ROOT/.workbuddy" ] || PROJ_ROOT="$(cd "$WORK" && pwd -W 2>/dev/null || pwd)"
  pushd "$PROJ_ROOT" >/dev/null 2>&1
  # 2026-09-16 修复：原写死 --profile muziqi，换账号时 qc 会验错 profile
  "$NODE" "$PF" --profile "$PROFILE" --video "$WORK/$OUTNAME" --cover "$WORK/cover_512k.jpg" 2>&1 | tail -20
  popd >/dev/null 2>&1
}

# ============================ 分发 ============================
case "$STAGE" in
  check)  do_check ;;
  part1)  submit_one part1 && poll_one part1 "$(grep '^part1 ' "$WORK/submit_ids.txt" 2>/dev/null | tail -1 | awk '{print $2}')" ;;
  mosaic) do_mosaic ;;
  part23) [ -s "$WORK/mosaic_ref.jpg" ] || { echo "FAIL 缺 mosaic_ref.jpg，先跑 mosaic"; exit 1; }
          submit_one part2 --image "'$WORK/mosaic_ref.jpg'" --image "'$MATERIAL_DIR/聊天截图/后台AI对话分析.jpg'"
          submit_one part3 --image "'$WORK/mosaic_ref.jpg'" --video "'$WORK/broll_seg3.mp4'"
          for L in part2 part3; do
            poll_one "$L" "$(grep "^$L " "$WORK/submit_ids.txt" 2>/dev/null | tail -1 | awk '{print $2}')" &
          done
          wait ;;
  build)  do_build ;;
  cover)  do_cover ;;
  qc)     do_qc ;;
  all)    do_check && \
          submit_one part1 && poll_one part1 "$(grep '^part1 ' "$WORK/submit_ids.txt" | tail -1 | awk '{print $2}')" && \
          do_mosaic && \
          ( submit_one part2 --image "'$WORK/mosaic_ref.jpg'"; submit_one part3 --image "'$WORK/mosaic_ref.jpg'" ) && \
          do_build && do_cover && do_qc ;;
  *) echo "未知 stage: $STAGE（check|part1|mosaic|part23|build|cover|qc|all）"; exit 2 ;;
esac
