#!/usr/bin/env node
/**
 * 即梦（Dreamina）OAuth Device Flow 两段式登录助手（账号无关）。
 *
 * 为什么需要它：
 *   设备码只有 **约 10 分钟** 有效期，且 `checklogin --poll=N` **不是长轮询**
 *   —— 实测约 40 秒就返回「等待登录超时，请重试」并退出。
 *   所以**不能**「先起后台轮询、等用户慢慢点」。正确顺序是两段式：
 *     ① 取码（立刻）→ 把码给用户 → ② 等用户授权完成后，再 checklogin。
 *   本脚本把「device_code 暂存」这一步固化下来，避免中间丢掉码。
 *
 * 用法：
 *   node dreamina_login.js code     # ① 取授权链接 + 暂存 device_code
 *   node dreamina_login.js done     # ② 用户授权完成后执行，落地 token
 *   node dreamina_login.js status   # 查看当前登录态
 *
 * 环境变量：
 *   VP_DREAMINA   指定 dreamina 可执行文件绝对路径（默认走 PATH 里的 dreamina）
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const EXE = process.env.VP_DREAMINA || 'dreamina';
const STATE = path.join(os.homedir(), '.workbuddy', '.dreamina_login_state.json');
const cmd = (process.argv[2] || '').toLowerCase();

const run = args => spawnSync(EXE, args, { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });

function fail(msg) {
  console.error(msg);
  process.exit(1);
}

// ---------- status ----------
if (cmd === 'status') {
  const r = run(['session', 'list']);
  const out = (r.stdout || '') + (r.stderr || '');
  console.log(out.trim() || '(无输出)');
  process.exit(r.status === 0 ? 0 : 1);
}

// ---------- code ----------
if (cmd === 'code') {
  const r = run(['login', '--headless']);
  const out = (r.stdout || '') + (r.stderr || '');
  if (r.status !== 0 || !/verification_uri/.test(out)) {
    fail('取码失败，原始输出：\n' + (out.trim() || '(空)'));
  }
  const pick = key => {
    const m = out.match(new RegExp('^' + key + ':\\s*(.+)$', 'm'));
    return m ? m[1].trim() : null;
  };
  const state = {
    verification_uri: pick('verification_uri'),
    user_code: pick('user_code'),
    device_code: pick('device_code'),
    expires_at: pick('expires_at'),
    saved_at: new Date().toISOString(),
  };
  fs.mkdirSync(path.dirname(STATE), { recursive: true });
  fs.writeFileSync(STATE, JSON.stringify(state, null, 2), 'utf8');

  console.log('请把下面这条链接发给用户，让他在浏览器里完成授权：\n');
  console.log(state.verification_uri);
  console.log('\nuser_code : ' + state.user_code);
  console.log('有效期至  : ' + state.expires_at + '   ⚠️ 大约只有 10 分钟');
  console.log('\ndevice_code 已暂存到 ' + STATE);
  console.log('用户回复「授权好了」之后，执行：node dreamina_login.js done');
  process.exit(0);
}

// ---------- done ----------
if (cmd === 'done') {
  if (!fs.existsSync(STATE)) fail('没有暂存的 device_code，请先执行：node dreamina_login.js code');
  const st = JSON.parse(fs.readFileSync(STATE, 'utf8'));
  if (!st.device_code) fail('暂存文件里没有 device_code，请重新取码');

  const r = run(['login', 'checklogin', '--device_code=' + st.device_code, '--poll=5']);
  const out = ((r.stdout || '') + (r.stderr || '')).trim();
  console.log(out || '(无输出)');

  if (r.status === 0 && !/超时|timeout|失败|error/i.test(out)) {
    console.log('\n✅ 登录成功，device_code 暂存文件已清理。');
    try { fs.rmSync(STATE, { force: true }); } catch (e) { /* 忽略 */ }
    process.exit(0);
  }
  console.log('\n⚠️ 未成功。常见原因：');
  console.log('  · 设备码已过期（>10 分钟）→ 重新执行 code 取新码');
  console.log('  · 用户尚未在浏览器完成授权 → 等他点完再执行 done');
  console.log('  · 若反复超时，直接跑 `dreamina login` 交互式重来一遍');
  process.exit(1);
}

console.log(`即梦登录助手
用法:
  node ${path.basename(__filename)} code     # ① 取授权链接 + 暂存 device_code
  node ${path.basename(__filename)} done     # ② 用户授权完成后执行，落地 token
  node ${path.basename(__filename)} status   # 查看当前登录态

当前 dreamina: ${EXE}`);
process.exit(cmd ? 2 : 0);
