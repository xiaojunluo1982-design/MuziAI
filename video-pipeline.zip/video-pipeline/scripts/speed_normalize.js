#!/usr/bin/env node
/**
 * speed_normalize.js —— 段级净语速归一（2026-10-23 新增）
 *
 * 为什么需要：
 *   即梦每段是**独立生成**（一次调用一个 part），模型分到的秒数是「建议」不是「约束」——
 *   它倾向于「把台词塞进给定时长、说完就留空尾」，于是同样目标语速下，
 *   各段实测净语速会随机落在 7.4–8.7 字/s。四段拼起来就是「这段赶、那段拖」。
 *   2026-10-21 seq3 实测：part1 7.59 / part2 7.43 / part3 8.35 / part4 7.44（极差 0.92，p3 快 12.4%）。
 *   → 公式管不住这件事，只能后期按段拉齐。
 *
 * 做法：
 *   ① 测每段「净语速」= 字数 ÷ 有声时长（有声时长 = 总时长 − 静音区间合计，silencedetect -35dB/0.2s）
 *   ② 取全片加权目标语速（默认 auto = 总字数 ÷ 总有声时长；也可 --target 指定）
 *   ③ 逐段算速度比 r = 目标 ÷ 本段净语速（r<1 表示这段太快、要放慢）
 *   ④ ffmpeg 同时 `setpts=PTS/r`（画面）+ `atempo=r`（音频，保音调）→ 音画同步变速
 *
 * 🔴 必须音视频一起变：只 atempo 音频会音画不同步；只 setpts 画面会变声。
 * 🔴 归一后的段才是**字幕 probe 与拼接的输入**（时长已变），顺序：trim → 本步 → 字幕 → 拼接。
 *
 * 用法：
 *   node speed_normalize.js --segdir <含 partN.mp4 的目录> --segments <内容包.json|segments.json>
 *        [--target auto|<字/秒>] [--min 0.85] [--max 1.15] [--out <输出目录>] [--apply]
 *   node speed_normalize.js --segdir seg --chars "54,52,104,56" --apply
 *   （不加 --apply = 只测量出报告，不动文件）
 *
 * 退出码：0 正常；2 输入缺失；3 转码失败
 */
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ---------- 外部命令探测（本机 PATH 缺 coreutils，一律绝对路径优先） ----------
const pick = (envVar, list, fallback) => {
  for (const c of [process.env[envVar], ...list].filter(Boolean)) {
    if (fs.existsSync(c)) return c;
  }
  console.warn('[WARN] 未找到 ' + (envVar || fallback) + '，回退裸命令名交给 PATH');
  return fallback;
};
const FFMPEG = pick('FFMPEG_BIN', [
  'C:/Users/admin/.workbuddy/bin/ffmpeg/bin/ffmpeg.exe',
  'C:/ffmpeg/bin/ffmpeg.exe',
], 'ffmpeg');
const FFPROBE = pick('FFPROBE_BIN', [
  'C:/Users/admin/.workbuddy/bin/ffmpeg/bin/ffprobe.exe',
  'C:/ffmpeg/bin/ffprobe.exe',
], 'ffprobe');

// ---------- 参数 ----------
const argv = process.argv.slice(2);
const getArg = (k, def) => { const i = argv.indexOf('--' + k); return i >= 0 && argv[i + 1] ? argv[i + 1] : def; };
const hasFlag = k => argv.includes('--' + k);

const SEGDIR = getArg('segdir', '');
const SEGFILE = getArg('segments', '');
const CHARS = getArg('chars', '');
const TARGET = getArg('target', 'auto');
const MINR = Number(getArg('min', '0.85'));
const MAXR = Number(getArg('max', '1.15'));
const NOISE = getArg('noise', '-35');
const MINDUR = getArg('mindur', '0.2');
const SKIP_EPS = Number(getArg('skip', '0.02'));   // |r-1| < 此值视为已对齐，直接 copy 不重编码
const APPLY = hasFlag('apply');

if (!SEGDIR || (!SEGFILE && !CHARS)) {
  console.error('用法: node speed_normalize.js --segdir <目录> (--segments <json> | --chars "54,52,104,56") [--target auto] [--min 0.85] [--max 1.15] [--out dir] [--apply]');
  process.exit(2);
}
if (!fs.existsSync(SEGDIR)) { console.error('ERR 目录不存在: ' + SEGDIR); process.exit(2); }
const OUT = getArg('out', path.join(SEGDIR, '..', 'seg_norm'));

// ---------- 字数来源 ----------
const cnLen = s => String(s).replace(/\s/g, '').length;   // 段字数含标点（与 durationFormula 同口径）
let chars = [];
if (CHARS) {
  chars = CHARS.split(',').map(x => Number(x.trim())).filter(n => n > 0);
} else {
  if (!fs.existsSync(SEGFILE)) { console.error('ERR 文件不存在: ' + SEGFILE); process.exit(2); }
  const j = JSON.parse(fs.readFileSync(SEGFILE, 'utf8'));
  const arr = j.spoken || j.segments || (Array.isArray(j) ? j : null);
  if (!arr) { console.error('ERR 取不到段数组（需 spoken / segments 字段）'); process.exit(2); }
  chars = arr.map(s => cnLen(typeof s === 'string' ? s : (s.text || s.content || '')));
}
if (!chars.length) { console.error('ERR 字数为空'); process.exit(2); }

// ---------- 段文件 ----------
// 兼容两种命名：probe 目录的 partN.mp4、trim 输出的 partN_trim.mp4
const segs = [];
for (let i = 1; i <= chars.length; i++) {
  const cand = [path.join(SEGDIR, 'part' + i + '.mp4'), path.join(SEGDIR, 'part' + i + '_trim.mp4')];
  const f = cand.find(x => fs.existsSync(x));
  if (!f) { console.error('ERR 缺 part' + i + '.mp4 / part' + i + '_trim.mp4 in ' + SEGDIR); process.exit(2); }
  segs.push(f);
}

// ---------- 测量 ----------
const probeDur = f => {
  const r = spawnSync(FFPROBE, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', f], { encoding: 'utf8' });
  return parseFloat((r.stdout || '0').trim()) || 0;
};
const silenceTotal = (f, D) => {
  const r = spawnSync(FFMPEG, ['-hide_banner', '-i', f, '-af', `silencedetect=noise=${NOISE}dB:d=${MINDUR}`, '-f', 'null', '-'],
    { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  const ev = [...((r.stderr || '').matchAll(/silence_(start|end): ([\d.]+)/g))].map(m => ({ k: m[1], t: parseFloat(m[2]) }));
  let sil = 0, open = null;
  for (const e of ev) {
    if (e.k === 'start') open = e.t;
    else if (e.k === 'end' && open !== null) { sil += Math.max(0, e.t - open); open = null; }
  }
  if (open !== null) sil += Math.max(0, D - open);
  return Math.min(sil, Math.max(0, D - 0.1));   // 兜底：不得把有声时长算成 0
};

const rows = segs.map((f, i) => {
  const D = probeDur(f);
  const sil = silenceTotal(f, D);
  const voice = D - sil;
  return { idx: i + 1, file: f, chars: chars[i], dur: D, silence: sil, voice, net: chars[i] / voice };
});

// ---------- 目标语速 ----------
// 🔴 auto 用**中位数**不用加权平均：加权平均会被最长那段（字数多、权重最大）拉向它自己，
//    结果「一段异常」变成「三段陪着加速」，反而把稳的段全动了（2026-10-23 实测：
//    seq3 加权均值 7.80 → p1/p2/p4 要各加速 2.8%/5.0%/4.8%，只有 p3 该降；中位数 7.51 → 只有 p3 动 10%）。
//    中位数 = 「多数段的正常水位」，异常段单独拉回来，其余段 |r-1|<2% 直接 copy 不重编码，质量损失最小。
const median = a => { const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const totalChars = rows.reduce((a, r) => a + r.chars, 0);
const totalVoice = rows.reduce((a, r) => a + r.voice, 0);
const auto = median(rows.map(r => r.net));
const target = TARGET === 'auto' ? auto : Number(TARGET);
if (!(target > 0)) { console.error('ERR target 非法: ' + TARGET); process.exit(2); }

console.log('段级净语速报告（阈值 ' + NOISE + 'dB / ' + MINDUR + 's，净语速 = 字数 ÷ 有声时长）');
console.log('  #  字数   时长   静音   有声   净语速   速度比r  atempo');
rows.forEach(r => {
  let raw = target / r.net;
  const r2 = Math.min(MAXR, Math.max(MINR, raw));
  const clamped = Math.abs(r2 - raw) > 1e-6;
  r.raw = raw; r.r = r2; r.clamped = clamped;
  r.newDur = r.dur / r2;
  r.newNet = r.chars / (r.voice / r2);
  console.log('  p' + r.idx + '  ' + String(r.chars).padStart(4) + '  ' + r.dur.toFixed(2) + '  ' +
    r.silence.toFixed(2) + '  ' + r.voice.toFixed(2) + '   ' + r.net.toFixed(2) + '     ' +
    r.r.toFixed(3) + (clamped ? ' *' : '  ') + '   ' + (Math.abs(r.r - 1) < SKIP_EPS ? 'copy(已对齐)' : r.r.toFixed(3)));
});
const nets = rows.map(r => r.net);
const spreadOld = Math.max(...nets) - Math.min(...nets);
const spreadOldPct = (spreadOld / (nets.reduce((a, b) => a + b) / nets.length)) * 100;
const newNets = rows.map(r => r.chars / r.voice * r.r);   // = 目标（未截断的段精确等于 target）
const spreadNew = Math.max(...newNets) - Math.min(...newNets);
console.log('目标净语速 = ' + target.toFixed(2) + ' 字/s（' + (TARGET === 'auto' ? 'auto 中位数，各段 ' + nets.map(n => n.toFixed(2)).join('/') : '指定') + '）');
console.log('归一前极差 ' + spreadOld.toFixed(2) + ' 字/s（' + spreadOldPct.toFixed(1) + '%）→ 归一后 ' + spreadNew.toFixed(2) + ' 字/s（' + ((spreadNew / target) * 100).toFixed(1) + '%）');
console.log('成片时长 ' + rows.reduce((a, r) => a + r.dur, 0).toFixed(2) + 's → ' + rows.reduce((a, r) => a + r.newDur, 0).toFixed(2) + 's');
rows.filter(r => r.clamped).forEach(r => console.log('  ⚠️ p' + r.idx + ' 速度比被限幅夹住（原始 ' + r.raw.toFixed(3) + ' → ' + r.r.toFixed(3) + '），该段仍会偏离目标 —— 大概率是文案某段字数与时长严重不匹配，建议回查'));

if (!APPLY) {
  console.log('\n[dry-run] 未改动任何文件。加 --apply 执行转码。');
  process.exit(0);
}

// ---------- 执行 ----------
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
const done = [];
for (const r of rows) {
  const dst = path.join(OUT, 'part' + r.idx + '.mp4');
  if (Math.abs(r.r - 1) < SKIP_EPS) {
    fs.copyFileSync(r.file, dst);
    done.push({ ...r, atempo: 1, action: 'copy' });
    console.log('p' + r.idx + ' 已对齐 → copy');
    continue;
  }
  const fc = `[0:v]setpts=PTS/${r.r}[v];[0:a]atempo=${r.r}[a]`;
  const res = spawnSync(FFMPEG, ['-y', '-i', r.file, '-filter_complex', fc, '-map', '[v]', '-map', '[a]',
    '-c:v', 'libx264', '-crf', '18', '-preset', 'medium', '-r', '60',
    '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', dst],
    { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, timeout: 600000 });
  if (!fs.existsSync(dst) || res.status !== 0) {
    console.error('ERR p' + r.idx + ' 转码失败: ' + ((res.stderr || '').split('\n').slice(-3).join(' ')));
    process.exit(3);
  }
  const nd = probeDur(dst);
  done.push({ ...r, atempo: r.r, newDurActual: nd, action: 'atempo' });
  console.log('p' + r.idx + ' atempo=' + r.r.toFixed(3) + ' → ' + r.dur.toFixed(2) + 's ⇒ ' + nd.toFixed(2) + 's');
}

// ---------- 复核（转码后实测，别信算术） ----------
const finalRows = done.map(d => {
  const D = probeDur(path.join(OUT, 'part' + d.idx + '.mp4'));
  const sil = silenceTotal(path.join(OUT, 'part' + d.idx + '.mp4'), D);
  const voice = D - sil;
  return { idx: d.idx, chars: d.chars, dur: +D.toFixed(2), net: +(d.chars / voice).toFixed(2) };
});
const fn = finalRows.map(r => r.net);
const fs2 = Math.max(...fn) - Math.min(...fn);
console.log('\n复核（转码后实测）：' + finalRows.map(r => 'p' + r.idx + ' ' + r.dur + 's/' + r.net).join('  '));
console.log('归一后极差 ' + fs2.toFixed(2) + ' 字/s（' + ((fs2 / (fn.reduce((a, b) => a + b) / fn.length)) * 100).toFixed(1) + '%）');

const meta = {
  at: new Date().toISOString(),
  segdir: path.resolve(SEGDIR), out: path.resolve(OUT),
  noise: NOISE, mindur: MINDUR, target: +target.toFixed(3), targetMode: TARGET,
  before: rows.map(r => ({ idx: r.idx, chars: r.chars, dur: +r.dur.toFixed(2), silence: +r.silence.toFixed(2), net: +r.net.toFixed(2) })),
  after: finalRows, atempo: done.map(d => +Number(d.atempo).toFixed(4)),
  spreadBefore: +spreadOld.toFixed(2), spreadAfter: +fs2.toFixed(2),
  totalBefore: +rows.reduce((a, r) => a + r.dur, 0).toFixed(2),
  totalAfter: +finalRows.reduce((a, r) => a + r.dur, 0).toFixed(2),
};
fs.writeFileSync(path.join(OUT, '_speed.json'), JSON.stringify(meta, null, 2), 'utf8');
console.log('OK -> ' + OUT + '（_speed.json 已写）');
console.log('🔴 下游必须改用 ' + OUT + ' 里的 partN.mp4：probe 复制、字幕、拼接、动效 --segDurs 全部以新时长为准');
