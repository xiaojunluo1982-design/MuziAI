/**
 * 字幕样式表 —— 单一真相（single source of truth）
 *
 * 被 `gen_subtitles.js`（即梦生成片：按字数占比排时间轴）
 * 与 `asr_to_ass.js`（真人素材：按 ASR 逐字时间戳排时间轴）共同引用。
 * **样式只在这里改一处**，不要在调用方再抄一份（会变成「两份真相」）。
 *
 * ASS 颜色为 &HAA BBGGRR（BGR 顺序）。BorderStyle: 1=描边 3=不透明底框（BackColour 作底色）
 *
 * ⚠️ `Fontname` 必须写「字体注册到系统的名字」（2026-09-16 实测）：
 *   Windows 上 libass 走 DirectWrite，**只认注册名**，既不是文件名、也不一定是 name 表 Family(1)。
 *   写错会**静默回退**系统字体（画面照样有字幕，肉眼看不出来）。实测取值：
 *     优设标题黑   → YouSheBiaoTiHei
 *     得意黑       → **Smiley Sans Oblique**（不是 'Smiley Sans'）
 *     胡晓波男神体 → HuXiaoBo-NanShen
 *     锐字真言体   → ZhenyanGB
 *     阿里普惠体   → **Alibaba PuHuiTi 3.0 105 Heavy**（不是 'Alibaba PuHuiTi'）
 *   烧字幕时还必须带 `:fontsdir='<VP_FONTS_DIR 转义形式>'` 做双保险。验证用 `setup_check.js` 的字体端到端项。
 */
const SUB_STYLES = {
  t1: { name: '经典亮黄（黄字黑边6px · 下1/3，优设标题黑）', font: 'YouSheBiaoTiHei', size: 52, primary: '&H0009DAF7', outline: '&H00000000', outlineW: 6, border: 1, back: '&H00000000', shadow: 0, marginv: 260 },
  t2: { name: '极简白（白字细边3px · 稍低，得意黑）', font: 'Smiley Sans Oblique', size: 48, primary: '&H00FFFFFF', outline: '&H00000000', outlineW: 3, border: 1, back: '&H00000000', shadow: 0, marginv: 230 },
  t3: { name: '影院黑条（白字+半透明黑底条，真言体）', font: 'ZhenyanGB', size: 46, primary: '&H00FFFFFF', outline: '&H00000000', outlineW: 0, border: 3, back: '&H96000000', shadow: 0, marginv: 240 },
  t4: { name: '综艺橙（白字橙红描边5px+黑影，普惠体）', font: 'Alibaba PuHuiTi 3.0 105 Heavy', size: 54, primary: '&H00FFFFFF', outline: '&H00003BFF', outlineW: 5, border: 1, back: '&H00000000', shadow: 2, marginv: 250 },
  t5: { name: '科技青（青白字+深蓝描边，男神体）', font: 'HuXiaoBo-NanShen', size: 48, primary: '&H00FFF39F', outline: '&H00A83F1A', outlineW: 4, border: 1, back: '&H00000000', shadow: 0, marginv: 255 },
  t6: { name: '优设标题黑·黄字黑边（配S7）', size: 52, primary: '&H0009DAF7', outline: '&H00000000', outlineW: 5, border: 1, back: '&H00000000', shadow: 0, marginv: 260, font: 'YouSheBiaoTiHei' },
  t7: { name: '得意黑·白字细边（潮流斜体，配S8）', size: 52, primary: '&H00FFFFFF', outline: '&H00000000', outlineW: 3, border: 1, back: '&H00000000', shadow: 0, marginv: 255, font: 'Smiley Sans Oblique' },
  t8: { name: '男神体·白字橙边+黑影（综艺，配S9）', size: 54, primary: '&H00FFFFFF', outline: '&H00002BE6', outlineW: 5, border: 1, back: '&H00000000', shadow: 2, marginv: 250, font: 'HuXiaoBo-NanShen' },
  t9: { name: '普惠体·白字+深蓝底条（商务，配S10）', size: 46, primary: '&H00FFFFFF', outline: '&H00000000', outlineW: 0, border: 3, back: '&H8C48200A', shadow: 0, marginv: 240, font: 'Alibaba PuHuiTi 3.0 105 Heavy' },
  t10: { name: '真言体·黄字黑边大号（炸场，配S11）', size: 54, primary: '&H0009DAF7', outline: '&H00000000', outlineW: 6, border: 1, back: '&H00000000', shadow: 1, marginv: 250, font: 'ZhenyanGB' },
};

module.exports = { SUB_STYLES };
