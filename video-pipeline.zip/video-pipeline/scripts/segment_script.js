#!/usr/bin/env node
/**
 * 口播分段：只按句末标点切分，绝不改写/删减/调序原文。
 *
 * 🔴 2026-10-11 起「时长优先制」（晓君总指令，旧字数三档作废）：
 *   成片 30-45s ⇄ 总量 220-330 字；单段 ≤15s ⇄ **≤101 字**（2026-10-23 由 109 下调）；
 *   语速基准 7.3 字/s（实测五样本 6.74-7.35）；段数不定死（一般 2-4 段）。
 *   每段生成秒数 duration = clamp(ceil(段字数/7.3*1.08), 4, 15) —— 不再一律 15s；
 *   余量按**比例**留（×1.08），固定 +1s 会让长段撞 15s 顶、语速忽快忽慢（2026-10-23 修）。
 *
 * 用法：
 *   node segment_script.js --script "口播全文..." [--segments 3] --out segments.json
 *   node segment_script.js --script-file script.txt --out segments.json
 */
const fs = require('fs');

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      a[argv[i].slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : true;
      if (a[argv[i].slice(2)] !== true) i++;
    }
  }
  return a;
}

const args = parseArgs(process.argv);
let script = args['script'];
if (!script && args['script-file']) script = fs.readFileSync(args['script-file'], 'utf8');
if (!script) {
  console.error('需要 --script 或 --script-file');
  process.exit(1);
}
script = script.trim();

const total = script.length;

function autoSegments(n) {
  // 时长优先制（2026-10-11）：总量 220-330 字，段均约 85 字 → 一般 3-4 段
  if (n >= 295) return 4;
  if (n >= 150) return 3;
  return 2;
}

let segCount = args['segments'] ? parseInt(args['segments'], 10) : autoSegments(total);

// 1) 按句末标点切成句子（保留标点）
const sentences = [];
let buf = '';
for (const ch of script) {
  buf += ch;
  if ('。？！'.includes(ch)) { sentences.push(buf); buf = ''; }
}
if (buf.trim()) sentences.push(buf);

// 2) 贪心分配到 segCount 段：目标是每段字数尽量接近 total/segCount
const target = total / segCount;
const MAX_SEG = 101; // 🔴 2026-10-23 由 109 下调：101×1.08÷7.3=14.94→15s 不撞顶；102 字就是 15.09→16s 被 clamp，该段语速会被迫快 10%+
const parts = [];
let cur = '';
for (let i = 0; i < sentences.length; i++) {
  const s = sentences[i];
  const remainingSlots = segCount - parts.length;
  if (remainingSlots <= 1) { cur += s; continue; }
  // 若加上这句会明显超过目标且当前段已有内容，则收口
  const overTarget = (cur + s).length > target * 1.25 && cur.length >= target * 0.6;
  // 若加上这句会突破单段硬上限，也必须收口——
  // 否则会走到「按逗号二次拆分」，把完整句子在逗号处劈开、段数也偏离字数档
  const overHardCap = (cur + s).length > MAX_SEG;
  if (cur && (overTarget || overHardCap)) {
    parts.push(cur);
    cur = s;
  } else {
    cur += s;
  }
}
if (cur) parts.push(cur);

// 3) 段数超出（极端长句）时，按逗号二次拆分收口
function splitByComma(text, maxLen) {
  if (text.length <= maxLen) return [text];
  const out = [];
  let b = '';
  for (const ch of text) {
    b += ch;
    if (('，、；：'.includes(ch) || '。？！'.includes(ch)) && b.length >= maxLen * 0.6) {
      out.push(b); b = '';
    }
  }
  if (b) out.push(b);
  return out;
}
const final = [];
for (const p of parts) {
  if (p.length > MAX_SEG) final.push(...splitByComma(p, MAX_SEG));
  else final.push(p);
}

/**
 * 4) 段数平衡（2026-09-02 修复）
 *
 * 背景：贪心分配里 MAX_SEG 硬上限会让实际段数**超出**请求的 --segments
 * （实测 418 字请求 4 段，输出 6 段，且段长 36~143 字严重不均）。
 * 段数一旦偏离，按 15s 上限折算的语速就会失真（长段被迫超速、短段留白）。
 *
 * 修法：贪心之后反复合并「字数之和最小的相邻对」，直到段数收敛到目标。
 * 只移动段边界、不改动任何文字，拼接后仍逐字等于原文。
 */
function balance(parts, segCount, MAX) {
  const arr = parts.slice();
  let limited = false;   // 是否因单段字数上限而收敛不到目标段数
  while (arr.length > segCount) {
    let best = -1, bestSum = Infinity;
    for (let i = 0; i < arr.length - 1; i++) {
      const sum = arr[i].length + arr[i + 1].length;
      if (sum < bestSum) { bestSum = sum; best = i; }
    }
    if (best < 0) break;
    if (bestSum > MAX) {
      // 再合并就会突破单段 15s 上限 —— 宁可多分一段，也不让某段超速失真
      limited = true;
      console.warn(`WARN: 受单段 ≤${MAX} 字（≈15s）限制，无法收敛到 ${segCount} 段，停在 ${arr.length} 段（这是正确的降级，不是错误）`);
      break;
    }
    arr.splice(best, 2, arr[best] + arr[best + 1]);
  }
  return { arr, limited };
}

const { arr: balanced, limited } = balance(final, segCount, MAX_SEG);

// 5) 每段生成秒数：按实测语速折算 + 1s 防截尾，夹在即梦支持的 4-15s 区间
const RATE = 7.3; // 实测语速 字/秒（09-22/09-23/10-09/10-10/10-11 五样本 6.74-7.35）
// 🔴 2026-10-23：余量改**比例**（PAD=1.08），不再固定 +1s。
//    固定 +1s 对短段富余 11%、对长段富余被 15s 上限吃掉 → 目标语速随段长漂移，
//    正是「不同 part 语速不一样」的根因（10-21 seq3 p2 目标 5.78 vs p3 6.93，差 20%）。
const PAD = 1.08;
const result = balanced.map((text, i) => {
  const chars = text.length;
  const duration = Math.max(4, Math.min(15, Math.ceil((chars / RATE) * PAD)));
  return { seg: i + 1, text, chars, duration };
});

const out = args['out'];
if (out) {
  fs.writeFileSync(out, JSON.stringify(result, null, 2), 'utf8');
  console.log('written:', out);
}
console.log('总字数:', total, '分段数:', result.length, '/ 目标', segCount);
result.forEach(r => console.log(
  `  seg${r.seg}: ${r.chars}字/${r.duration}s = ${(r.chars / r.duration).toFixed(2)} 字每秒  ${r.text.slice(0, 20)}...`));

// 自检
const joined = result.map(r => r.text).join('');
console.log('\n--- 分段自检 ---');
// 段数不符只在「未受字数上限限制」时才算 FAIL；受限于 15s 上限而多分一段是正确的降级
const segOk = result.length === segCount || limited;
const checks = [
  ['逐字未改写', joined === script],
  ['段数符合目标' + (limited ? '（受15s上限降级，可接受）' : ''), segOk],
  ['无空段', result.every(r => r.text.trim().length > 0)],
];
checks.forEach(([k, v]) => console.log((v ? 'PASS' : 'FAIL') + '  ' + k));

const rates = result.map(r => r.chars / r.duration);
const maxChars = Math.max(...result.map(r => r.chars));
const maxRate = Math.max(...rates);
if (maxChars > MAX_SEG) {
  console.warn(`WARN: 最长段 ${maxChars} 字 > ${MAX_SEG}，单段可能超 15s，建议返回改文案或手工调段`);
}
if (maxRate > 8) {
  console.warn(`WARN: 最快段语速 ${maxRate.toFixed(2)} 字/秒 > 8，可能失真，建议手工调段`);
}
if (checks.some(c => !c[1])) process.exit(1);
