#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""基频中位数对比：验证 trim_silence.py --speed 走的是 atempo（保音调）而非改采样率（会把人声变尖）。

用法（先各自转 16k 单声道 wav）：
  ffmpeg -y -v error -i 原片.mp4 -ac 1 -ar 16000 -vn a_src.wav
  ffmpeg -y -v error -i 成片.mp4 -ac 1 -ar 16000 -vn a_out.wav
  python scripts/f0_pitch_check.py a_src.wav a_out.wav

判据：中位基频差异 < 12% → 音调保持；≈+30% → 用错了 asetrate / 改采样率那类写法。

实测（2026-09-26 晓君总实拍原片 1.3x）：117.6 → 107.4 Hz，差异 8.7%，PASS。
（这点差异来自剪辑后取样段落与源不完全对齐，atempo 本身零变调。）
"""
import sys
import wave
import array


def f0_median(path, frames=40):
    w = wave.open(path)
    fs = w.getframerate()
    data = array.array("h")
    data.frombytes(w.readframes(w.getnframes()))
    w.close()
    total = len(data)
    win = int(0.04 * fs)
    lo, hi = int(fs / 350.0), int(fs / 70.0)
    step = max(1, (total - win) // frames)
    vals = []
    for i in range(0, total - win, step):
        seg = data[i:i + win]
        e = sum(float(x) * x for x in seg) / win
        if e < 2.0e6:
            continue
        best, bl = 0.0, 0
        for lag in range(lo, hi):
            s = 0.0
            for k in range(0, win - lag, 2):
                s += float(seg[k]) * seg[k + lag]
            if s > best:
                best, bl = s, lag
        if bl:
            vals.append(fs / float(bl))
    if not vals:
        return None
    vals.sort()
    return vals[len(vals) // 2]


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    a, b = sys.argv[1], sys.argv[2]
    fa, fb = f0_median(a), f0_median(b)
    print("A %s -> f0 中位数 %.1f Hz" % (a, fa or -1))
    print("B %s -> f0 中位数 %.1f Hz" % (b, fb or -1))
    if fa and fb:
        d = abs(fb - fa) / fa * 100.0
        print("差异 %.1f%% -> %s" % (d, "PASS 音调保持" if d < 12 else "FAIL 音调被改动"))
        return 0 if d < 12 else 1
    print("样本不足，无法判定")
    return 2


if __name__ == "__main__":
    sys.exit(main())
