#!/usr/bin/env node
/**
 * remap_asr_by_keeps.js —— 重剪后**把原片 ASR 确定性重映射到新成片时间轴**
 * （video-pipeline · 2026-10-14 从 xjz11 v2 实战脚本固化）
 *
 * ⭐ 为什么需要它：SKILL §2B.12 ② 要求「重剪后必须重做 ASR（旧字幕作废）」。
 *   但重做一次云 ASR 要花积分 + 网络等待；而「原片 → 成片」其实是一条**确定性分段仿射映射**，
 *   直接把 `raw_asr.json`（原片字级时间戳）映射过去即可 —— 同一份音频、同一批字，
 *   结果与「重跑一次 ASR」等价，**零成本零等待**。
 *
 * 输入（四个都是文件路径）：
 *   --in       原片 ASR（apiz bigmodel-v2 的 raw 结果，字级 start/end 毫秒）
 *   --keeps    `trim_silence.py --dump-keeps keeps.json` 的输出（**必须同一次裁剪进程**）
 *   --segments 拼接段 JSON：[{ "s": 加气口后的起点, "e": 终点 }, ...]（与拼接脚本同源，顺序一致）
 *   --semantic 语义剪点 JSON：[[起, 终], ...]（= 拼接用的 KEEPS 原文范围，**不加气口**）
 *   --out      输出（结构与 `--in` 相同，可直接喂 `asr_to_ass.js`，无需 --slice）
 *
 * ⚠️ 三个必须记住的坑（都是实测踩出来的）：
 *   1. **别按「逐字两端点映射」写** —— 卡在保留段边界上的字（起点落在被剪掉的静音头部里）
 *      会整字被丢（实测丢「老/那/每/然/所/效」）。✅ 正解：求「字区间 ∩ 保留区间」的交集再映射，
 *      交集短于最小可见宽度（0.10s）时补宽，但不得跨出所在保留段。
 *   2. **字窗口要用语义剪点（semantic），不用垫了气口的 segments** ——
 *      否则垫回来的那段气口里会漏进「被删掉的重复句」的尾巴字（实测漏出「花/就/从」3 个孤儿字）。
 *      几何映射用 segments（含气口），字窗口用 semantic（不含气口）。
 *   3. 映射后要**做单调性收口**（不许与前字时间重叠），否则字幕分屏按时间排会串屏。
 *
 * 用法：
 *   node scripts/remap_asr_by_keeps.js \
 *     --in raw_asr.json --keeps keeps_v2.json \
 *     --segments segments_v2.json --semantic semantic_v2.json \
 *     --out asr_v2.json
 */
const fs = require('fs');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--')) {
    const k = process.argv[i].slice(2);
    args[k] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
  }
}
for (const k of ['in', 'keeps', 'segments', 'semantic', 'out']) {
  if (!args[k]) { console.error('ERR 缺参数 --' + k); process.exit(2); }
}

const raw = JSON.parse(fs.readFileSync(args['in'], 'utf8'));
const kj = JSON.parse(fs.readFileSync(args['keeps'], 'utf8'));
const segs = JSON.parse(fs.readFileSync(args['segments'], 'utf8'));
const SEM = JSON.parse(fs.readFileSync(args.semantic, 'utf8'));

const keeps = kj.keeps;
const SPEED = kj.speed || 1.0;
const MIN_W = 0.10;

const offs = [];
{ let a = 0; for (const g of segs) { offs.push(a); a += (g.e - g.s); } }
const keptAcc = [];
{ let a = 0; for (const [s, e] of keeps) { keptAcc.push(a); a += (e - s); } }

// 自检：拼接总时长须与 trim 实测到的一致（±0.3s，容忍容器误差）
const joinedTotal = segs.reduce((a, g) => a + (g.e - g.s), 0);
if (kj.total && Math.abs(joinedTotal - kj.total) > 0.3) {
  console.error(`ERR 拼接时长自检失败：本脚本算 ${joinedTotal.toFixed(2)}s vs trim 实测 ${kj.total}s` +
    `（segments 与 keeps 不同源？）`);
  process.exit(2);
}
console.log(`拼接自检 PASS：${joinedTotal.toFixed(2)}s（trim 实测 ${kj.total}）| 保留段 ${keeps.length} 段 | speed ${SPEED}`);

const mapWord = (wsMs, weMs) => {
  const a = wsMs / 1000, b = Math.max(weMs / 1000, a + 0.01);
  let best = null;
  for (let i = 0; i < segs.length; i++) {
    const [cs, ce] = SEM[i];
    const s0 = Math.max(a, cs), s1 = Math.min(b, ce);
    if (s1 - s0 <= 0.02) continue;
    const g = segs[i];
    const j0 = offs[i] + (s0 - g.s), j1 = offs[i] + (s1 - g.s);
    for (let k = 0; k < keeps.length; k++) {
      const [ks, ke] = keeps[k];
      const t0 = Math.max(j0, ks), t1 = Math.min(j1, ke);
      if (t1 - t0 <= 0.001) continue;
      const cand = [(keptAcc[k] + (t0 - ks)) / SPEED, (keptAcc[k] + (t1 - ks)) / SPEED];
      if (!best || cand[0] < best[0]) best = cand;
      break;
    }
    if (best) break;
  }
  if (!best) return null;
  if (best[1] - best[0] < MIN_W) {
    let k = 0;
    for (let i = 0; i < keeps.length; i++) {
      const bs = keptAcc[i] / SPEED, be = (keptAcc[i] + (keeps[i][1] - keeps[i][0])) / SPEED;
      if (best[0] >= bs - 1e-6 && best[0] <= be + 1e-6) { k = i; break; }
    }
    const bs = keptAcc[k] / SPEED, be = (keptAcc[k] + (keeps[k][1] - keeps[k][0])) / SPEED;
    const s = Math.min(best[0], Math.max(bs, be - MIN_W));
    best = [s, Math.min(be, s + MIN_W)];
  }
  return best;
};

const out = [];
let wIn = 0, wOut = 0, wShort = 0;
for (const u of raw.result.utterances) {
  const words = [];
  for (const w of (u.words || [])) {
    wIn++;
    const mw = mapWord(w.start_time, w.end_time);
    if (!mw) continue;                                   // 整字落在剪掉区间（去重复/废弃段）→ 丢
    if (mw[1] - mw[0] <= MIN_W + 1e-6) wShort++;
    words.push({ confidence: w.confidence, start_time: Math.round(mw[0] * 1000), end_time: Math.round(mw[1] * 1000), text: w.text });
    wOut++;
  }
  if (!words.length) continue;
  for (let i = 1; i < words.length; i++) {                // 单调性收口
    if (words[i].start_time < words[i - 1].end_time) {
      const mid = Math.round((words[i].start_time + words[i - 1].end_time) / 2);
      words[i - 1].end_time = mid; words[i].start_time = mid;
      if (words[i].end_time <= words[i].start_time) words[i].end_time = words[i].start_time + 60;
    }
  }
  out.push({ start_time: words[0].start_time, end_time: words[words.length - 1].end_time, text: words.map((w) => w.text).join(''), words });
}

const res = {
  task_id: (raw.task_id || 'asr') + '_remap',
  status: 'remapped',
  channel: 'local',
  model: (raw.model || '') + '+remap(' + SPEED + 'x)',
  result: { utterances: out, text: out.map((u) => u.text).join('') },
  price: 0,
  note: `由 ${args['in']} 按确定性分段仿射映射重排到重剪后时间轴（keeps=${args.keeps}）`,
};
fs.writeFileSync(args.out, JSON.stringify(res, null, 1), 'utf8');
console.log(`字：${wIn} → ${wOut}（丢弃 ${wIn - wOut} = 去重复/废弃段；边界字补宽 ${wShort}）| 句：${raw.result.utterances.length} → ${out.length}`);
console.log('输出 ->', args.out);
console.log('下一步：node scripts/asr_to_ass.js --in ' + args.out + ' --out subtitles.ass --style <profile 字幕样式>   # ⛔ 不要传 --slice，时间轴已是成片的');
