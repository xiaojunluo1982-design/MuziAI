#!/usr/bin/env node
/**
 * 生成「上传到 ima 内容生产线」用的 Markdown 文档（不是上传本身，上传走 MCP）。
 *
 * 为什么单独一个脚本：
 *   周计划是结构化 JSON，日报要交叉 published_log —— 让模型每次手写这段转换，
 *   字段一多就会漏、会编。这里把「JSON → 可读文档」固化下来，模型只负责搬运。
 *
 * 用法：
 *   周报（每周日 09:00 产完后跑）—— 🔴 周复盘 + 周计划合并成【一个文档】再传 ima：
 *     node ima_sync_doc.js weekly --review "D:\牧子数智\内容计划\短视频周复盘-2026-09-20.md" \
 *          --plan "D:\牧子数智\内容计划\短视频周计划-2026-09-21.json" \
 *          [--pool "D:\牧子数智\内容计划\短视频选题候选池-2026-09-21.md"] -o out.md
 *   周计划单篇（旧用法，保留兼容；新流程请用 weekly）：
 *     node ima_sync_doc.js plan "<周计划.json>" -o out.md
 *   发布日报（每日 05:00 发布完跑）：
 *     node ima_sync_doc.js daily --date 2026-09-21 --root "D:\牧子数智" -o out.md
 *     可选：--note "视频号授权失效已跳过" （可重复，追加到备注区）
 *
 * weekly 模式：复盘正文原样保留（标题层级降一级），计划由 renderPlan 渲染后接在后面。
 * daily 模式会自动定位本周计划（按 date 所在周的周一 + 计划目录），取当日条目。
 */
const fs = require('fs');
const path = require('path');

const argv = process.argv.slice(2);
const mode = argv[0];
const val = (k, d) => { const i = argv.indexOf('--' + k); return i >= 0 ? argv[i + 1] : d; };
const all = k => argv.reduce((a, v, i) => (v === '--' + k && argv[i + 1] !== undefined ? a.concat(argv[i + 1]) : a), []);
// 位置参数（plan 模式的 json 路径）：跳过所有「带值的开关」及其值
const WITH_VALUE = new Set(['--date', '--root', '--log', '--note', '-o', '--review', '--plan', '--pool']);
const pos = (() => {
  const a = argv.slice(1); const out = [];
  for (let i = 0; i < a.length; i++) {
    if (WITH_VALUE.has(a[i])) { i++; continue; }
    if (a[i].startsWith('-')) continue;
    out.push(a[i]);
  }
  return out;
})();

// 输出路径：-o / --out 都认（早期只认 --o 导致静默打到 stdout）
const out = (() => { const i = argv.findIndex(a => a === '-o' || a === '--out'); return i >= 0 ? argv[i + 1] : null; })();
const cn = s => String(s || '').replace(/\s/g, '').length;
const emit = txt => { if (out) { fs.writeFileSync(out, txt, 'utf8'); console.error(`已写入 ${out}（${Buffer.byteLength(txt, 'utf8')} bytes）`); } else process.stdout.write(txt); };// 写入用 utf8，无 BOM

const WEEK = '日一二三四五六';
const mondayOf = ds => {
  const d = new Date(ds + 'T00:00:00');
  const off = (d.getDay() + 6) % 7;              // 周一=0
  d.setDate(d.getDate() - off);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const weekdayOf = ds => WEEK[new Date(ds + 'T00:00:00').getDay()];

// ---------------- 文本渲染 ----------------
function renderPlan(plan, src) {
  const L = [];
  const total = plan.entries.reduce((a, e) => a + (e.segments || []).reduce((x, s) => x + cn(s), 0), 0);
  L.push(`# 短视频周计划｜${plan.account || ''}｜${plan.weekStart} ~ ${plan.weekEnd}`);
  L.push('');
  L.push(`- 周主题：${plan.topic || ''}`);
  L.push(`- 账号：${plan.account || ''}（profile \`${plan.profile || ''}\`）`);
  L.push(`- 生成时间：${plan.generatedAt || ''}`);
  L.push(`- 闸门：approved=${plan.approved}（口径：生成即默认通过，唯 \`hold: true\` 叫停）｜publishMode=${plan.publishMode}`);
  L.push(`- 本周口播合计 ${total} 字 / ${plan.entries.length} 条 · 每条 3 段`);
  L.push('');
  L.push('## 选题依据');
  L.push('');
  const ms = plan.materialSource || {};
  if (ms.ima && (ms.ima.sources || []).length) {
    L.push(`- ima 素材（${ms.ima.mode || ''}）：`);
    ms.ima.sources.forEach(s => L.push(`  - ${s}`));
  }
  if (ms.hotspot) {
    L.push(`- 热点窗口：${ms.hotspot.window || ''}｜采样 ${JSON.stringify(ms.hotspot.sample || {})}`);
    L.push(`  - 关键词：${(ms.hotspot.keywords || []).join('、')}`);
  }
  if (ms.dataReview) L.push(`- 数据复盘：${ms.dataReview}`);
  if (plan.topicRationale) { L.push(''); L.push(`> ${plan.topicRationale}`); }
  L.push('');
  L.push(`## 本周 ${plan.entries.length} 条`);
  const pd = plan.productionDefaults || {};
  if (pd.scene) { L.push(''); L.push(`> 整周共用场景：${pd.scene}`); L.push(`> 整周共用着装动作：${pd.outfit_action || ''}`); }
  for (const e of plan.entries) {
    const segs = e.segments || [];
    const n = segs.reduce((a, s) => a + cn(s), 0);
    L.push('');
    L.push(`### seq${e.seq} ｜ ${e.date}（${e.weekday || weekdayOf(e.date)}）｜ ${e.content_type || e.type || ''}`);
    L.push('');
    L.push(`- **标题**：${e.title || ''}`);
    L.push(`- **封面**：${(e.cover_title || []).join(' / ')}`);
    L.push(`- 栏目：${e.column || ''}｜开场：${e.opening || ''}｜CTA：${e.ctaType || ''}`);
    L.push(`- 口播：${n} 字 / ${segs.length} 段 / 估算 ${(n * 0.15).toFixed(0)} 秒`);
    if (e.cta) L.push(`- CTA 话术：${e.cta}`);
    if (e.angle_第一人称) L.push(`- 第一人称切入：${e.angle_第一人称}`);
    if (e.product_link) L.push(`- 产品结合点：${e.product_link}`);
    L.push(`- 场景：${e.scene || pd.scene || '（继承 productionDefaults）'}`);
    L.push(`- 着装动作：${e.outfit_action || pd.outfit_action || '（继承 productionDefaults）'}`);
    L.push(`- 发布平台：${(e.platforms || pd.platforms || []).join('、')}`);
    L.push(`- 素材出处：${e.materialSource || e.hot_signal || ''}`);
    if (e.refineNote) L.push(`- 备注：${e.refineNote}`);
    L.push('');
    L.push('**口播正文**');
    L.push('');
    segs.forEach((s, i) => L.push(`${i + 1}. ${s}`));
  }
  L.push('');
  L.push('---');
  L.push('');
  L.push(`> 源文件：\`${src}\`｜本文件由 \`video-pipeline/scripts/ima_sync_doc.js plan\` 生成`);
  return L.join('\n') + '\n';
}

function renderDaily(date, root, logPath, notes) {
  const L = [];
  const mon = mondayOf(date);
  const planPath = path.join(root, '内容计划', `短视频周计划-${mon}.json`);
  let entry = null, plan = null;
  if (fs.existsSync(planPath)) {
    plan = JSON.parse(fs.readFileSync(planPath, 'utf8'));
    entry = (plan.entries || []).find(e => e.date === date) || null;
  }
  // 🔴 2026-10-09 修复：当天可能有多条台账记录（主条目 + 小红书补发队列等），
  //   原来一律取 `.pop()`（最后一条）会把主条目盖掉（10-09 实测：报告里只剩「小红书补发-02」）。
  //   现改为「主条目优先」：seq 为数字者视为主条目（取 seq 最大者）；无数字 seq 才回落到最后一条。
  const isNumSeq = r => r.seq !== null && r.seq !== undefined && String(r.seq).trim() !== '' && Number.isFinite(Number(r.seq));
  const recs = (() => {
    if (!fs.existsSync(logPath)) return [];
    const j = JSON.parse(fs.readFileSync(logPath, 'utf8'));
    const arr = Array.isArray(j) ? j : (j.records || j.entries || []);
    return arr.filter(r => r.date === date);
  })();
  const numSeq = recs.filter(isNumSeq);
  const rec = numSeq.length ? numSeq[numSeq.length - 1] : (recs[recs.length - 1] || null);
  const others = recs.filter(r => r !== rec).length;

  L.push(`# 短视频发布日报｜${plan ? plan.account : '晓君总'}｜${date}（${weekdayOf(date)}）`);
  L.push('');
  if (entry) {
    const segs = entry.segments || [];
    const n = segs.reduce((a, s) => a + cn(s), 0);
    L.push(`- 当日选题：${entry.title || ''}`);
    L.push(`- 封面：${(entry.cover_title || []).join(' / ')}`);
    L.push(`- 内容类型：${entry.content_type || entry.type || ''}｜开场：${entry.opening || ''}｜CTA：${entry.ctaType || ''}`);
    L.push(`- 口播：${n} 字 / ${segs.length} 段 / 估算 ${(n * 0.15).toFixed(0)} 秒`);
    if (entry.cta) L.push(`- CTA 话术：${entry.cta}`);
  } else {
    L.push('- 当日选题：**未在本周计划中找到该日期条目**（计划文件缺失或日期不匹配）');
  }
  L.push('');
  L.push('## 发布结果');
  L.push('');
  if (rec && (rec.platforms || []).length) {
    L.push('| 平台 | 账号 ID | 状态 | taskSetId |');
    L.push('|---|---|---|---|');
    for (const p of rec.platforms) {
      const label = { published: 'published（已发出）', failed: 'failed（失败）', superseded: 'superseded（作废·换号）', submitted: 'submitted（已提交待复核）', pending_review: 'pending_review（待送审）', hold: 'hold（人工叫停）' }[p.status] || (p.status || '');
      L.push(`| ${p.platform || ''} | ${p.platformAccountId || ''} | ${label} | ${p.taskSetId || ''} |`);
    }
    // superseded = 换号/作废的历史记录（如 2026-09-21 视频号换号），不计入分母
    const live = rec.platforms.filter(p => p.status !== 'superseded');
    const ok = live.filter(p => p.status === 'published').length;
    const dead = rec.platforms.length - live.length;
    L.push('');
    L.push(dead
      ? `完成 ${ok}/${live.length} 个平台（另有 ${dead} 条 superseded 记录 = 换号/作废，不计入分母）。`
      : `完成 ${ok}/${live.length} 个平台。`);
    if (others > 0) {
      L.push('');
      L.push(`> 当天台账另有 ${others} 条非主条目记录（如小红书补发队列），未计入上表；如需核验见 \`published_log.json\` ${date} 段。`);
    }
  } else {
    L.push('台账中**没有当日发布记录**——可能未执行、全部失败，或台账未写入（不得据此写成「已发布」）。');
  }
  if (notes.length) {
    L.push('');
    L.push('## 备注');
    L.push('');
    notes.forEach(n => L.push(`- ${n}`));
  }
  L.push('');
  L.push('---');
  L.push('');
  L.push(`> 数据源：\`${path.relative(root, logPath).replace(/\\/g, '/')}\`｜生成脚本 \`video-pipeline/scripts/ima_sync_doc.js daily\``);
  return L.join('\n') + '\n';
}

// 标题降级（合并文档时把两段正文各降一级，保住单一 h1）
function demote(md, n = 1) {
  let inFence = false;
  return String(md).split('\n').map(l => {
    if (/^\s*```/.test(l)) { inFence = !inFence; return l; }
    if (inFence) return l;
    const m = l.match(/^(#{1,6})(\s+)/);
    if (!m) return l;
    const lvl = Math.min(6, m[1].length + n);
    return '#'.repeat(lvl) + l.slice(m[1].length);
  }).join('\n');
}
const dateIn = s => (String(s).match(/(\d{4}-\d{2}-\d{2})/) || [])[1] || '';

/**
 * 周报 = 周复盘 + 下周计划（+ 候选池附录）合并成【一个文档】。
 * 为什么合并：ima「内容生产线」里一个周次只留一条记录，翻一个文件就能看完整周——
 * 复盘看上周做得怎么样、计划看这周要做什么，两者本来就是一前一后同一件事。
 */
function renderWeekly(reviewPath, planPath, poolPath) {
  const plan = planPath && fs.existsSync(planPath) ? JSON.parse(fs.readFileSync(planPath, 'utf8')) : null;
  const review = reviewPath && fs.existsSync(reviewPath) ? fs.readFileSync(reviewPath, 'utf8').trim() : null;
  const pool = poolPath && fs.existsSync(poolPath) ? fs.readFileSync(poolPath, 'utf8').trim() : null;
  const revDate = dateIn(reviewPath);
  const mon = plan ? plan.weekStart : '';
  const L = [];

  L.push(`# 短视频周报｜${plan ? plan.account : '晓君总'}｜${revDate} 复盘 ＋ ${mon}${plan ? ' ~ ' + plan.weekEnd : ''} 计划`);
  L.push('');
  L.push('> 一个文档看完整周：**第一部分**是上周复盘（数据 / 爆款规律 / 诊断），**第二部分**是下周计划（7 条选题 + 口播全文），**附录**是未选用的选题候选池。');
  L.push('');
  L.push(`- 复盘日期：${revDate}`);
  if (plan) {
    const total = plan.entries.reduce((a, e) => a + (e.segments || []).reduce((x, s) => x + cn(s), 0), 0);
    L.push(`- 计划周次：${plan.weekStart} ~ ${plan.weekEnd}（${plan.entries.length} 条 · 每条 3 段 · 合计 ${total} 字）`);
    L.push(`- 周主题：${plan.topic || ''}`);
    L.push(`- 闸门：approved=${plan.approved}（生成即默认通过，唯 \`hold: true\` 叫停）｜publishMode=${plan.publishMode || ''}`);
  }
  L.push(`- 合并来源：\`${[reviewPath, planPath, poolPath].filter(Boolean).map(p => p.replace(/\\/g, '/').split('/').pop()).join(' ＋ ')}\``);
  L.push('');
  L.push('---');
  L.push('');
  L.push(`## 第一部分 · 本周复盘${revDate ? `（截至 ${revDate}）` : ''}`);
  L.push('');
  L.push(review ? demote(review) : '_复盘文件缺失，本部分为空。_');
  L.push('');
  L.push('---');
  L.push('');
  L.push(`## 第二部分 · 下周计划${mon ? `（${mon} ~ ${plan ? plan.weekEnd : ''}）` : ''}`);
  L.push('');
  L.push(plan ? demote(renderPlan(plan, planPath.replace(/\\/g, '/'))) : '_周计划文件缺失，本部分为空。_');
  if (pool) {
    L.push('');
    L.push('---');
    L.push('');
    L.push('## 附录 · 选题候选池（未选用，下期复用）');
    L.push('');
    L.push(demote(pool));
  }
  L.push('');
  L.push('---');
  L.push('');
  L.push('> 本文件由 `video-pipeline/scripts/ima_sync_doc.js weekly` 生成（周复盘原样保留 + 周计划由 JSON 渲染，不经模型手写）。');
  return L.join('\n') + '\n';
}

// ---------------- 入口 ----------------
if (mode === 'weekly') {
  const rv = val('review', pos[0] || null);
  const pl = val('plan', pos[1] || null);
  const pool = val('pool', null);
  if (!rv && !pl) { console.error('用法: node ima_sync_doc.js weekly --review <周复盘.md> --plan <周计划.json> [--pool <候选池.md>] [-o out.md]'); process.exit(2); }
  if (rv && !fs.existsSync(rv)) { console.error(`周复盘不存在: ${rv}`); process.exit(2); }
  if (pl && !fs.existsSync(pl)) { console.error(`周计划不存在: ${pl}`); process.exit(2); }
  if (pool && !fs.existsSync(pool)) { console.error(`注意：候选池不存在，已跳过 → ${pool}`); }
  emit(renderWeekly(rv, pl, pool));
} else if (mode === 'plan') {
  const f = pos[0];
  if (!f || !fs.existsSync(f)) { console.error('用法: node ima_sync_doc.js plan <周计划.json> [-o out.md]'); process.exit(2); }
  emit(renderPlan(JSON.parse(fs.readFileSync(f, 'utf8')), f.replace(/\\/g, '/')));
} else if (mode === 'daily') {
  const date = val('date', null);
  if (!date) { console.error('用法: node ima_sync_doc.js daily --date YYYY-MM-DD [--root <项目根>] [-o out.md] [--note "..."]'); process.exit(2); }
  const root = val('root', process.cwd());
  const logPath = path.resolve(val('log', path.join(root, 'output', 'published_log.json')));
  emit(renderDaily(date, root, logPath, all('note')));
} else {
  console.error('mode 必须是 weekly / plan / daily');
  process.exit(2);
}
