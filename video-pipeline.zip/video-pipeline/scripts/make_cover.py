#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
通用竖版封面生成（720x1280）——12 款风格可选，默认 s7 标题条风。
配合 gen_subtitles.js 的默认 t6 使用（2026-09-03 拍板 s7+t6）。

风格一览：
  s1 爆款大字报   白+亮黄两行、黑描边、中下部渐变灰横幅（牧子琪现款，抖音爆款风）
  s2 杂志极简     纯白大字、无横幅、左上对齐、细黑描边（高级感，适合观点/认知类）
  s3 综艺色块     斜切色块打底、白字粗黑边（综艺花字风，热闹、冲击力强）
  s4 暗夜科技     全屏压暗、青蓝发光字居中（科技感，适合 AI/数字人主题）
  s5 奶油手账     奶油圆角横幅、深棕字（小红书手账风，柔和亲和）
  s12 荧光毛笔    顶部双行、白+荧光绿、毛笔粗体、顶部暗化（复刻 @海龙Allen 主页封面）
  （s6~s11 见文件末 STYLES 表）

用法：
  python make_cover.py --base cover_base.jpg \
      --line1 "晚上10点" --line2 "客户咨询谁在回" \
      --style s1 \
      --out-png cover.png --out-jpg cover_512k.jpg

通用参数：--top --bottom --y1 --y2 --left --max-width --stroke --font
（各风格有自己的默认布局，通用参数可覆盖）
"""
import argparse
import os

from PIL import Image, ImageDraw, ImageFont

W, H = 720, 1280

# ---------- 下载字体目录（2026-09-04 通用化）----------
# 换角色 / 换电脑时设环境变量 VP_FONTS_DIR 指向自己的字体目录；不设则回落牧子琪默认目录。
# ⚠️ fontconfig（C:\Users\user\fonts.conf）必须含同一目录的 <dir>，否则烧字幕会掉回微软雅黑。
FONTS_DIR = os.environ.get("VP_FONTS_DIR") or r"G:\牧子琪\fonts"

# ---------- 字体库（别名 → 文件）----------
# 系统字体 + 免费商用下载字体（全部确认可商用）
FONT_ALIASES = {
    # —— 系统自带 ——
    "yahei":      r"C:\Windows\Fonts\msyhbd.ttc",      # 微软雅黑 Bold（默认全能）
    "yahei-l":    r"C:\Windows\Fonts\msyh.ttc",        # 微软雅黑 常规（细）
    "simhei":     r"C:\Windows\Fonts\simhei.ttf",      # 黑体（笔画利落）
    "deng":       r"C:\Windows\Fonts\Dengb.ttf",       # 等线 Bold（几何现代）
    "kai":        r"C:\Windows\Fonts\simkai.ttf",      # 楷体（书卷手写）
    "song":       r"C:\Windows\Fonts\simsun.ttc",      # 宋体（衬线传统）
    "fangsong":   r"C:\Windows\Fonts\simfang.ttf",     # 仿宋（细瘦文艺）
    "noto-bold":  (r"C:\Windows\Fonts\NotoSansSC-VF.ttf", 700),   # 思源黑体 Bold（可变字重）
    "noto-black": (r"C:\Windows\Fonts\NotoSansSC-VF.ttf", 900),   # 思源黑体 Black（最粗）
    # —— 下载的免费商用美术字体（目录由 FONTS_DIR 决定，见文件头）——
    "douyin":     os.path.join(FONTS_DIR, "YouSheBiaoTiHei.ttf"),       # 优设标题黑（口播标题最主流）
    "ali-heavy":  os.path.join(FONTS_DIR, "AlibabaPuHuiTi-Heavy.ttf"),  # 阿里普惠体 Heavy（现代粗黑）
    "nanshen":    os.path.join(FONTS_DIR, "HuXiaoBoNanShenTi.otf"),     # 胡晓波男神体（综艺加粗）
    "zhenyan":    os.path.join(FONTS_DIR, "RuiziZhenYan.ttf"),          # 锐字真言体（抖音爆款综艺体）
    "smiley":     os.path.join(FONTS_DIR, "SmileySans-Oblique.ttf"),    # 得意黑（潮流斜体）
    # —— 思源宋体（Source Han Serif SC，SIL OFL 免费可商用；2026-09-16 晓君总定 s1 封面用）——
    "song-bold":  os.path.join(FONTS_DIR, "SourceHanSerifSC-Bold.otf"),   # 思源粗宋（晓君总 s1 现款）
    "song-heavy": os.path.join(FONTS_DIR, "SourceHanSerifSC-Heavy.otf"),  # 思源宋体 Heavy（更粗备选）
    # —— 毛笔/手写粗体（s12 荧光毛笔风，2026-10-14 起）——
    "dongfang":   os.path.join(FONTS_DIR, "AlimamaDongFangDaKai.ttf"),     # 阿里妈妈东方大楷（毛笔粗楷，s12 主用）
    "zhushi":     os.path.join(FONTS_DIR, "YangRenDongZhuShi-Heavy.ttf"),  # 杨任东竹石体 Heavy（备选毛笔）
    # —— GitHub 开源标题/封面字体（2026-10-14 新增，均免费可商用）——
    "douyin-sans": os.path.join(FONTS_DIR, "DouyinSansBold.ttf"),              # 抖音美好体 Bold（OFL，现代饱满黑）
    "shatter":     os.path.join(FONTS_DIR, "HowlShatteredDisplay-Regular.ttf"),# 嗷呜碎瘾黑（OFL，破碎爆裂超粗，潮流/警示向）
    "ximai":       os.path.join(FONTS_DIR, "ZiZhiQuXiMaiTi.ttf"),              # 字制区喜脉体（公益免费，≈文悦新青年体）
    "mantou":      os.path.join(FONTS_DIR, "MantouSans-Regular.ttf"),          # 馒头黑体（OFL，圆润厚重；⚠️简体缺字，慎用大字）
}

_cache = {}


def load_font(spec, size):
    """spec：字体别名或 ttf/ttc 路径；支持 Noto 可变字重"""
    key = (spec, size)
    if key in _cache:
        return _cache[key]
    if spec in FONT_ALIASES:
        v = FONT_ALIASES[spec]
        if isinstance(v, tuple):
            path, weight = v
            f = ImageFont.truetype(path, size, index=0)
            try:
                f.set_variation_by_axes([weight])
            except Exception:
                pass
        else:
            f = ImageFont.truetype(v, size, index=0)
    else:
        f = ImageFont.truetype(spec, size, index=0)
    _cache[key] = f
    return f


WHITE = (255, 255, 255, 255)
YELLOW = (247, 218, 9, 255)
GRAY = (74, 74, 74)
BLACK = (0, 0, 0, 255)
CYAN = (159, 243, 255, 255)      # #9FF3FF
NAVY = (26, 63, 120, 255)        # #1A3F78
BROWN = (91, 58, 30, 255)        # #5B3A1E
CREAM = (255, 246, 229)          # #FFF6E5
RED = (255, 77, 51, 255)         # #FF4D33
GOLD = (255, 209, 0, 255)        # #FFD100
EMERALD = (28, 227, 131, 255)    # #1CE383 荧光绿（s12 荧光毛笔强调色，参考图实测中位数）


# ---------- 通用工具 ----------

def fit_font(text, size, max_width, stroke, font="yahei"):
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    s = size
    while s >= 40:
        f = load_font(font, s)
        bbox = probe.textbbox((0, 0), text, font=f, stroke_width=stroke)
        if (bbox[2] - bbox[0]) <= max_width:
            return f, s
        s -= 2
    return load_font(font, 40), 40


def text_w(text, font, stroke):
    bbox = ImageDraw.Draw(Image.new("RGBA", (10, 10))).textbbox(
        (0, 0), text, font=font, stroke_width=stroke)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]


def draw_stroke_text(draw, xy, text, font, fill, stroke, shadow=None, shadow_alpha=140):
    if shadow:
        draw.text((xy[0] + shadow[0], xy[1] + shadow[1]), text, font=font,
                  fill=(0, 0, 0, shadow_alpha), stroke_width=stroke,
                  stroke_fill=(0, 0, 0, shadow_alpha))
    draw.text(xy, text, font=font, fill=fill, stroke_width=stroke, stroke_fill=(0, 0, 0, 255))


def render_italic_line(text, font, fill, stroke, shear=0.22, shadow=None, shadow_alpha=140):
    """渲染一行文字并做水平切变合成斜体（思源宋体等无斜体版时用）。

    返回 RGBA 图；调用方用 getbbox() 取实际内容框，再按需要的左上角对齐粘贴。
    shear>0 表示顶部向右倾斜（正向斜体）。
    """
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bbox = probe.textbbox((0, 0), text, font=font, stroke_width=stroke)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    # 预留切变溢出 + 描边 + 阴影的空间，避免被裁
    pad = int(abs(shear) * (th + 8)) + stroke + 12
    tmp = Image.new("RGBA", (tw + 2 * pad + 10, th + 2 * pad + 10), (0, 0, 0, 0))
    td = ImageDraw.Draw(tmp)
    ox = pad + 5 - bbox[0]
    oy = pad + 5 - bbox[1]
    if shadow:
        td.text((ox + shadow[0], oy + shadow[1]), text, font=font,
                fill=(0, 0, 0, shadow_alpha), stroke_width=stroke,
                stroke_fill=(0, 0, 0, shadow_alpha))
    td.text((ox, oy), text, font=font, fill=fill, stroke_width=stroke,
            stroke_fill=(0, 0, 0, 255))
    w2, h2 = tmp.size
    # 锚定底边：底部不动、越往上越右移（正向斜体）
    return tmp.transform((w2, h2), Image.AFFINE,
                         (1, shear, -shear * h2, 0, 1, 0), resample=Image.BICUBIC)


def gradient_banner(width, height, top_y, bottom_y, base, max_alpha=76):
    banner = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    px = banner.load()
    bh = bottom_y - top_y
    for y in range(bh):
        yratio = abs(y - bh / 2) / (bh / 2) if bh else 0
        yf = 1.0 - 0.40 * yratio
        for x in range(width):
            xratio = abs(x - width / 2) / (width / 2)
            xf = 1.0 - 0.55 * xratio
            a = int(max_alpha * yf * xf)
            px[x, top_y + y] = (base[0], base[1], base[2], max(0, min(255, a)))
    return banner


def rounded_rect(img, box, radius, color, alpha):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle(box, radius=radius, fill=color + (alpha,))
    return Image.alpha_composite(img, layer)


def darken(img, alpha):
    layer = Image.new("RGBA", img.size, (10, 14, 30, alpha))
    return Image.alpha_composite(img, layer)


# ---------- 5 款风格渲染 ----------

def style_s1(img, a, f1, f2, l1, l2):
    """爆款大字报：渐变灰横幅 + 白/亮黄 + 黑描边 + 左对齐中下部（牧子琪现款）

    支持 --italic（逐行切变合成斜体，思源宋体等无斜体版时用）。"""
    img = Image.alpha_composite(img, gradient_banner(W, H, a.top, a.bottom, GRAY))
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if getattr(a, "italic", False):
        shear = getattr(a, "italic_shear", 0.22)
        for text, font, fill, y in ((l1, f1, WHITE, a.y1), (l2, f2, YELLOW, a.y2)):
            line = render_italic_line(text, font, fill, a.stroke, shear, shadow=(4, 4))
            bb = line.getbbox()
            if bb:
                layer.alpha_composite(line, (a.left - bb[0], y - bb[1]))
    else:
        d = ImageDraw.Draw(layer)
        draw_stroke_text(d, (a.left, a.y1), l1, f1, WHITE, a.stroke, shadow=(4, 4))
        draw_stroke_text(d, (a.left, a.y2), l2, f2, YELLOW, a.stroke, shadow=(4, 4))
    return Image.alpha_composite(img, layer)


def style_s2(img, a, f1, f2, l1, l2):
    """杂志极简：无横幅、纯白大字左上、细黑描边、干净高级"""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    # 左上竖排细线装饰
    d.rectangle([(a.left - 14, a.y1 + 4), (a.left - 8, a.y2 + 78)], fill=YELLOW)
    draw_stroke_text(d, (a.left, a.y1), l1, f1, WHITE, a.stroke, shadow=(2, 2), shadow_alpha=110)
    draw_stroke_text(d, (a.left, a.y2), l2, f2, WHITE, a.stroke, shadow=(2, 2), shadow_alpha=110)
    return Image.alpha_composite(img, layer)


def style_s3(img, a, f1, f2, l1, l2):
    """综艺色块：斜切色块打底 + 白字粗黑边，贴纸感"""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    def block(x, y, w, h, color, skew=26):
        pts = [(x + skew, y), (x + w, y), (x + w - skew, y + h), (x, y + h)]
        d.polygon(pts, fill=color)

    w1, h1 = text_w(l1, f1, a.stroke)
    w2, h2 = text_w(l2, f2, a.stroke)
    y = a.y1 - 18
    block(a.left - 22, y, w1 + 56, h1 + 62, RED)
    block(a.left - 8, y + 12, w1 + 40, h1 + 40, GOLD)
    draw_stroke_text(d, (a.left + 8, a.y1), l1, f1, WHITE, a.stroke, shadow=(3, 3))
    y2b = a.y2 - 18
    block(a.left - 22, y2b, w2 + 56, h2 + 62, NAVY[:3])
    block(a.left - 8, y2b + 12, w2 + 40, h2 + 40, (60, 90, 200, 255)[:3])
    draw_stroke_text(d, (a.left + 8, a.y2), l2, f2, WHITE, a.stroke, shadow=(3, 3))
    return Image.alpha_composite(img, layer)


def style_s4(img, a, f1, f2, l1, l2):
    """暗夜科技：全屏压暗 + 青蓝发光字居中，无描边（AI/数字人主题）"""
    img = darken(img, 118)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    def center_line(text, font, fill, y, glow):
        w, _ = text_w(text, font, 0)
        x = (W - w) // 2
        # 发光：多层半透明同字重绘（柔光晕），主字无描边
        d.text((x, y), text, font=font, fill=(glow[0], glow[1], glow[2], 55),
               stroke_width=14, stroke_fill=(glow[0], glow[1], glow[2], 42))
        d.text((x, y), text, font=font, fill=(glow[0], glow[1], glow[2], 90),
               stroke_width=7, stroke_fill=(glow[0], glow[1], glow[2], 70))
        d.text((x, y), text, font=font, fill=fill)

    center_line(l1, f1, CYAN, a.y1, CYAN)
    center_line(l2, f2, WHITE, a.y2, CYAN)
    # 底部青色细线
    d.rectangle([(80, a.bottom + 16), (W - 80, a.bottom + 20)], fill=CYAN)
    return Image.alpha_composite(img, layer)


def style_s5(img, a, f1, f2, l1, l2):
    """奶油手账：奶油色圆角横幅 + 深棕字，无描边（小红书风）"""
    img = rounded_rect(img, (28, a.top, W - 28, a.bottom), 34, CREAM, 228)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.text((a.left, a.y1 - 46), "● AI 能干这事", font=load_font("yahei", 30), fill=RED)
    d.text((a.left, a.y1), l1, font=f1, fill=BROWN)
    d.text((a.left, a.y2), l2, font=f2, fill=BROWN)
    # 右下小圆点装饰
    for i, c in enumerate([RED, GOLD, (110, 180, 120, 255)]):
        d.ellipse([(W - 100 + i * 26, a.bottom - 30), (W - 86 + i * 26, a.bottom - 16)], fill=c)
    return Image.alpha_composite(img, layer)


def style_s6(img, a, f1, f2, l1, l2):
    """抖音主页风：两行居中、第一行白第二行亮黄、细黑描边轻投影、无横幅（复刻 牧子数智 现有封面）"""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    def center_line(text, font, fill, y):
        w, _ = text_w(text, font, a.stroke)
        x = (W - w) // 2
        # 轻投影 + 细黑描边
        d.text((x + 3, y + 3), text, font=font, fill=(0, 0, 0, 120),
               stroke_width=a.stroke, stroke_fill=(0, 0, 0, 120))
        d.text((x, y), text, font=font, fill=fill,
               stroke_width=a.stroke, stroke_fill=(0, 0, 0, 255))

    center_line(l1, f1, WHITE, a.y1)
    center_line(l2, f2, YELLOW, a.y2)
    return Image.alpha_composite(img, layer)


def style_s7(img, a, f1, f2, l1, l2):
    """标题条风：斜切底条反差配色（第一行白字黑条 / 第二行黑字黄条），优设标题黑"""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    def bar(x, y, w, h, color, skew=22):
        d.polygon([(x + skew, y), (x + w, y), (x + w - skew, y + h), (x, y + h)], fill=color)

    w1, h1 = text_w(l1, f1, 0)
    w2, h2 = text_w(l2, f2, 0)
    pad_x, pad_y = 30, 18
    bar(a.left - 14, a.y1 - pad_y, w1 + pad_x * 2 + 14, h1 + pad_y * 2 + 26, (20, 20, 24, 235))
    d.text((a.left + pad_x, a.y1), l1, font=f1, fill=WHITE)
    bar(a.left - 14, a.y2 - pad_y, w2 + pad_x * 2 + 14, h2 + pad_y * 2 + 26, YELLOW)
    d.text((a.left + pad_x, a.y2), l2, font=f2, fill=(18, 18, 18, 255))
    return Image.alpha_composite(img, layer)


def style_s8(img, a, f1, f2, l1, l2):
    """潮流斜体：轻暗化 + 得意黑大字居中无描边 + 黄色小方块角标"""
    img = darken(img, 88)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    # 左上角三格黄色马赛克角标
    for i in range(3):
        d.rectangle([(a.left, a.y1 - 150 + i * 26), (a.left + 52, a.y1 - 150 + i * 26 + 22)],
                    fill=YELLOW if i == 2 else (255, 209, 0, 140))
    # 第一行白、第二行黄，居中，无描边（得意黑自带斜度）
    for text, font, fill, y in [(l1, f1, WHITE, a.y1), (l2, f2, YELLOW, a.y2)]:
        w, _ = text_w(text, font, 0)
        d.text(((W - w) // 2, y), text, font=font, fill=fill)
    return Image.alpha_composite(img, layer)


def style_s9(img, a, f1, f2, l1, l2):
    """综艺撞色：白/黄字 + 黑粗边 + 错位实心色影（红/蓝），男神体"""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    dx, dy = 8, 8
    d.text((a.left + dx, a.y1 + dy), l1, font=f1, fill=RED, stroke_width=a.stroke,
           stroke_fill=RED)
    d.text((a.left, a.y1), l1, font=f1, fill=WHITE, stroke_width=a.stroke,
           stroke_fill=(0, 0, 0, 255))
    d.text((a.left + dx, a.y2 + dy), l2, font=f2, fill=(40, 90, 220, 255), stroke_width=a.stroke,
           stroke_fill=(40, 90, 220, 255))
    d.text((a.left, a.y2), l2, font=f2, fill=YELLOW, stroke_width=a.stroke,
           stroke_fill=(0, 0, 0, 255))
    return Image.alpha_composite(img, layer)


def style_s10(img, a, f1, f2, l1, l2):
    """商务渐变：底部深蓝渐变升起 + 白字左对齐 + 黄色竖条，普惠体"""
    grad = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = grad.load()
    gh = 520
    for i in range(gh):
        y = H - gh + i
        alpha = int(200 * (i / gh) ** 1.5)
        for x in range(W):
            px[x, y] = (10, 22, 48, alpha)
    img = Image.alpha_composite(img, grad)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rectangle([(a.left - 16, a.y1 - 8), (a.left - 6, a.y2 + 108)], fill=YELLOW)
    d.text((a.left + 8, a.y1), l1, font=f1, fill=WHITE)
    d.text((a.left + 8, a.y2), l2, font=f2, fill=YELLOW)
    return Image.alpha_composite(img, layer)


def style_s11(img, a, f1, f2, l1, l2):
    """真言炸场：黄字黑粗边 + 双层错位黑影，居中，冲击力最大"""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    def boom(text, font, y):
        w, _ = text_w(text, font, a.stroke)
        x = (W - w) // 2
        d.text((x + 10, y + 10), text, font=font, fill=(40, 40, 40, 200),
               stroke_width=a.stroke, stroke_fill=(40, 40, 40, 200))
        d.text((x + 5, y + 5), text, font=font, fill=(0, 0, 0, 255),
               stroke_width=a.stroke, stroke_fill=(0, 0, 0, 255))
        d.text((x, y), text, font=font, fill=YELLOW,
               stroke_width=a.stroke, stroke_fill=(0, 0, 0, 255))

    boom(l1, f1, a.y1)
    boom(l2, f2, a.y2)
    return Image.alpha_composite(img, layer)


def style_s12(img, a, f1, f2, l1, l2):
    """荧光毛笔：顶部双行、白字主句 + 荧光绿强调、毛笔粗体、顶部暗化、柔和暗影（无描边）

    复刻 @AI深度落地-海龙Allen 主页封面（2026-10-14 晓君总提供参考图）：
    文字压顶、白 + 荧光绿 #1CE383 双色、毛笔/手写粗体；靠暗影而非描边保证可读性；
    第二行下可选荧光绿刷笔横线（--no-underline 关闭）。"""
    # 顶部纵向暗化（上重下轻，到 a.bottom 归零）—— 保证任意底图都清晰
    if a.bottom and a.bottom > 0:
        grad = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        gpx = grad.load()
        region = int(a.bottom)
        for y in range(min(region, H)):
            alpha = int(148 * (1 - y / region) ** 1.3)
            for x in range(W):
                gpx[x, y] = (6, 10, 8, alpha)
        img = Image.alpha_composite(img, grad)

    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    def line(text, font, fill, y):
        # 柔和暗影（右下 3/5px、半透明）+ 主字（无描边）
        d.text((a.left + 3, y + 5), text, font=font, fill=(0, 0, 0, 150))
        d.text((a.left, y), text, font=font, fill=fill)

    line(l1, f1, WHITE, a.y1)
    line(l2, f2, EMERALD, a.y2)
    if getattr(a, "underline", True):
        fsize = getattr(f2, "size", 90)
        uy = int(a.y2 + fsize * 0.92) + 14
        uw = min(text_w(l2, f2, 0)[0], int(W * 0.36))
        d.rounded_rectangle([(a.left, uy), (a.left + uw, uy + 11)], radius=5, fill=EMERALD)
    return Image.alpha_composite(img, layer)


STYLES = {
    # name: (描述, 布局默认值, 推荐字体)
    # 🔴 2026-09-29 修正（根因）：原 font="douyin"（优设标题黑）与 profile 规范不符。
    #   xiaojunzong.json defaults.coverFont = "song-bold"，且 2026-09-16 起沿用
    #   「思源粗宋 + 斜体切变」；此前只传 `--style s1` 不传 `--font/--italic` 就会
    #   **静默**退回黑体直立字（脚本不报错、肉眼当天不一定看得出）——09-29 微云直剪
    #   封面即因此挂上优设标题黑、非斜体，被晓君总退回重做。默认值对齐规范：改一次，
    #   以后 `--style s1` 单参数就是对的。要黑体直立请显式 `--font douyin --no-italic`。
    "s1": dict(desc="爆款大字报（白+亮黄/黑描边/渐变横幅/思源粗宋斜体）",
               top=690, bottom=930, y1=708, y2=832, left=36, maxw=648, size1=92, size2=92, stroke=5,
               font="song-bold", italic=True),
    "s2": dict(desc="杂志极简（纯白左上/细描边）",
               top=0, bottom=0, y1=132, y2=258, left=52, maxw=600, size1=84, size2=84, stroke=3,
               font="smiley"),
    "s3": dict(desc="综艺色块（斜切色块/白字粗边）",
               top=0, bottom=0, y1=720, y2=880, left=60, maxw=560, size1=84, size2=84, stroke=6,
               font="nanshen"),
    "s4": dict(desc="暗夜科技（压暗/青蓝发光/无描边/居中）",
               top=0, bottom=940, y1=700, y2=826, left=36, maxw=648, size1=88, size2=88, stroke=0,
               font="ali-heavy"),
    "s5": dict(desc="奶油手账（奶油横幅/深棕字/无描边/小红书风）",
               top=660, bottom=960, y1=716, y2=836, left=64, maxw=560, size1=80, size2=80, stroke=0,
               font="zhenyan"),
    "s6": dict(desc="抖音主页风（白+黄两行居中/细黑描边，复刻牧子数智现有封面）",
               top=0, bottom=0, y1=640, y2=750, left=36, maxw=660, size1=78, size2=86, stroke=3,
               font="zhenyan"),
    # —— 2026-08-30 新字体 5 款 ——
    "s7": dict(desc="标题条风（黑条白字+黄条黑字斜切/优设标题黑）",
               top=0, bottom=0, y1=700, y2=830, left=44, maxw=560, size1=72, size2=76, stroke=0,
               font="douyin"),
    "s8": dict(desc="潮流斜体（轻暗化/得意黑大字居中/无描边）",
               top=0, bottom=0, y1=660, y2=790, left=48, maxw=624, size1=92, size2=92, stroke=0,
               font="smiley"),
    "s9": dict(desc="综艺撞色（白/黄字黑边+红蓝错位色影/男神体）",
               top=0, bottom=0, y1=690, y2=820, left=40, maxw=600, size1=80, size2=86, stroke=5,
               font="nanshen"),
    "s10": dict(desc="商务渐变（底部深蓝渐变/白+黄字/黄竖条/普惠体）",
                top=0, bottom=0, y1=820, y2=950, left=52, maxw=600, size1=72, size2=76, stroke=0,
                font="ali-heavy"),
    "s11": dict(desc="真言炸场（黄字黑粗边+双层错位黑影/居中）",
                top=0, bottom=0, y1=660, y2=790, left=36, maxw=648, size1=86, size2=92, stroke=4,
                font="zhenyan"),
    # 2026-10-14 新增：复刻 @AI深度落地-海龙Allen 主页封面（黑绿毛笔冲击）
    "s12": dict(desc="荧光毛笔（顶部双行/白+荧光绿/毛笔粗体/顶部暗化）",
                top=0, bottom=520, y1=150, y2=302, left=44, maxw=632, size1=88, size2=92, stroke=0,
                font="dongfang", underline=True),
}
RENDER = {"s1": style_s1, "s2": style_s2, "s3": style_s3, "s4": style_s4, "s5": style_s5,
          "s6": style_s6, "s7": style_s7, "s8": style_s8, "s9": style_s9, "s10": style_s10,
          "s11": style_s11, "s12": style_s12}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True, help="底图（建议取 part1 纯人物帧）")
    ap.add_argument("--line1", required=True)
    ap.add_argument("--line2", required=True)
    # 2026-09-04：默认 s7（9/3 晓君总拍板「封面和字幕就默认 s7+t6」），与 profile.defaults 一致
    ap.add_argument("--style", default="s7", choices=list(STYLES),
                    help="封面风格 s1-s12；默认 s7 标题条风。需要老样式请显式 --style s1")
    ap.add_argument("--out-png", required=True)
    ap.add_argument("--out-jpg", default=None)
    ap.add_argument("--font", default=None,
                    help="字体：别名 %s 或 ttf/ttc 路径；默认用各风格推荐字体" % "/".join(FONT_ALIASES))
    # 可覆盖布局的通用参数
    ap.add_argument("--top", type=int, default=None)
    ap.add_argument("--bottom", type=int, default=None)
    ap.add_argument("--y1", type=int, default=None)
    ap.add_argument("--y2", type=int, default=None)
    ap.add_argument("--left", type=int, default=None)
    ap.add_argument("--max-width", type=int, default=None)
    ap.add_argument("--stroke", type=int, default=None)
    # 2026-09-29：默认值改为「取风格自带值」——不入参则听 STYLES 的 italic（s1 已设为 True），
    # 显式 --italic 强制开、--no-italic 强制关。避免风格自带斜体被 store_true 的 False 静默覆盖。
    ap.add_argument("--italic", action="store_true", default=None,
                    help="文字斜体（逐行切变合成；思源宋体等无斜体版时用）；不传则用风格自带值")
    ap.add_argument("--no-italic", dest="italic", action="store_false",
                    help="强制关闭风格自带的斜体（如要 s1 的黑体直立字）")
    ap.add_argument("--underline", action="store_true", default=None,
                    help="第二行下的荧光绿刷笔横线（s12 自带 True）；不传则用风格自带值")
    ap.add_argument("--no-underline", dest="underline", action="store_false",
                    help="关闭 s12 的荧光绿横线")
    ap.add_argument("--italic-shear", type=float, default=0.30,
                    help="斜体切变强度，默认 0.30（明显可辨；<0.25 几乎看不出来）")
    args = ap.parse_args()

    st = dict(STYLES[args.style])
    st["italic"] = bool(st.get("italic", False)) if args.italic is None else args.italic
    st["italic_shear"] = args.italic_shear
    st["underline"] = bool(st.get("underline", False)) if args.underline is None else args.underline
    font_spec = args.font or st.get("font", "yahei")
    for k_json, k_arg in [("top", "top"), ("bottom", "bottom"), ("y1", "y1"), ("y2", "y2"),
                          ("left", "left"), ("maxw", "max_width"), ("stroke", "stroke")]:
        v = getattr(args, k_arg)
        if v is not None:
            st[k_json] = v

    img = Image.open(args.base).convert("RGBA")
    if img.size != (W, H):
        img = img.resize((W, H), Image.LANCZOS)

    maxw = st["maxw"]
    f1, s1_ = fit_font(args.line1, st["size1"], maxw, st["stroke"], font_spec)
    f2, s2_ = fit_font(args.line2, st["size2"], maxw, st["stroke"], font_spec)
    if abs(s1_ - s2_) > 12:
        print("WARN 两行字号差 >12px（%d/%d），建议每行 5-8 字更均衡" % (s1_, s2_))

    img = RENDER[args.style](img, argparse.Namespace(**st), f1, f2,
                             args.line1, args.line2)

    img.convert("RGB").save(args.out_png, "PNG", optimize=True)
    print("[%s %s] font %d/%d -> PNG %.1fKB" % (
        args.style, STYLES[args.style]["desc"], s1_, s2_, os.path.getsize(args.out_png) / 1024))

    if args.out_jpg:
        for q in (90, 84, 78, 72, 66, 60):
            img.convert("RGB").save(args.out_jpg, "JPEG", quality=q, optimize=True)
            kb = os.path.getsize(args.out_jpg) / 1024
            if kb < 512:
                print("JPG q=%d %.1fKB -> %s" % (q, kb, args.out_jpg))
                break
        else:
            print("WARN JPG 仍 >=512KB")


if __name__ == "__main__":
    main()
