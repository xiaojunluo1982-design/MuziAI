#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
牧子琪视频：part1 参考帧面部马赛克。

用途：part1 生成后抽清晰参考帧 -> 面部打码 -> 作为 part2+ 的「场景/服装/光线/构图」参考，
      面部统一以身份图 G:\\牧子琪\\牧子琪.jpeg 为准，防止面部逐段漂移。

Windows 注意：cv2 在 Python3.13 + OpenCV5 下 imread 中文路径会失败，脚本内部用 ASCII
临时目录做中转，调用方无需关心。

用法：
  python mosaic_face.py <src.jpg> <dst.jpg> [--rect x,y,w,h] [--blocks 16] [--extra-rect x,y,w,h]

  --rect        像素绝对矩形（默认自动按竖屏口播推算：画面宽 26%~74%、高 4%~38%）
  --blocks      马赛克块数，越大越糊（默认 16）
  --extra-rect  追加一个矩形（可重复），用于补码没盖住的五官区域
"""
import argparse
import os
import shutil
import sys
import tempfile

import cv2
import numpy as np


def pixelate(face, blocks=16):
    h, w = face.shape[:2]
    if h < 4 or w < 4:
        return face
    b = max(8, blocks)
    small = cv2.resize(face, (max(6, w // b), max(6, h // b)), interpolation=cv2.INTER_LINEAR)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)


def apply_rect(img, rect, blocks):
    h, w = img.shape[:2]
    x, y, rw, rh = [int(v) for v in rect]
    x = max(0, min(x, w - 1))
    y = max(0, min(y, h - 1))
    rw = max(1, min(rw, w - x))
    rh = max(1, min(rh, h - y))
    img[y:y + rh, x:x + rw] = pixelate(img[y:y + rh, x:x + rw], blocks)
    return (x, y, rw, rh)


def default_rect(h, w):
    """竖屏口播：脸固定在画面上方中央"""
    return (int(w * 0.26), int(h * 0.04), int(w * 0.48), int(h * 0.34))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--rect", default=None, help="x,y,w,h 像素绝对矩形")
    ap.add_argument("--blocks", type=int, default=16)
    ap.add_argument("--extra-rect", action="append", default=[], help="追加补码矩形 x,y,w,h，可重复")
    args = ap.parse_args()

    # ASCII 临时路径中转，规避 cv2 中文路径读取失败
    tmpdir = tempfile.mkdtemp(prefix="mzq_mosaic_")
    tmp_src = os.path.join(tmpdir, "src.jpg")
    tmp_dst = os.path.join(tmpdir, "dst.jpg")
    try:
        shutil.copyfile(args.src, tmp_src)
        img = cv2.imread(tmp_src)
        if img is None:
            print("ERR cannot read:", args.src)
            return 2
        h, w = img.shape[:2]

        rects = []
        if args.rect:
            rects.append([int(v) for v in args.rect.split(",")])
        else:
            rects.append(default_rect(h, w))
        for r in args.extra_rect:
            rects.append([int(v) for v in r.split(",")])

        applied = []
        for r in rects:
            applied.append(apply_rect(img, r, args.blocks))

        cv2.imwrite(tmp_dst, img)
        os.makedirs(os.path.dirname(os.path.abspath(args.dst)), exist_ok=True)
        shutil.copyfile(tmp_dst, args.dst)

        print("saved:", args.dst)
        print("size: %dx%d" % (w, h))
        for (x, y, rw, rh) in applied:
            print("mosaic_rect abs=(%d,%d,%d,%d) rel=(%.3f,%.3f,%.3f,%.3f)" %
                  (x, y, rw, rh, x / w, y / h, rw / w, rh / h))
        return 0
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
