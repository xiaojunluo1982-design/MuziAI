#!/usr/bin/env node
/**
 * plan_cut_by_words.js —— 文本驱动定剪点（真人实拍线通用）
 * （video-pipeline · 2026-10-15 从 xjz11 v3 实战固化）
 *
 * ⭐ 解决什么：手敲「秒数区间」的 KEEPS 有三个必踩的坑 ——
 *   ① 区间画粗 → 把「呃 / 嗯」这类口水词包进去（剪不干净）；
 *   ② 边界落在半个词组上 → 切掉「但是 / 发布到 / 帮我挑选出」这种半截话；
 *   ③ **气口加在段首**（seg.s = 句首 - pad）→ 段尾正好落在 ASR 的 word.end_time 上。
 *      而实测 **ASR 字级时间戳与真实音频有 0.05–0.38s 误差**（拿 silencedetect 对过：
 *      ASR 说 33.67 收声、实测静音 33.72；ASR 说 61.08 开口、实测 61.46）。
 *      段尾零余量 = 字尾的收音 / 换气被剃掉 → 听起来就是「正常的语气被剪了」。
 *
 * ⭐ 本脚本的规矩：
 *   · **逐字定界**：只删「整段连续的字」，保留区间一律由 `第 i 字起点 → 第 j 字终点` 生成，
 *     边界天生落在字缝上，不可能切进字里。
 *   · **气口加在段尾**：`seg.e = 末字 end + gap`。段尾多留 0.30–0.50s，字尾完整；
 *     句间静音长度 = 气口本身，一步到位，不再靠两段拼凑。
 *   · **长停顿断段**：相邻保留字之间静音 ≥ `--split-gap`（默认 0.60s）就断开成两段，
 *     否则长停顿会被吞进段内 —— 既不进气口计算，也会把字幕时间轴映射错。
 *
 * 用法：
 *   # ① 先看看有哪些候选（口水词 + 重复句块），人工确认后写 remove.json
 *   node plan_cut_by_words.js --in raw_asr.json --suggest
 *   # ② 出定剪点
 *   node plan_cut_by_words.js --in raw_asr.json --remove remove.json \
 *     --out-semantic semantic.json --out-segments segments.json --report cut_report.md
 *
 * remove.json 格式（闭区间字序号，来自 --suggest / 逐字表）：
 *   [{ "i": 144, "j": 144, "type": "filler", "why": "「呃」" },
 *    { "i": 90,  "j": 96,  "type": "falseStart", "why": "…下一句重说" }]
 *   也接受简写 [[90,96],[144,144]]
 *
 * 后续链路：build_join（吃 segments.json）→ trim_silence.py --speed <profile> --gap-min/--gap-max \
 *          --dump-keeps keeps.json → remap_asr_by_keeps.js --keeps keeps.json --segments segments.json \
 *          --semantic semantic.json → asr_to_ass.js → 烧字幕
 */
const fs = require('fs');
const path = require('path');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--')) {
    const k = process.argv[i].slice(2);
    args[k] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
  }
}
if (!args['in']) { console.error('ERR 缺 --in <raw_asr.json>'); process.exit(2); }

// ---- 参数 ----------------------------------------------------------------
const GAP_FACTOR = Number(args['gap-factor'] || 0.6);
const GAP_MIN = Number(args['gap-min'] || 0.30);
const GAP_MAX = Number(args['gap-max'] || 0.50);
const GAP_SAFE = Number(args['gap-safe'] || 0.10);
const SPLIT_GAP = Number(args['split-gap'] || 0.60);
const HEAD_LEAD = Number(args['head-lead'] || 0.75);   // trim_silence --edge 会把贴边 0.30s 再裁掉
const TAIL_LEAD = Number(args['tail-lead'] || 0.75);
const FILLERS = ['呃', '嗯', '额', '唔', '诶'];
const SUGGEST = !!args['suggest'];

// ---- 读逐字表 -------------------------------------------------------------
const raw = JSON.parse(fs.readFileSync(args['in'], 'utf8'));
const W = [];
for (const u of raw.result.utterances) {
  for (const w of (u.words || [])) {
    if (w.text.trim() === '') continue;
    W.push({ t: w.text, s: w.start_time / 1000, e: w.end_time / 1000 });
  }
}

// ---- 短语块（按 ≥0.25s 停顿切）------------------------------------------
const blocks = [];
let cur = null;
for (let k = 0; k < W.length; k++) {
  if (!cur || W[k].s - cur.e >= 0.25) { cur = { s: W[k].s, e: W[k].e, from: k, to: k, t: W[k].t }; blocks.push(cur); }
  else { cur.e = W[k].e; cur.to = k; cur.t += W[k].t; }
}

// ---- --suggest：候选（口水词 + 重复句块）----------------------------------
if (SUGGEST) {
  console.log('逐字 ' + W.length + ' 字 / 短语块 ' + blocks.length + ' 个\n');
  console.log('== A. 口水词候选（filler，**逐字**扫 —— 呃 常被 ASR 粘进下一个词，按块扫会漏）==');
  let nf = 0;
  for (let k = 0; k < W.length; k++) {
    const t = W[k].t.trim();
    if (t && FILLERS.includes(t)) {
      console.log(`  删 [${k}-${k}] ${W[k].s.toFixed(2)}-${W[k].e.toFixed(2)} 「${t}」`); nf++;
    }
  }
  if (!nf) console.log('  （无）');
  console.log('\n== B. 口误重来候选（falseStart：后一个块以前一个块开头/包含）==');
  let ns = 0;
  for (let a = 0; a < blocks.length; a++) {
    for (let b = a + 1; b < blocks.length && blocks[b].s - blocks[a].e < 6.0; b++) {
      const A = blocks[a].t, B = blocks[b].t;
      const head = A.slice(0, Math.min(3, A.length));
      if (B.startsWith(head) || (A.length >= 2 && B.includes(A)) || (/^[^，。]{2,4}$/.test(A) && B.includes(A))) {
        console.log(`  删 [${blocks[a].from}-${blocks[a].to}] ${blocks[a].s.toFixed(2)}「${A}」 → 保留 ${blocks[b].s.toFixed(2)}「${B}」`);
        ns++; break;
      }
    }
  }
  if (!ns) console.log('  （无）');
  console.log('\n== C. 逐字表（写 remove.json 用）==');
  blocks.forEach((b, i) => console.log(`  #${String(i).padStart(2)} [${String(b.from).padStart(3)}-${String(b.to).padStart(3)}] ${b.s.toFixed(2)}-${b.e.toFixed(2)} 「${b.t}」`));
  process.exit(0);
}

for (const k of ['remove', 'out-semantic', 'out-segments']) {
  if (!args[k]) { console.error('ERR 缺 --' + k); process.exit(2); }
}

// ---- 删除清单 -------------------------------------------------------------
let rm = JSON.parse(fs.readFileSync(args['remove'], 'utf8'));
rm = rm.map((r) => Array.isArray(r) ? { i: r[0], j: r[1], type: 'manual', why: '' } : r);
const removed = new Array(W.length).fill(null);
for (const r of rm) for (let k = r.i; k <= r.j; k++) removed[k] = r;

// ---- 保留区间 -------------------------------------------------------------
const spans = [];
let c2 = null;
for (let k = 0; k < W.length; k++) {
  if (removed[k]) { c2 = null; continue; }
  if (!c2 || W[k].s - c2.e >= SPLIT_GAP) { c2 = { s: W[k].s, e: W[k].e, from: k, to: k }; spans.push(c2); }
  else { c2.e = W[k].e; c2.to = k; }
}

// ---- 段 + 段尾气口 --------------------------------------------------------
const segs = spans.map((g, i) => {
  const last = i === spans.length - 1;
  let gap = TAIL_LEAD, avail = null;
  if (!last) {
    avail = spans[i + 1].s - g.e;
    gap = +Math.max(0, Math.min(Math.max(avail * GAP_FACTOR, GAP_MIN), GAP_MAX, avail - GAP_SAFE)).toFixed(3);
  }
  return {
    s: +(i === 0 ? Math.max(0, g.s - HEAD_LEAD) : g.s).toFixed(3),
    e: +(g.e + gap).toFixed(3),
    gap,
    raw: [+g.s.toFixed(3), +g.e.toFixed(3)],
    avail: avail == null ? null : +avail.toFixed(3),
  };
});

const semantic = spans.map((g) => [+g.s.toFixed(3), +g.e.toFixed(3)]);
fs.writeFileSync(args['out-semantic'], JSON.stringify(semantic, null, 1), 'utf8');
fs.writeFileSync(args['out-segments'], JSON.stringify(segs, null, 1), 'utf8');

// ---- 对照表 --------------------------------------------------------------
if (args['report']) {
  const L = ['# 定剪点对照表（文本驱动 / 逐字定界）', '',
    `逐字 ${W.length} 字 → 保留 ${W.length - removed.filter(Boolean).length} / 删 ${removed.filter(Boolean).length}`, '',
    '## 一、删掉的', '', '| 类型 | 时间 | 文字 | 依据 |', '|---|---|---|---|'];
  for (const r of rm) L.push(`| ${r.type} | ${W[r.i].s.toFixed(2)}–${W[r.j].e.toFixed(2)} | ${W.slice(r.i, r.j + 1).map((w) => w.t).join('')} | ${r.why || ''} |`);
  L.push('', '## 二、保留的（气口在本段尾部）', '', '| # | 区间 | 段尾气口 | 原停顿 | 文字 |', '|---|---|---|---|---|');
  segs.forEach((g, i) => {
    const txt = W.slice(spans[i].from, spans[i].to + 1).map((w) => w.t).join('');
    L.push(`| ${String(i).padStart(2)} | ${g.raw[0].toFixed(2)}–${g.raw[1].toFixed(2)} | ${i === segs.length - 1 ? '(片尾)' : '+' + g.gap.toFixed(2)} | ${g.avail == null ? '—' : g.avail.toFixed(2)} | ${txt} |`);
  });
  const speech = spans.reduce((a, g) => a + (g.e - g.s), 0);
  const gapTotal = segs.slice(0, -1).reduce((a, g) => a + g.gap, 0);
  L.push('', `合计：语音 ${speech.toFixed(2)}s + 气口 ${gapTotal.toFixed(2)}s = 拼接 ${(speech + gapTotal).toFixed(2)}s`);
  fs.writeFileSync(args['report'], L.join('\n'), 'utf8');
}

const speech = spans.reduce((a, g) => a + (g.e - g.s), 0);
const gapTotal = segs.slice(0, -1).reduce((a, g) => a + g.gap, 0);
console.log(`段数 ${segs.length}｜保留 ${W.length - removed.filter(Boolean).length} 字 / 删 ${removed.filter(Boolean).length} 字`);
console.log(`语音 ${speech.toFixed(2)}s + 气口 ${gapTotal.toFixed(2)}s = 拼接 ${(speech + gapTotal).toFixed(2)}s`);
console.log('气口序列：' + segs.slice(0, -1).map((g) => g.gap.toFixed(2)).join(' '));
