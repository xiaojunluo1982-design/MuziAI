#!/usr/bin/env node
/**
 * 把本地文件上传到 ima 知识库的 COS 暂存位。
 *
 * 背景：ima 入库是三步 ——
 *   1) MCP `create_media`  → 返回 media_id + cos_credential（临时密钥，约 12h）
 *   2) 用 cos_credential 把文件 PUT 到 COS   ← 本脚本负责这一步
 *   3) MCP `add_knowledge`（带 media_id + folder_id）→ 真正入库
 * MCP 那两步只能由 Agent 调（走连接器），中间这一步是纯 HTTP，所以固化成脚本。
 *
 * 用法：
 *   node ima_upload_cos.js <本地文件> <cos_credential.json>
 *   cos_credential.json = create_media 返回值的整体或只含 cos_credential 的对象
 *
 * 输出：成功打印 `OK <etag> <bytes>` 与 exit 0；失败打印 FAIL 原因与 exit 1。
 * ⚠️ 绝不回显 secret_id / secret_key / token。
 */
const fs = require('fs');
const crypto = require('crypto');

const [file, credPath] = process.argv.slice(2);
if (!file || !credPath) { console.error('用法: node ima_upload_cos.js <本地文件> <cos_credential.json>'); process.exit(2); }
if (!fs.existsSync(file)) { console.error('FAIL 本地文件不存在: ' + file); process.exit(1); }
if (!fs.existsSync(credPath)) { console.error('FAIL 凭证文件不存在: ' + credPath); process.exit(1); }

let cred;
try {
  const j = JSON.parse(fs.readFileSync(credPath, 'utf8'));
  cred = j.cos_credential || j;
} catch (e) { console.error('FAIL 凭证 JSON 解析失败: ' + e.message); process.exit(1); }
for (const k of ['secret_id', 'secret_key', 'token', 'bucket_name', 'region', 'cos_key']) {
  if (!cred[k]) { console.error(`FAIL 凭证缺字段: ${k}`); process.exit(1); }
}

const MIME = {
  md: 'text/markdown', txt: 'text/plain', json: 'application/json', csv: 'text/csv',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
  mp4: 'video/mp4', mov: 'video/quicktime', pdf: 'application/pdf',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  html: 'text/html'
};
const ext = (file.split('.').pop() || '').toLowerCase();
const contentType = MIME[ext] || 'application/octet-stream';

const host = `${cred.bucket_name}.cos.${cred.region}.myqcloud.com`;
const uriPath = '/' + String(cred.cos_key).replace(/^\/+/, '');
const body = fs.readFileSync(file);
const now = Math.floor(Date.now() / 1000);
const keyTime = `${now};${now + 3600}`;

// ---- COS V5 签名（sha1）----
const sha1 = s => crypto.createHash('sha1').update(s).digest('hex');
const hmac = (key, s) => crypto.createHmac('sha1', key).update(s).digest('hex');
const signKey = hmac(cred.secret_key, keyTime);
const headerList = 'content-type;host';
const httpHeaders = `content-type=${encodeURIComponent(contentType)}&host=${encodeURIComponent(host)}`;
const httpString = `put\n${uriPath}\n\n${httpHeaders}\n`;
const stringToSign = `sha1\n${keyTime}\n${sha1(httpString)}\n`;
const signature = hmac(signKey, stringToSign);
const authorization =
  `q-sign-algorithm=sha1&q-ak=${cred.secret_id}&q-sign-time=${keyTime}&q-key-time=${keyTime}` +
  `&q-header-list=${headerList}&q-url-param-list=&q-signature=${signature}`;

(async () => {
  const url = `https://${host}${uriPath}`;
  let res;
  try {
    res = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': contentType,
        'Content-Length': String(body.length),
        'x-cos-security-token': cred.token,
        Authorization: authorization
      },
      body
    });
  } catch (e) {
    console.error('FAIL 网络错误: ' + e.message); process.exit(1);
  }
  if (res.ok) {
    const etag = res.headers.get('etag') || '(no etag)';
    console.log(`OK ${etag} ${body.length} bytes -> ${uriPath}`);
    console.log('下一步：MCP add_knowledge { knowledge_base_id, folder_id, media_id }');
  } else {
    const t = await res.text().catch(() => '');
    console.error(`FAIL HTTP ${res.status} ${res.statusText}\n${t.slice(0, 500)}`);
    process.exit(1);
  }
})();
