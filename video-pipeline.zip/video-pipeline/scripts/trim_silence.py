#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
口播视频剪辑修整：去段首尾空白 + 处理段内停顿（气口）。

依据（2026-09-16 晓君总指令，固化进 SKILL.md Step 8.5）：
  剪辑时默认检查并去除「重复语句、停顿、空白、气口」。
  - 停顿/空白/气口：本脚本自动处理（silencedetect 检测 -> 裁剪时间线 -> trim+concat）
  - 重复语句：无法可靠自动检测（需转写），AI 生成段台词来自定稿文案一般无重复；
    真人原声素材在送审环节人工确认，有口误重复则剪掉后再进本脚本。

用法：
  python trim_silence.py <in.mp4> <out.mp4> [--noise -35] [--edge 0.3] [--speed 1.1]
                         # 🔴 旧口径（legacy 双窗口，仅 即梦生成段 沿用）
                         [--min-dur 0.55] [--max-pause 0.6] [--keep-pause 0.42]
                         # 🔴 新口径（气口语义，实拍线用；给 gap-min/gap-max 即启用）
                         [--gap-min 0.30] [--gap-max 0.50] [--min-dur 0.30]

━━ 两套静音处置语义（⚠️ 二选一，给 gap 参数 = 新口径） ━━

【新】气口语义（2026-10-14 晓君总三次反馈后落定 · 🔴 晓君总实拍线当前唯一口径）
  原话：「气口剪得太多，语句之前太紧了，**可以尝试在每句话前留 0.3-0.5 秒**，语速放到 1.1 倍。」
  规则：**每个被检测到的静音**（≥ `--min-dur`）保留 `clamp(时长, gap-min, gap-max)` 秒，
        **锚在静音尾部**（贴着下一句的起点 = 他"换气准备开口"那几帧），**不再整段删除**。
  效果：句与句之间恒定留 0.30-0.50s 气口，长停顿（比划不出声）压到 0.50s 上限。
  ⇒ 实拍线调用：`--speed 1.1 --min-dur 0.30 --gap-min 0.30 --gap-max 0.50 --edge 0.30`

【旧】legacy 双窗口语义（默认，即梦**生成**段沿用 —— 生成段有定稿文案卡时长，不能变长）
  · 只有 ≥ `--min-dur` 的静音被处理；
  · dur > `--max-pause` → 只保留开头 `--keep-pause` 秒；
  · `min-dur` ~ `max-pause` 之间的静音 → **整段删除**。

⚠️ **参数语义（易记反，2026-10-06 读源码确认）**：
  旧口径下 `--min-dur` 是主控 —— 调大 = 少删 = 更宽松；`--max-pause` **调大反而更紧**
  （更多静音落进「全删窗口」）。新口径没有这个反直觉窗口，`gap-min/gap-max` 就是字面意思。

━━ 历史口径（供追溯，⛔ 不得据此出片） ━━
  · 09-29 `min-dur 0.32 / max-pause 0.45 / keep-pause 0.18 / edge 0.12`（紧）
  · 10-05 `0.45 / 0.65 / 0.32 / 0.25`（第一次放宽，已作废）
  · 10-06 `0.55 / 0.60 / 0.42 / 0.30`（第二次放宽，实拍线已作废）
  · 10-14 **新口径 = 气口语义 0.30–0.50 + 1.1x**（当前）

参数：
  --noise       静音判定阈值 dB（默认 -35）
  --min-dur     最短静音时长，低于此的停顿完全不动（默认 0.55；新口径传 0.30）
  --gap-min     新口径：气口下限（默认 0.30）
  --gap-max     新口径：气口上限（默认 0.50）
  --max-pause   旧口径：段内静音超过此长度视为「超长停顿」（默认 0.6s）
  --keep-pause  旧口径：超长停顿压缩后保留的长度（默认 0.42s）
  --edge        段首尾静音各保留的余量（默认 0.3s）
  --speed       整体倍速（默认 1.0 = 不变速）。
                🔴 晓君总**实拍**素材默认 **1.1**（2026-10-14 指令，**覆盖** 09-29 的 1.2、09-26 的 1.3），
                调用侧显式传 `--speed 1.1`：
                视频 `setpts=PTS/speed`、音频 `atempo=speed` —— **atempo 保音调，不变成尖声**。
                ⚠️ 即梦**生成**段（Step 7.5 对 partN 的常规修整）**一律不变速**，用默认 1.0。
                范围 0.5-100（atempo 单次限制）。

无静音需处理且 speed=1.0 时直接 copy 流输出（不动画面，不重编码）。
**speed≠1.0 时一律重编码**（copy 无法改时间戳/采样）。
"""
import argparse
import os
import re
import subprocess
import sys

FFMPEG = os.environ.get("VP_FFMPEG", r"C:\Users\admin\.workbuddy\bin\ffmpeg\bin\ffmpeg.exe")


def detect_silences(path, noise, min_dur):
    """返回 [(start, end), ...] 静音区间（秒）。"""
    cmd = [FFMPEG, "-i", path, "-af",
           "silencedetect=noise=%sdB:d=%s" % (noise, min_dur),
           "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    log = p.stderr or ""
    starts = [float(m) for m in re.findall(r"silence_start:\s*([\d.]+)", log)]
    ends_durs = re.findall(r"silence_end:\s*([\d.]+)\s*\|\s*silence_duration:\s*([\d.]+)", log)
    ends = [float(e) for e, _d in ends_durs]
    # silence_start 可能多于 end（音频在静音中结束）
    out = []
    for i, s in enumerate(starts):
        e = ends[i] if i < len(ends) else None
        out.append((s, e))
    return out, log


def media_duration(path):
    p = subprocess.run([FFMPEG, "-i", path], capture_output=True, text=True, timeout=120)
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", p.stderr or "")
    if not m:
        return None
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


def media_fps(path):
    """取源视频帧率（提速后按 fps*speed 输出，避免压帧发顿）。"""
    p = subprocess.run([FFMPEG, "-i", path], capture_output=True, text=True, timeout=120)
    m = re.search(r"([\d.]+)\s*fps", p.stderr or "")
    try:
        return float(m.group(1)) if m else None
    except ValueError:
        return None


def build_keep_ranges(silences, total, max_pause, keep_pause, edge, gap=None):
    """构建保留区间 [(start, end)]。

    gap=(gap_min, gap_max) -> 气口语义：每个静音保留 clamp(dur, gap_min, gap_max)，
                              锚在**静音尾部**（气口贴着下一句起点）。
    gap=None               -> legacy 双窗口语义：超长压缩到 keep_pause，其余整段删除。
    两种情况都做首尾余量裁剪（edge）。
    """
    if total is None:
        return None
    keeps = []
    cur = 0.0
    for (s, e) in silences:
        e_eff = e if e is not None else total
        if e_eff <= s:
            continue
        if s > cur:
            keeps.append((cur, s))
        # 静音段处理
        dur = e_eff - s
        if gap is not None:
            gmin, gmax = gap
            keep_len = min(max(dur, gmin), gmax, dur)   # 短于 gmin 的静音无法拉长，原样留
            keeps.append((e_eff - keep_len, e_eff))     # 锚尾：贴着下一句
        else:
            if dur > max_pause:
                # 压缩：保留开头 keep_pause（换气感），把中间多余部分裁掉
                keeps.append((s, s + keep_pause))
        cur = e_eff
    if cur < total:
        keeps.append((cur, total))
    # 首尾余量裁剪
    trimmed = []
    for (s, e) in keeps:
        s2 = s if s > 0.01 else edge
        e2 = e if e < total - 0.01 else total - edge
        if e2 - s2 > 0.1:
            trimmed.append((max(0.0, s2), min(total, e2)))
    # 合并重叠/相邻
    merged = []
    for seg in trimmed:
        if merged and seg[0] <= merged[-1][1] + 0.01:
            merged[-1] = (merged[-1][0], max(merged[-1][1], seg[1]))
        else:
            merged.append(seg)
    return merged


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--noise", default="-35")
    ap.add_argument("--min-dur", default="0.55")
    ap.add_argument("--max-pause", type=float, default=0.6)
    ap.add_argument("--keep-pause", type=float, default=0.42)
    ap.add_argument("--gap-min", type=float, default=None,
                    help="新口径气口下限（秒）；给了 gap-min 或 gap-max 即启用气口语义")
    ap.add_argument("--gap-max", type=float, default=None,
                    help="新口径气口上限（秒）")
    ap.add_argument("--edge", type=float, default=0.3)
    ap.add_argument("--speed", type=float, default=1.0,
                    help="整体倍速；晓君总实拍默认 1.1（调用侧显式传），生成段保持 1.0")
    ap.add_argument("--dump-keeps", default=None,
                    help="把实际保留区间写成 JSON 到该路径（供字幕时间轴重映射用；"
                         "⛔ 重剪后必须重做/重映射字幕，见 SKILL §2B.12）")
    ap.add_argument("--head-tail-only", action="store_true",
                    help="只裁段首尾空白，段内停顿/气口一律不动（2026-10-19 晓君总指令："
                         "即梦数字人线不再剪气口，保留自然呼吸感）")
    args = ap.parse_args()

    # 气口语义开关（2026-10-14 新增）
    gap = None
    if args.head_tail_only:
        # 2026-10-19 晓君总指令：即梦数字人线「不用剪气口」
        # 只裁片首/片尾空白，段内任何停顿原样保留；检测阈值放松到 0.15s 才抓得到片头留白
        try:
            if float(args.min_dur) > 0.15:
                args.min_dur = "0.15"
        except ValueError:
            args.min_dur = "0.15"
        print("[MODE] head-tail-only：只裁首尾空白，段内气口/停顿一律不动（不剪气口）")
    elif args.gap_min is not None or args.gap_max is not None:
        gmin = args.gap_min if args.gap_min is not None else 0.30
        gmax = args.gap_max if args.gap_max is not None else 0.50
        if gmax < gmin:
            print("ERR --gap-max(%s) 小于 --gap-min(%s)" % (gmax, gmin))
            return 2
        gap = (gmin, gmax)
        # 气口语义下 min-dur 默认跟着降到 gmin（0.55 会把正常句间停顿漏掉 → 等于没留气口）
        if args.min_dur == "0.55":
            args.min_dur = "%.2f" % gmin
            print("[INFO] 气口语义：--min-dur 自动设为 %s（原默认 0.55 会漏掉正常句间停顿）" % args.min_dur)
        print("[MODE] 气口语义：每个静音保留 clamp(dur, %.2f, %.2f)s，锚尾" % gap)
    else:
        print("[MODE] legacy 双窗口：min-dur %s / max-pause %s / keep-pause %s"
              % (args.min_dur, args.max_pause, args.keep_pause))

    # 防呆（2026-10-07 r68 实测踩到）：dst 不带扩展名 → ffmpeg 报
    # 「Unable to choose an output format for 'body'」，且**静音分析已经跑完**才发现，白等一轮。
    # 调用侧口径写的是 `trim_silence.py <拼接片> <body>`，容易被照抄成不带 .mp4 → 这里自动补。
    if not os.path.splitext(args.dst)[1]:
        args.dst = args.dst + ".mp4"
        print("[WARN] dst 未带扩展名，已自动补为 %s" % args.dst)

    if not (0.5 <= args.speed <= 100.0):
        print("ERR --speed 超出 atempo 单次可用范围 0.5-100，当前 %s" % args.speed)
        return 2
    speed_on = abs(args.speed - 1.0) > 1e-6

    if not os.path.exists(args.src):
        print("ERR not found:", args.src)
        return 2

    total = media_duration(args.src)
    silences, _log = detect_silences(args.src, args.noise, args.min_dur)

    if args.head_tail_only:
        # ── 2026-10-19 晓君总指令：即梦数字人线「不用剪气口」──────────────────
        # 只裁片首/片尾大段空白（各留 edge 余量），**段内任何停顿一律不动**。
        # 取「片头连续静音的结束点」/「片尾连续静音的起点」，不是固定裁 edge 秒。
        total = total or media_duration(args.src) or 0.0
        head_cut, tail_cut = 0.0, total
        for (s, e) in silences:
            ee = e if e is not None else total
            if s <= 0.05:
                head_cut = max(0.0, ee - args.edge)
            elif ee >= total - 0.05:
                tail_cut = min(total, s + args.edge)
        keep_len = tail_cut - head_cut
        if keep_len <= 0.3:
            print("[WARN] head-tail 裁完只剩 %.2fs，放弃裁剪改为全片" % keep_len)
            head_cut, tail_cut = 0.0, total
        print("首尾空白：片头静音 %.2fs / 片尾静音 %.2fs → 裁到 %.2f-%.2fs（段内停顿 0 处改动）"
              % (head_cut, total - tail_cut, head_cut, tail_cut))
        if not speed_on and head_cut <= 0.02 and (total - tail_cut) <= 0.02:
            subprocess.run([FFMPEG, "-y", "-v", "error", "-i", args.src,
                            "-c", "copy", args.dst], check=True, timeout=600)
            print("首尾无空白可裁，直接 copy ->", args.dst)
            return 0
        fc = ("[0:v]trim=start=%.3f:end=%.3f,setpts=PTS-STARTPTS[v];"
              "[0:a]atrim=start=%.3f:end=%.3f,asetpts=PTS-STARTPTS[a]"
              % (head_cut, tail_cut, head_cut, tail_cut))
        vmap, amap, rate_args = "[v]", "[a]", ["-r", "60"]
        if speed_on:
            fc += ";[v]setpts=PTS/%.6f[vout];[a]atempo=%.6f[aout]" % (args.speed, args.speed)
            vmap, amap = "[vout]", "[aout]"
            fps = media_fps(args.src)
            rate_args = ["-r", "%.3f" % (fps * args.speed)] if fps else []
        cmd = [FFMPEG, "-y", "-v", "error", "-i", args.src,
               "-filter_complex", fc, "-map", vmap, "-map", amap,
               "-c:v", "libx264", "-crf", "18", "-preset", "medium"] + rate_args + [
               "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", args.dst]
        subprocess.run(cmd, check=True, timeout=1800)
        print("已输出（head-tail-only）-> %s  %.2fs  %d bytes"
              % (args.dst, keep_len, os.path.getsize(args.dst)))
        return 0

    if gap is not None:
        # 气口语义：只有「比 gap-max 还长」的静音会被缩短（其余原样/补齐下限）
        long_pauses = [s for (s, e) in silences
                       if (e if e is not None else (total or 0)) - s > gap[1]]
    else:
        long_pauses = [s for (s, e) in silences
                       if (e if e is not None else (total or 0)) - s > args.max_pause]
    print("时长 %.2fs | 静音段 %d 个（需压缩的 %d 个）"
          % (total or -1, len(silences), len(long_pauses)))

    if not long_pauses:
        # 无超长停顿：只做首尾余量裁剪（若首尾本身有静音）
        keeps = build_keep_ranges(silences, total, args.max_pause, args.keep_pause, args.edge, gap)
        # keeps 与全片几乎一致、且不变速时可直接 copy
        if (not speed_on) and keeps and abs(keeps[0][0] - 0) <= args.edge + 0.01 and abs(keeps[-1][1] - (total or 0)) <= args.edge + 0.01:
            subprocess.run([FFMPEG, "-y", "-v", "error", "-i", args.src,
                            "-c", "copy", args.dst], check=True, timeout=600)
            print("无需压缩停顿，直接 copy ->", args.dst)
            return 0

    keeps = build_keep_ranges(silences, total, args.max_pause, args.keep_pause, args.edge, gap)
    if not keeps:
        print("ERR 无法确定时长/区间")
        return 2
    cut_total = sum(e - s for s, e in keeps)
    print("裁剪后预计时长 %.2fs（去 %.2fs）" % (cut_total, (total or 0) - cut_total))
    if args.dump_keeps:
        import json as _json
        with open(args.dump_keeps, "w", encoding="utf-8", newline="\n") as fh:
            _json.dump({"src": os.path.basename(args.src), "total": total,
                        "speed": args.speed, "mode": ("gap" if gap is not None else "legacy"),
                        "gap": gap, "min_dur": args.min_dur, "edge": args.edge,
                        "keeps": [[round(s, 4), round(e, 4)] for s, e in keeps]},
                       fh, ensure_ascii=False, indent=1)
        print("保留区间已写出 ->", args.dump_keeps)
    if gap is not None:
        print("气口：保留段 %d 段，句间气口目标 %.2f-%.2fs" % (len(keeps), gap[0], gap[1]))
    if speed_on:
        print("整体提速 %.2fx -> 成片预计 %.2fs" % (args.speed, cut_total / args.speed))

    # trim+concat 滤镜链
    parts_v, parts_a, concat_in = [], [], []
    for i, (s, e) in enumerate(keeps):
        parts_v.append("[0:v]trim=start=%.3f:end=%.3f,setpts=PTS-STARTPTS[v%d]" % (s, e, i))
        parts_a.append("[0:a]atrim=start=%.3f:end=%.3f,asetpts=PTS-STARTPTS[a%d]" % (s, e, i))
        concat_in.append("[v%d][a%d]" % (i, i))
    fc = ";".join(parts_v + parts_a) + ";" + "".join(concat_in) + "concat=n=%d:v=1:a=1[v][a]" % len(keeps)

    vmap, amap = "[v]", "[a]"
    rate_args = ["-r", "60"]
    if speed_on:
        # 视频缩时间戳提速；音频 atempo 保音调（人声不会变尖）
        fc += ";[v]setpts=PTS/%.6f[vout];[a]atempo=%.6f[aout]" % (args.speed, args.speed)
        vmap, amap = "[vout]", "[aout]"
        # 提速后等效帧率变高：不硬压 60，保住所有帧（压帧会顿）
        fps = media_fps(args.src)
        if fps:
            rate_args = ["-r", "%.3f" % (fps * args.speed)]
            print("源 %.3f fps -> 输出 %.3f fps" % (fps, fps * args.speed))
        else:
            rate_args = []

    cmd = [FFMPEG, "-y", "-v", "error", "-i", args.src,
           "-filter_complex", fc, "-map", vmap, "-map", amap,
           "-c:v", "libx264", "-crf", "18", "-preset", "medium"] + rate_args + [
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", args.dst]
    subprocess.run(cmd, check=True, timeout=1800)
    print("已输出 ->", args.dst, os.path.getsize(args.dst), "bytes")
    return 0


if __name__ == "__main__":
    sys.exit(main())
