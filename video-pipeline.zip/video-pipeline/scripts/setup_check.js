#!/usr/bin/env node
/**
 * 使用前自检（账号无关）：确认 profile / 素材 / 凭证 / 环境都配好了。
 *
 * 目的：把「使用前必须完成的配置清单」变成可执行拦截——没配好就不让开工，
 * 而不是跑到一半（生成了一半、烧完字幕）才发现字体不对 / 账号离线 / 身份图没放。
 *
 * 用法：
 *   node setup_check.js --profile muziqi
 *   node setup_check.js --profile muziqi --offline   # 跳过外部命令（即梦 / 蚁小二）
 *
 * 有 FAIL 时退出码 1。清单说明见 references/setup-checklist.md。
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const SKILL_DIR = path.resolve(__dirname, '..');
const PROFILE_DIR = path.join(SKILL_DIR, 'profiles');

const argv = process.argv.slice(2);
const pIdx = argv.indexOf('--profile');
const profileName = pIdx >= 0 ? argv[pIdx + 1] : (process.env.VW_PROFILE || null);
const OFFLINE = argv.includes('--offline');
const DEFAULT_FONTS_DIR = 'G:\\牧子琪\\fonts';

if (!profileName) {
  console.error('用法: node setup_check.js --profile <账号> [--offline]');
  console.error('可用 profile: ' + fs.readdirSync(PROFILE_DIR)
    .filter(f => f.endsWith('.json') && !f.startsWith('_'))
    .map(f => f.replace(/\.json$/, '')).join(', '));
  process.exit(2);
}

const PASS = [], FAIL = [], WARN = [];
const ok = m => PASS.push(m);
const no = m => FAIL.push(m);
const warn = m => WARN.push(m);

const profilePath = path.join(PROFILE_DIR, profileName + '.json');
console.log('='.repeat(60));
console.log('使用前自检 · profile = ' + profileName + (OFFLINE ? '（--offline：跳过外部命令）' : ''));
console.log('='.repeat(60));

// ---------- 1. profile 存在 ----------
if (!fs.existsSync(profilePath)) {
  no(`profile 不存在: ${profilePath}`);
  report();
}
const rawJson = fs.readFileSync(profilePath, 'utf8');
let profile;
try {
  profile = JSON.parse(rawJson);
  ok(`profile 可读: profiles/${profileName}.json`);
} catch (e) {
  no(`profile JSON 解析失败: ${e.message}`);
  report();
}

// ---------- 2. 占位符是否已替换（打包版会留 <待填·xxx>）----------
const PLACEHOLDER = /<待填[^">]*>|YOUR_[A-Z_]+|PLACEHOLDER|__FILL_ME__/g;
const phHits = [...new Set(rawJson.match(PLACEHOLDER) || [])];
if (phHits.length) {
  no(`profile 里还有未替换的占位符: ${phHits.join(', ')}（照 setup-checklist.md 第 1 节填）`);
} else {
  ok('无未替换的占位符');
}

// ---------- 3. 路径与素材 ----------
const P = profile.paths || {};
const GM = profile.generationMode || {};
const identityRef = GM.identityRef || 'image';        // 'video' | 'image'
const sceneMode = GM.sceneMode || 'real_photo';       // 'real_photo' | 'model_generated'

// 3a. 形象参考（2026-09-16 新增：支持视频参考）
if (identityRef === 'video') {
  if (!P.identityVideo) {
    no('generationMode.identityRef=video，但 paths.identityVideo 为空 —— 形象参考视频未配置');
  } else if (!fs.existsSync(P.identityVideo)) {
    no(`paths.identityVideo 指向的文件不存在: ${P.identityVideo}`);
  } else {
    ok(`形象参考视频: ${P.identityVideo}（identityRef=video）`);
  }
}

const need = [
  ['identityImage', 'file', '身份/脸部基准图'],
  ['materialDir', 'dir', 'B-roll 素材目录'],
];
// sceneMode=model_generated 时不再依赖真实场景照片（2026-09-16 晓君总改口径）
if (sceneMode !== 'model_generated') need.splice(1, 0, ['sceneDir', 'dir', '真实场景照片目录']);

for (const [key, kind, label] of need) {
  const v = P[key];
  if (!v) { no(`paths.${key} 为空 —— ${label}未配置`); continue; }
  let st = null;
  try { st = fs.statSync(v); } catch (e) { /* 不存在 */ }
  if (!st) { no(`paths.${key} 指向的路径不存在: ${v}`); continue; }
  if (kind === 'file' && !st.isFile()) { no(`paths.${key} 不是文件: ${v}`); continue; }
  if (kind === 'dir' && !st.isDirectory()) { no(`paths.${key} 不是目录: ${v}`); continue; }
  ok(`${label}: ${v}`);
}

// 场景来源：模型生成时给说明性提示，不再当必需项
if (sceneMode === 'model_generated') {
  warn('场景为模型生成（generationMode.sceneMode=model_generated）—— 不依赖真实场景照片，'
     + '但跨段场景漂移风险更高，prompt 里要把空间关系/光源方向写具体');
} else if (P.sceneDir) {
  try {
    const imgs = fs.readdirSync(P.sceneDir).filter(f => /\.(jpg|jpeg|png)$/i.test(f));
    if (imgs.length === 0) no(`场景目录里没有图片: ${P.sceneDir}`);
    else ok(`场景照片 ${imgs.length} 张`);
  } catch (e) { /* 上面已报 */ }
}

// 3b. 音轨策略自检（2026-09-16 实测：生成音轨不是本人原声，必须替换）
if (profile.audio && profile.audio._policy) {
  ok(`音轨策略已声明：${String(profile.audio._policy).slice(0, 34)}…`);
} else if (profile.type === 'real_person') {
  warn('真人账号但 profile 未声明 audio 策略 —— 生成音轨默认会被沿用（不是本人口型对应的原声），'
     + '建议补 audio._policy：丢弃生成音轨 + 用本人真实录音替换');
}

// 3c. 人脸评测依赖（scripts/face_similarity.py 用）
const FACE_MODELS = process.env.VP_FACE_MODELS || path.join(os.homedir(), '.workbuddy', 'models');
const YUNET = path.join(FACE_MODELS, 'face_detection_yunet_2023mar.onnx');
const SFACE = path.join(FACE_MODELS, 'face_recognition_sface_2021dec.onnx');
{
  const miss = [];
  if (!fs.existsSync(YUNET)) miss.push('face_detection_yunet_2023mar.onnx（约 227KB）');
  if (!fs.existsSync(SFACE)) miss.push('face_recognition_sface_2021dec.onnx（约 38,696,353 B）');
  if (miss.length) {
    warn(`人脸评测模型缺失（不影响生成，但跑不了还原度打分）: ${miss.join(' / ')}；目录 ${FACE_MODELS}`);
  } else {
    const sz = fs.statSync(SFACE).size;
    // 实测被截断成 18MB 时会误报 "Failed to parse ONNX model"，很迷惑，所以校验字节数
    if (sz < 38000000) no(`SFace 模型疑似下载不完整: ${sz} B（应为 38,696,353 B）→ OpenCV 会报 Failed to parse ONNX model`);
    else ok(`人脸评测模型就绪（SFace ${sz} B）`);
  }
}

// ---------- 4. 即梦会话 ----------
const vg = profile.videoGeneration || {};
const v = vg.fallback || vg;
const session = String(v.session || '');
if (!session) no('videoGeneration.fallback.session 为空 —— 即梦会话未配置');
else if (!/^\d{6,}$/.test(session)) no(`即梦会话 ID 不像数字 ID: ${session}（dreamina session list 查）`);
else ok(`即梦会话 ID: ${session}`);

// ---------- 5. 发布账号 ----------
const accts = profile.publishAccounts || {};
const platKeys = Object.keys(accts).filter(k => !k.startsWith('_'));
if (platKeys.length === 0) {
  no('publishAccounts 为空 —— 至少要配一个发布平台');
} else {
  for (const k of platKeys) {
    const a = accts[k];
    if (typeof a === 'string') { warn(`${k}: 只写了账号名「${a}」，缺 platformAccountId`); continue; }
    const id = String(a.platformAccountId || '');
    if (!id) no(`${k}: platformAccountId 为空`);
    else if (!/^[0-9a-fA-F]{24}$/.test(id)) no(`${k}: platformAccountId 不是 24 位 ID: ${id}`);
    else ok(`${k}: ${a.name || '(无名)'} ${id}`);
  }
}

// ---------- 6. 字体（不做这步，中文字幕会静默掉回默认字体）----------
// 字体目录按候选顺序解析。**不能只认 VP_FONTS_DIR**：它是 setx 落盘的，只对新进程生效，
// 已在运行的终端里读不到 —— 旧实现会在这种情形下直接误报「字体目录不可访问」，
// 并把下面 7c 的端到端实测整段跳过，等于把最关键的防线关掉了。（2026-09-16 修）
const KNOWN_FONTS_DIR = path.join(os.homedir(), '.workbuddy', 'fonts');
const FONT_DIR_CANDIDATES = [
  ['VP_FONTS_DIR', process.env.VP_FONTS_DIR],
  ['profile.paths.fontsDir', P.fontsDir],
  ['~/.workbuddy/fonts', KNOWN_FONTS_DIR],
  ['默认', DEFAULT_FONTS_DIR],
].filter(c => c[1]);

let fontsDir = null, fontsSrc = null;
for (const [src, dir] of FONT_DIR_CANDIDATES) {
  try { if (fs.statSync(dir).isDirectory()) { fontsDir = dir; fontsSrc = src; break; } } catch (e) { /* 试下一个 */ }
}

if (!fontsDir) {
  fontsDir = process.env.VP_FONTS_DIR || DEFAULT_FONTS_DIR;
  no('字体目录都不可访问，候选全试过了: '
    + FONT_DIR_CANDIDATES.map(c => `${c[0]}=${c[1]}`).join(' | '));
} else {
  ok(`字体目录: ${fontsDir}（来源: ${fontsSrc}）`);
  if (fontsSrc !== 'VP_FONTS_DIR') {
    warn(`本进程读不到 VP_FONTS_DIR（setx 只对新进程生效，重开终端即可）——已自动改用 ${fontsDir}`);
  }

  // 5 款字体文件逐个点名（7c 的像素实测更强，但它依赖 ffmpeg；这里给一份不看 ffmpeg 的清单）
  const FONT_FILES = [
    'YouSheBiaoTiHei.ttf', 'SmileySans-Oblique.ttf', 'HuXiaoBoNanShenTi.otf',
    'RuiziZhenYan.ttf', 'AlibabaPuHuiTi-Heavy.ttf',
  ];
  const missing = FONT_FILES.filter(f => !fs.existsSync(path.join(fontsDir, f)));
  if (missing.length) no(`字体目录缺文件: ${missing.join(', ')}`);
}

// fontconfig：Windows 上 **实测对 libass 无效**（走 DirectWrite 提供者），所以只做提示、不判 FAIL。
// 非 Windows（Linux/macOS 构建）才真的需要它。
if (fontsDir) {
  const fc = path.join(os.homedir(), 'fonts.conf');
  const fcExists = fs.existsSync(fc);
  if (process.platform === 'win32') {
    ok(fcExists
      ? `fontconfig 存在，但 Windows 上对 libass 无效（DirectWrite 提供者）——真正的解法是 :fontsdir= + 精确 Fontname`
      : `Windows 不需要 fonts.conf（libass 走 DirectWrite，配了也无效）——字体靠 :fontsdir= + 精确 Fontname`);
  } else if (!fcExists) {
    no(`缺 fontconfig: ${fc} —— 烧字幕时 libass 找不到字体（不报错但字不对）`);
  } else {
    const fcTxt = fs.readFileSync(fc, 'utf8');
    const dirs = (fcTxt.match(/<dir>([^<]+)<\/dir>/g) || []).map(s => s.replace(/<\/?dir>/g, ''));
    const hit = dirs.some(d => d.replace(/[\\/]+/g, '/') === fontsDir.replace(/[\\/]+/g, '/'));
    if (hit) ok('fontconfig 已含该字体目录');
    else no(`fontconfig(${fc}) 的 <dir> 不含字体目录 ${fontsDir}`);
  }
}

// ---------- 7. Python + Pillow（封面生成必需）----------
// 系统 python 常不带 Pillow，所以按候选顺序探测第一个能 import PIL 的解释器。
// 找不到就 FAIL —— 这是实测最常见的一坑，装完还失败会直接 ModuleNotFoundError。
const PY_CANDIDATES = [
  process.env.VP_PYTHON,
  'python',
  'python3',
  process.platform === 'win32'
    ? path.join(os.homedir(), '.workbuddy/binaries/python/envs/default/Scripts/python.exe')
    : null,
].filter(Boolean);

let pyHit = null;
for (const cand of PY_CANDIDATES) {
  const r = spawnSync(cand, ['-c', 'import PIL; print(PIL.__version__)'], { encoding: 'utf8' });
  if (r.status === 0) { pyHit = `${cand} (Pillow ${String(r.stdout || '').trim()})`; break; }
}
if (pyHit) ok(`Python+Pillow 可用: ${pyHit}`);
else no(`所有候选 python 都没装 Pillow（试过: ${PY_CANDIDATES.join(', ')}）—— make_cover.py 会 ModuleNotFoundError。\n        装 pip install Pillow，或用环境变量 VP_PYTHON 指定带 PIL 的解释器`);

// ---------- 7b. ffmpeg / ffprobe（抽帧 / 拼接烧字幕 / 质检）----------
// 2026-09-16 新增：原自检完全没有这一项 —— 依赖表里写了 ffmpeg，但脚本不查，
// 于是"没装 ffmpeg"这件事要拖到 Step 4 抽帧甚至 Step 8 烧字幕才炸，白跑一遍生成。
const FF_CANDIDATES = [
  process.env.VP_FFMPEG,
  'ffmpeg',
  process.platform === 'win32'
    ? path.join(os.homedir(), '.workbuddy/bin/ffmpeg/bin/ffmpeg.exe')
    : null,
].filter(Boolean);

let ffHit = null;
for (const cand of FF_CANDIDATES) {
  const r = spawnSync(cand, ['-version'], { encoding: 'utf8' });
  if (!r.error && r.status === 0) {
    ffHit = { exe: cand, ver: String(r.stdout || '').split('\n')[0].trim() };
    break;
  }
}
if (ffHit) ok(`ffmpeg 可用: ${ffHit.ver}`);
else no(`找不到 ffmpeg（试过: ${FF_CANDIDATES.join(', ')}）—— 抽帧/拼接/烧字幕/质检全部无法执行。\n        装法见 references/setup-checklist.md 第 0 节，或用 VP_FFMPEG 指定绝对路径`);

if (ffHit) {
  // ffprobe 与 ffmpeg 同目录发布，单独验一次（Step 9 质检读时长/码流靠它）
  const probeName = process.platform === 'win32' ? 'ffprobe.exe' : 'ffprobe';
  const probePath = path.join(path.dirname(path.resolve(ffHit.exe)), probeName);
  const probeExe = fs.existsSync(probePath) ? probePath : 'ffprobe';
  const rp = spawnSync(probeExe, ['-version'], { encoding: 'utf8' });
  if (!rp.error && rp.status === 0) ok('ffprobe 可用');
  else no('ffprobe 不可用 —— Step 9 质检读不到时长/码流');

  // 烧字幕依赖 libass：ffmpeg 没编 libass 时 ass 滤镜不存在，字幕会整段丢失
  const rf = spawnSync(ffHit.exe, ['-hide_banner', '-filters'], { encoding: 'utf8' });
  const filterTxt = String(rf.stdout || '');
  if (rf.status === 0 && /(^|\s)(ass|subtitles)(\s|$)/m.test(filterTxt)) {
    ok('ffmpeg 含 libass（ass 滤镜可用，能烧字幕）');
  } else {
    no('这版 ffmpeg 不含 libass —— 烧中文字幕会失败。换含 libass 的构建（BtbN gpl 或 gyan essentials 都带）');
  }

  // ---------- 7c. 字幕字体真的能被 libass 找到吗（端到端实测）----------
  // 2026-09-16 新增。前面两项只能证明「目录在、名字对」，证明不了 libass 真命中了：
  // Windows 上 libass 走 **DirectWrite 字体提供者**，FONTCONFIG_FILE / fonts.conf 对它
  // 完全无效（实测：5 款字体全部静默回退微软雅黑，画面照样有字幕，肉眼极难发现）。
  //
  // 做法：同一句文本，分别用「样式里真实的 Fontname」和「一个绝不存在的字体名」
  //      各烧一帧，比对像素。两帧一致 ⇒ 前者也回退了；不一致 ⇒ 真的命中了。
  if (ffHit && fontsDir && fs.existsSync(fontsDir)) {
    const crypto = require('crypto');
    const SUB_FONTS = [
      ['t1/t6 优设标题黑', 'YouSheBiaoTiHei'],
      ['t2/t7 得意黑', 'Smiley Sans Oblique'],
      ['t5/t8 胡晓波男神体', 'HuXiaoBo-NanShen'],
      ['t3/t10 锐字真言体', 'ZhenyanGB'],
      ['t4/t9 阿里普惠体 Heavy', 'Alibaba PuHuiTi 3.0 105 Heavy'],
    ];
    const BOGUS = '__VP_NoSuchFont_9f3a__';
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'vpfont-'));
    const esc = s => s.replace(/\\/g, '/').replace(/:/g, '\\:');

    const renderHash = fontname => {
      const ass = [
        '[Script Info]', 'ScriptType: v4.00+', 'PlayResX: 400', 'PlayResY: 120', '',
        '[V4+ Styles]',
        'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour,'
          + ' BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle,'
          + ' BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding',
        `Style: T,${fontname},48,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,`
          + '-1,0,0,0,100,100,0,0,1,0,0,5,10,10,10,1',
        '', '[Events]', 'Format: Layer, Start, End, Style, Text',
        'Dialogue: 0,0:00:00.00,0:00:05.00,T,字体测试ABC',
      ].join('\n') + '\n';
      fs.writeFileSync(path.join(tmpDir, 'p.ass'), ass, 'utf8');
      const vf = `ass=p.ass:fontsdir='${esc(fontsDir)}'`;
      const r = spawnSync(ffHit.exe, [
        '-hide_banner', '-loglevel', 'error',
        '-f', 'lavfi', '-i', 'color=c=black:s=400x120:d=1',
        '-vf', vf, '-frames:v', '1',
        '-f', 'rawvideo', '-pix_fmt', 'gray', '-',
      ], { encoding: 'buffer', cwd: tmpDir, maxBuffer: 64 * 1024 * 1024 });
      if (r.status !== 0 || !r.stdout || !r.stdout.length) return null;
      return crypto.createHash('sha1').update(r.stdout).digest('hex');
    };

    const bogusHash = renderHash(BOGUS);
    if (!bogusHash) {
      warn('字体端到端实测跑不起来（ffmpeg 渲染失败），跳过 —— 请手工确认字幕字体');
    } else {
      const missed = [];
      for (const [label, fname] of SUB_FONTS) {
        const h = renderHash(fname);
        if (!h) missed.push(`${label}（渲染失败）`);
        else if (h === bogusHash) missed.push(`${label} → 回退了`);
      }
      if (!missed.length) ok(`字幕字体端到端实测：${SUB_FONTS.length} 款全部命中`);
      else no(`字幕字体没被 libass 找到，会静默回退系统字体：\n        ${missed.join('\n        ')}\n        排查：① 字体是否在该目录 ② Fontname 是否等于字体注册到系统/Windows 的名字\n        ③ 烧字幕命令是否带了 :fontsdir='<字体目录>'`);
    }
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e) { /* 忽略 */ }
  } else if (!ffHit) {
    warn('字幕字体端到端实测跳过：ffmpeg 不可用（修好 ffmpeg 后务必重跑，这步是唯一能抓出静默字体回退的检查）');
  } else {
    warn(`字幕字体端到端实测跳过：字体目录未解析到（fontsDir=${fontsDir}）`);
  }
}

// ---------- 8/9. 外部命令（在线）----------
if (!OFFLINE) {
  // 外部命令调用：本机 CLI 有的是 git-bash 脚本（dreamina），有的有 .exe（yxer），
  // Windows 上 shell:true 走 cmd.exe 会执行不了 bash 脚本，所以做多级回退。
  // 都失败才判 FAIL，避免环境差异导致误报。
  const runCmd = (cmd, args) => {
    const attempts = [
      () => spawnSync(cmd, args, { encoding: 'utf8', shell: process.platform === 'win32' }),
      () => spawnSync('bash', ['-lc', [cmd, ...args].join(' ')], { encoding: 'utf8' }),
      () => spawnSync(cmd, args, { encoding: 'utf8' }),
    ];
    for (const a of attempts) {
      try {
        const r = a();
        if (!r.error && r.status === 0 && String(r.stdout || '').trim()) return r;
      } catch (e) { /* 换下一种调用方式 */ }
    }
    return null;
  };

  // 命令解析：先按环境变量/已知安装位置找绝对路径，找不到再交给 PATH。
  // 为什么需要（2026-09-16 实测）：本机 PATH 不含 ~/bin 与 /usr/bin，而 dreamina 官方安装器
  // 恰好装在 ~/bin —— 只按裸命令名探测会把「已装好且已登录」误报成 FAIL。
  // （`setx` 落的 PATH 只对新进程生效，已在运行的终端读不到。）
  const resolveCmd = (envVar, bareName, extra) => {
    for (const c of [process.env[envVar], ...extra].filter(Boolean)) {
      if (fs.existsSync(c)) return c;
    }
    return bareName;   // 交给 PATH 解析
  };

  const HOME_BIN = path.join(os.homedir(), 'bin');
  const DREAMINA = resolveCmd('VP_DREAMINA', 'dreamina', [
    path.join(HOME_BIN, 'dreamina.exe'),
    path.join(HOME_BIN, 'dreamina'),
    path.join(os.homedir(), '.workbuddy', 'bin', 'dreamina.exe'),
    path.join(os.homedir(), '.workbuddy', 'bin', 'dreamina'),
  ]);

  // yxer 优先用包内原生二进制 bin-native/yxer.exe（Go 版，不受 node 版本目录轮换影响）。
  // 详见 references/publishing.md「yxer 入口自愈」。
  let yxerNative = [];
  try {
    const nvRoot = path.join(os.homedir(), '.workbuddy', 'binaries', 'node', 'versions');
    yxerNative = fs.readdirSync(nvRoot)
      .map(v => path.join(nvRoot, v, 'node_modules', '@yixiaoermail', 'cli', 'bin-native', 'yxer.exe'))
      .filter(p => fs.existsSync(p));
  } catch (e) { /* 没有就算了，退回 PATH */ }
  const YXER = resolveCmd('VP_YXER', 'yxer', yxerNative);

  if (/[\\/]/.test(DREAMINA)) {
    warn(`PATH 里找不到 dreamina，已回退到绝对路径 ${DREAMINA}（重开终端让 PATH 生效即可消除）`);
  }

  // runCmd 失败时返回 null（不是对象），这里必须判空，否则 TypeError 崩掉整个自检
  // （2026-09-16 修复：本机未装 dreamina 时 setup_check.js 在 d.error 处直接抛异常）
  const d = runCmd(DREAMINA, ['session', 'list']);
  if (!d) no(`dreamina 不可用或未登录（${DREAMINA} session list 失败）`);
  else {
    const txt = String(d.stdout || '');
    ok(`dreamina 可用且已登录（${DREAMINA}）`);
    if (session && txt && !txt.includes(session)) {
      no(`即梦里找不到会话 ${session} —— 会话不存在或未登录到该账号`);
    } else if (session) ok(`即梦会话 ${session} 存在`);
  }

  for (const k of platKeys) {
    const a = accts[k];
    if (typeof a === 'string' || !a.platformAccountId) continue;
    const y = runCmd(YXER, ['accounts', 'list', k, '--json']);
    if (!y) { no(`yxer 查询 ${k} 失败（未装/未登录蚁小二）`); continue; }
    const txt = String(y.stdout || '');
    if (!txt.includes(a.platformAccountId)) no(`${k} 账号 ${a.platformAccountId} 不在 yxer 账号列表里`);
    else if (!/"status"\s*:\s*1/.test(txt)) warn(`${k} 账号存在，但请人工确认它 status=1（在线）`);
    else ok(`${k} 账号在线`);
  }
}

report();

function report() {
  console.log('');
  if (PASS.length) { console.log('PASS:'); PASS.forEach(m => console.log('  [OK]   ' + m)); }
  if (WARN.length) { console.log(''); console.log('WARN:'); WARN.forEach(m => console.log('  [!]    ' + m)); }
  if (FAIL.length) { console.log(''); console.log('FAIL:'); FAIL.forEach(m => console.log('  [FAIL] ' + m)); }
  console.log('');
  console.log('='.repeat(60));
  if (FAIL.length) {
    console.log(`>>> 未通过：${FAIL.length} 项 FAIL，${WARN.length} 项 WARN。照 setup-checklist.md 补全再开工。`);
    process.exit(1);
  }
  console.log(`>>> 全部通过（${PASS.length} 项 PASS${WARN.length ? `，${WARN.length} 项 WARN` : ''}），可以开工。`);
  process.exit(0);
}
