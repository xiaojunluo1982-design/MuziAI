#!/usr/bin/env node
/**
 * preflight_check.js — 发布前自动质检（替代人工审核的硬关卡）
 *
 * 背景：2026-09-02 晓君总裁定「以后不用我审核，视频做好直接发」。
 * 人工审核撤了，但公开事故不能撤，所以用脚本把那道关守住。
 *
 * 检查项（FAIL 一律阻断，exit 1）：
 *   A. 成片：文件存在 / ffprobe 可读 / 720x1280 / 有音轨 / 时长 20-180s
 *   B. 素材：封面 存在 / < 512KB / 格式 jpg / B3 封面 key 必须带日期唯一后缀（防串封面）
 *            成片 key 必须含日期（B4，2026-10-14 新增 —— 成片 key 与封面同源，由文件名派生）
 *   C. 账号（防串号，最硬的一条）：
 *      C0. profile 里该账号带 `_suspendFrom: "YYYY-MM-DD"` 且已到期 → FAIL（账号暂停，老板指令）
 *      payload 里的 platformAccountId 必须 === profile 里该平台的 id
 *      且 yxer 里该 id 的 status === 1
 *      且 yxer 里该 id 的 platformAccountName === profile 里的 name
 *   D. 文案：抖音 description <=30 / 小红书 title <=20 / 视频号封面 <512KB
 *   E. 合规：正文不得出现价格、百分比、绝对化用语
 *   G. 重复发布拦截（2026-09-02 补）：同一天同一平台若已发过，直接 FAIL。
 *      来源两处，互为交叉验证：
 *        ① 周计划条目里的 published 块（人工/agent 回写）
 *        ② output/published_log.json 发布台账（--record 追加，机器写）
 *      「skipped」（账号离线）不算已发，允许补发。
 *      判重键 = 平台 + platformAccountId；**回写周计划 published 块 / 台账 platforms[] 时
 *      每一项都必须带 platformAccountId**，否则键退化成「平台|*」通配，主号一发成功
 *      就会把同平台的附加号一起锁死（2026-09-10 实测踩坑，已加 G 判重数据完整性 WARN）。
 *      附加号写在 published._附加号 子块里（`_` 开头，不会被误收成主号记录）。
 *
 * WARN 不阻断（只提示）：模型自带字幕、音轨单声道等
 *
 * 两段式用法（推荐）：
 *   ① 上传前先验素材，早发现硬伤：
 *      node preflight_check.js --profile muziqi --video "<成片.mp4>" --cover "<封面.jpg>"
 *   ② 构造 payload 后验账号与文案，通过才 publish：
 *      node preflight_check.js --profile muziqi --video "<成片.mp4>" --cover "<封面.jpg>" \
 *        --payload "<payload_抖音.json>" --payload "<payload_小红书.json>"
 *
 * 发布成功后登记台账（供下次拦截用）：
 *      node preflight_check.js --record '{"date":"2026-09-02","platforms":[{"platform":"抖音","taskSetId":"xxx","status":"submitted"}]}'
 *
 * 兜底开关（默认关闭，用了必须在汇报里写明理由）：
 *      --allow-republish   把 G 的 FAIL 降级为 WARN（例如晓君总明确要求删了重发）
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SKILL_DIR = path.resolve(__dirname, '..');

// ---------- 参数 ----------
function parseArgs(argv) {
  const a = {
    profile: null, video: null, cover: null, payloads: [],
    plan: null, date: null, ledger: null, record: null, allowRepublish: false,
  };
  for (let i = 2; i < argv.length; i++) {
    const k = argv[i];
    const v = argv[i + 1];
    if (k === '--profile') { a.profile = v; i++; }
    else if (k === '--video') { a.video = v; i++; }
    else if (k === '--cover') { a.cover = v; i++; }
    else if (k === '--payload') { a.payloads.push(v); i++; }
    else if (k === '--plan') { a.plan = v; i++; }
    else if (k === '--date') { a.date = v; i++; }
    else if (k === '--ledger') { a.ledger = v; i++; }
    else if (k === '--record') { a.record = v; i++; }
    else if (k === '--allow-republish') { a.allowRepublish = true; }
    else if (k === '--help' || k === '-h') { a.help = true; }
  }
  return a;
}

const args = parseArgs(process.argv);

// ---------- 台账模式：发布成功后登记（不跑质检） ----------
const LEDGER = args.ledger || process.env.MUZIQI_PUBLISH_LOG ||
  path.join(process.cwd(), 'output', 'published_log.json');

if (args.record) {
  let rec;
  try { rec = JSON.parse(args.record); }
  catch (e) { console.error('FAIL  --record 不是合法 JSON'); process.exit(1); }
  rec.ts = new Date().toISOString();
  let all = [];
  if (fs.existsSync(LEDGER)) {
    try { all = JSON.parse(fs.readFileSync(LEDGER, 'utf8')); } catch (e) { all = []; }
  }
  all.push(rec);
  fs.mkdirSync(path.dirname(LEDGER), { recursive: true });
  fs.writeFileSync(LEDGER, JSON.stringify(all, null, 2), 'utf8');
  console.log('已登记发布台账 → ' + LEDGER);
  console.log(JSON.stringify(rec, null, 2));
  process.exit(0);
}

if (args.help || !args.profile || !args.video || !args.cover) {
  console.log('用法(验素材): node preflight_check.js --profile <名> --video <mp4> --cover <jpg>');
  console.log('用法(全量)  : 上面再加 --payload <json>，可重复传多个平台');
  console.log('用法(登记)  : node preflight_check.js --record \'{"date":"YYYY-MM-DD","platforms":[...]}\'');
  process.exit(2);
}
const payloadMode = args.payloads.length > 0;

// ---------- 当天日期 ----------
function todayStr() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}
const CHECK_DATE = args.date || todayStr();

// ---------- 周计划：取当天条目 ----------
function findPlanEntry(date) {
  let files = [];
  if (args.plan) {
    files = [args.plan];
  } else {
    const dir = path.join(process.cwd(), 'output', '周计划');
    if (fs.existsSync(dir)) {
      files = fs.readdirSync(dir)
        .filter(f => f.endsWith('_周计划.json'))
        .map(f => path.join(dir, f));
    }
  }
  for (const f of files) {
    try {
      const arr = JSON.parse(fs.readFileSync(f, 'utf8'));
      const hit = (arr || []).find(e => e.date === date);
      if (hit) return { file: f, entry: hit };
    } catch (e) { /* 忽略坏文件 */ }
  }
  return null;
}

// ---------- 台账 ----------
function readLedger(date) {
  if (!fs.existsSync(LEDGER)) return [];
  try {
    const all = JSON.parse(fs.readFileSync(LEDGER, 'utf8'));
    return (all || []).filter(r => r.date === date);
  } catch (e) { return []; }
}

// 判定某平台当天是否已发（skipped 不算）
function isPublished(pfObj) {
  if (!pfObj) return false;
  const st = String(pfObj.status || '').toLowerCase();
  if (!st) return false;
  if (st === 'skipped' || st === 'failed' || st === 'error') return false;
  return true; // submitted / allsuccessful / success 都算已提交，禁止重发
}

// 汇总：键 "<平台>|<账号ID>" -> {status, taskSetId, at, source}
// 2026-09-06 起支持一平台多号（矩阵号同步发布）：重复发布必须按「平台+账号」判定，
// 否则主号发完会把同平台的附加号一起误拦。老数据没有 platformAccountId 时记为 "<平台>|*"，
// 查找时先精确匹配，再回落到通配 —— 通配命中仍视为已发，宁可漏发也不重发。
function pubKey(platform, accountId) {
  return platform + '|' + (accountId || '*');
}
function collectedPublished(date) {
  const map = {};
  const missingIds = [];   // 已发布记录但缺 platformAccountId → 判重退化为平台级，会误锁同平台另一个号
  const p = findPlanEntry(date);
  if (p) {
    const pub = p.entry.published || {};
    for (const [k, v] of Object.entries(pub)) {
      // "_" 开头是说明性字段（如 _附加号），不是平台发布记录，误收会污染判重表
      if (k === 'at' || k === 'approved_by' || k.startsWith('_') || typeof v !== 'object') continue;
      if (isPublished(v)) {
        if (!v.platformAccountId) missingIds.push('周计划 published.' + k);
        map[pubKey(k, v.platformAccountId)] = { status: v.status, taskSetId: v.taskSetId, at: pub.at, source: '周计划' };
      }
    }
    // 附加号块同样要带 ID，否则主号发完会把附加号一起误拦
    const sub = pub._附加号 || {};
    for (const [k, v] of Object.entries(sub)) {
      if (typeof v !== 'object' || v === null || !isPublished(v)) continue;
      if (!v.platformAccountId) missingIds.push('周计划 published._附加号.' + k);
    }
  }
  for (const r of readLedger(date)) {
    for (const pf of (r.platforms || [])) {
      if (isPublished(pf)) {
        if (!pf.platformAccountId) missingIds.push('台账 ' + (r.date || '') + ' ' + pf.platform);
        map[pubKey(pf.platform, pf.platformAccountId)] = {
          status: pf.status, taskSetId: pf.taskSetId, at: r.ts, source: '台账' + (r.note ? '(' + r.note + ')' : ''),
        };
      }
    }
  }
  return { map, planFile: p && p.file, missingIds };
}
// 精确匹配优先，否则回落到该平台的通配记录
function findDup(map, platform, accountId) {
  return map[pubKey(platform, accountId)] || map[pubKey(platform, null)] || null;
}

const results = [];   // {level:'PASS'|'FAIL'|'WARN', item, msg}
const add = (level, item, msg) => results.push({ level, item, msg });

// ---------- profile ----------
const profilePath = path.join(SKILL_DIR, 'profiles', args.profile + '.json');
if (!fs.existsSync(profilePath)) {
  console.error('FAIL  找不到 profile: ' + profilePath);
  process.exit(1);
}
const profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
const accounts = profile.publishAccounts || {};
// 2026-09-06 起支持矩阵号：extraPublishAccounts 里的账号与主号同平台同内容同步发布，
// 白名单内的 id 不算串号。profile 没配则为空，行为与旧版一致。
const extraAccounts = profile.extraPublishAccounts || {};
function resolveAccount(platform, usedId) {
  const main = accounts[platform];
  if (main && usedId === main.platformAccountId) return { role: '主号', name: main.name };
  const extras = extraAccounts[platform] || [];
  const hit = extras.find(e => usedId === e.platformAccountId);
  if (hit) return { role: '附加号', name: hit.name };
  return null; // 不在任何白名单里 → 串号
}

// ---------- A. 成片 ----------
let probe = null;
if (!fs.existsSync(args.video)) {
  add('FAIL', 'A1 成片存在', '找不到文件: ' + args.video);
} else {
  add('PASS', 'A1 成片存在', path.basename(args.video));
  try {
    const out = execSync(
      'ffprobe -v error -show_entries format=duration -show_entries stream=codec_type,width,height,channels ' +
      '-of default=noprint_wrappers=1 "' + args.video + '"',
      { encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }
    ).trim();
    const widths = [...out.matchAll(/^width=(\d+)$/gm)].map(m => +m[1]).filter(Boolean);
    const heights = [...out.matchAll(/^height=(\d+)$/gm)].map(m => +m[1]).filter(Boolean);
    const types = [...out.matchAll(/^codec_type=(\w+)$/gm)].map(m => m[1]);
    const dur = parseFloat((out.match(/^duration=([\d.]+)$/m) || [])[1] || '0');
    probe = { w: widths[0] || 0, h: heights[0] || 0, types, dur };

    if (probe.w === 720 && probe.h === 1280) add('PASS', 'A2 分辨率', '720x1280 竖屏');
    else add('FAIL', 'A2 分辨率', probe.w + 'x' + probe.h + '，应为 720x1280');

    if (types.includes('audio')) add('PASS', 'A3 音轨', '有音轨（codec_type=audio）');
    else add('FAIL', 'A3 音轨', '无音轨！曾出现"没声音"投诉，禁止发布');

    if (types.includes('video')) add('PASS', 'A4 视频流', '有');
    else add('FAIL', 'A4 视频流', '无');

    if (probe.dur >= 20 && probe.dur <= 180) add('PASS', 'A5 时长', probe.dur.toFixed(2) + 's');
    else add('FAIL', 'A5 时长', probe.dur.toFixed(2) + 's，应在 20-180s');
  } catch (e) {
    add('FAIL', 'A2 ffprobe', '读取失败: ' + String(e.message).slice(0, 120));
  }
}

// ---------- B. 封面 ----------
let coverSize = 0;
if (!fs.existsSync(args.cover)) {
  add('FAIL', 'B1 封面存在', '找不到文件: ' + args.cover);
} else {
  coverSize = fs.statSync(args.cover).size;
  if (coverSize < 512 * 1024) add('PASS', 'B1 封面体积', (coverSize / 1024).toFixed(0) + 'KB < 512KB');
  else add('FAIL', 'B1 封面体积', (coverSize / 1024).toFixed(0) + 'KB，超过 512KB 上限');
  if (/\.jpe?g$/i.test(args.cover)) add('PASS', 'B2 封面格式', 'jpg');
  else add('WARN', 'B2 封面格式', path.extname(args.cover) + '，建议 jpg');
}

// ---------- C. 账号（防串号） ----------
const acctCache = {};
function listAccounts(platform) {
  if (acctCache[platform]) return acctCache[platform];
  try {
    const out = execSync('yxer accounts list "' + platform + '" --json', {
      encoding: 'utf8', maxBuffer: 20 * 1024 * 1024,
    }).trim();
    const j = JSON.parse(out);
    const arr = Array.isArray(j) ? j : (j.data || j.list || j.items || []);
    acctCache[platform] = arr;
    return arr;
  } catch (e) {
    add('FAIL', 'C0 账号查询', platform + ' 列表拉取失败: ' + String(e.message).slice(0, 120));
    acctCache[platform] = [];
    return [];
  }
}

const BANNED_WORDS = [
  { re: /[¥￥]\s*\d|\d+\s*元|\d+\s*块钱/, name: '价格' },
  { re: /\d+\s*%|百分之\s*[零一二三四五六七八九十百千\d]+/, name: '百分比' },
  { re: /(效果|转化|成交|业绩|营收).{0,6}(提升|增长|翻).{0,4}\d+/, name: '效果数字' },
  { re: /全国第一|行业第一|最好|最强|唯一指定|100%/, name: '绝对化用语' },
];

const PUB = collectedPublished(CHECK_DATE);

// 数据完整性自检：已发布记录缺 platformAccountId 时，判重键退化成「平台|*」通配，
// 主号一发成功就会把同平台的附加号一起锁死，导致附加号永远补发不了。
// 这是回写台账/周计划时的漏字段，不是内容问题，早发现早补。
if (PUB.missingIds && PUB.missingIds.length) {
  add('WARN', 'G 判重数据', '以下已发布记录缺 platformAccountId，判重已退化为平台级：' +
    PUB.missingIds.join('；') + ' —— 请补齐后再发布，否则同平台另一个号会被误拦');
}

for (const pf of args.payloads) {
  if (!fs.existsSync(pf)) { add('FAIL', 'C payload', '找不到: ' + pf); continue; }
  let payload;
  try { payload = JSON.parse(fs.readFileSync(pf, 'utf8')); }
  catch (e) { add('FAIL', 'C payload', path.basename(pf) + ' JSON 解析失败'); continue; }

  const platform = (payload.platforms || [])[0];
  const form = (payload.publishArgs && payload.publishArgs.accountForms || [])[0];
  if (!platform || !form) { add('FAIL', 'C payload', path.basename(pf) + ' 缺 platforms/accountForms'); continue; }

  const tag = platform;
  const expect = accounts[platform];
  if (!expect) { add('FAIL', 'C1 ' + tag + ' 配置', 'profile 里没有该平台的发布账号配置'); continue; }

  // G 重复发布拦截（同天 同平台 且 同账号 已发过 → FAIL）
  // 按「平台+账号」判定：主号发完不影响附加号补发，但同一账号绝不重发。
  const usedId = form.platformAccountId;
  const acct = resolveAccount(platform, usedId);
  const acctLabel = acct ? acct.role + '「' + acct.name + '」' : '未知账号';

  // C0 暂停发布闸门（2026-09-29 新增）
  // 背景：晓君总指令「明天起抖音主号牧子数智暂停发布」。账号暂停是老板指令，
  // 不能只写成 profile 注释（没人读），必须做成硬 FAIL，让所有发布路径都绕不过。
  // 约定：profile 里给账号对象加 `_suspendFrom: "YYYY-MM-DD"`，该日期（含）起，
  // 任何用到这个号的 payload 一律 FAIL。恢复发布 = 从 profile 删掉该字段。
  const suspEntry = (accounts[platform] && accounts[platform].platformAccountId === usedId)
    ? accounts[platform]
    : (extraAccounts[platform] || []).find(e => e.platformAccountId === usedId)
      || ((profile._suspendedAccounts || {})[platform] || []).find(e => e.platformAccountId === usedId);
  if (suspEntry && suspEntry._suspendFrom && String(suspEntry._suspendFrom) <= CHECK_DATE) {
    add('FAIL', 'C0 ' + tag + ' 暂停发布', '「' + (suspEntry.name || usedId) + '」自 ' +
      suspEntry._suspendFrom + ' 起已暂停发布（晓君总指令），' + CHECK_DATE +
      ' 不得再用该账号；如需恢复请从 profile 删除 _suspendFrom');
    continue;
  }

  const dup = findDup(PUB.map, platform, usedId);
  if (dup) {
    const msg = CHECK_DATE + ' 该账号已发布过（' + acctLabel + '，' + (dup.at || dup.source) + '，taskSetId=' +
      (dup.taskSetId || '-') + '，来源=' + dup.source + '）—— 禁止重复发布';
    if (args.allowRepublish) add('WARN', 'G ' + tag + ' 重复发布', msg + '；已用 --allow-republish 放行，务必在汇报写明理由');
    else add('FAIL', 'G ' + tag + ' 重复发布', msg + '；确需重发请加 --allow-republish 并写明理由');
  } else {
    add('PASS', 'G ' + tag + ' 重复发布', CHECK_DATE + ' ' + acctLabel + ' 未发布过');
  }

  // C1 id 一致性 —— 串号最强防线（主号 + 附加号白名单都算合法）
  if (acct) add('PASS', 'C1 ' + tag + ' 账号ID', usedId + ' = ' + acctLabel + '，在白名单内');
  else add('FAIL', 'C1 ' + tag + ' 账号ID', 'payload 用 ' + usedId + '，既不是主号 ' +
    (expect && expect.platformAccountId) + ' 也不在附加号白名单 —— 疑似串号！');

  // C2 在线状态 + 名字
  const arr = listAccounts(platform);
  const hit = arr.find(a => a.id === usedId);
  if (!hit) {
    add('FAIL', 'C2 ' + tag + ' 在线', 'yxer 列表里找不到该账号 id，可能未授权');
  } else if (hit.status !== 1) {
    add('FAIL', 'C2 ' + tag + ' 在线', 'status=' + hit.status + '（离线/授权过期）—— 跳过该账号，禁止换号顶替');
  } else {
    add('PASS', 'C2 ' + tag + ' 在线', 'status=1 ' + hit.platformAccountName);
    if (!acct) {
      add('FAIL', 'C3 ' + tag + ' 账号名', '账号不在白名单，无法核名');
    } else if (hit.platformAccountName === acct.name) {
      add('PASS', 'C3 ' + tag + ' 账号名', hit.platformAccountName);
    } else {
      add('FAIL', 'C3 ' + tag + ' 账号名', '线上是「' + hit.platformAccountName + '」，profile 要求「' + acct.name + '」—— 疑似串号！');
    }
  }

  // D 文案长度 / 平台特殊字段
  const cpf = form.contentPublishForm || {};
  const desc = cpf.description || '';
  const title = cpf.title || '';
  if (platform === '抖音') {
    const n = [...desc].length;
    if (n > 0 && n <= 30) add('PASS', 'D ' + tag + ' 描述长度', n + ' 字 ≤30');
    else add('FAIL', 'D ' + tag + ' 描述长度', n + ' 字，抖音上限 30');
  }
  if (platform === '小红书') {
    const n = [...title].length;
    if (n > 0 && n <= 20) add('PASS', 'D ' + tag + ' 标题长度', n + ' 字 ≤20');
    else add('FAIL', 'D ' + tag + ' 标题长度', n + ' 字，小红书上限 20');
    if (cpf.visibleType === 0) add('PASS', 'D ' + tag + ' visibleType', '0');
    else add('FAIL', 'D ' + tag + ' visibleType', '应为 0，当前 ' + cpf.visibleType);
    if (!/#/.test(desc) && !/话题/.test(desc)) add('WARN', 'D ' + tag + ' 话题', '正文未检测到话题标签');
  }
  if (platform === '视频号') {
    if (cpf.createType === 2) add('PASS', 'D ' + tag + ' createType', '2');
    else add('FAIL', 'D ' + tag + ' createType', '应为 2，当前 ' + cpf.createType);
    if (cpf.pubType === 1) add('PASS', 'D ' + tag + ' pubType', '1');
    else add('FAIL', 'D ' + tag + ' pubType', '应为 1，当前 ' + cpf.pubType);
    if (coverSize && coverSize < 512 * 1024) add('PASS', 'D ' + tag + ' 封面', '<512KB');
    else add('FAIL', 'D ' + tag + ' 封面', '视频号封面必须 <512KB');
  }

  // E 合规
  const text = title + '\n' + desc;
  let dirty = [];
  for (const b of BANNED_WORDS) if (b.re.test(text)) dirty.push(b.name);
  if (!dirty.length) add('PASS', 'E ' + tag + ' 合规', '无价格/百分比/绝对化用语');
  else add('FAIL', 'E ' + tag + ' 合规', '命中禁词：' + dirty.join('、'));

  // F 素材对象完整性
  const v = form.video || {};
  const c = form.cover || {};
  const miss = [];
  if (!v.key || !v.size || !v.duration) miss.push('video');
  if (!c.key || !c.size || !c.width || !c.height) miss.push('cover');
  if (!miss.length) add('PASS', 'F ' + tag + ' 素材对象', 'video/cover 字段完整');
  else add('FAIL', 'F ' + tag + ' 素材对象', '缺字段或不完整：' + miss.join('、'));

  // B3 封面 key 唯一性（2026-09-29 新增 · 串封面根因闸门）
  // 蚁小二 OSS 的封面 key 按「文件名」生成、不带 hash；该 URL 又被 CDN 缓存 30 天
  // （2026-09-29 实测 X-Swift-CacheTime=2592000 / Age=72469）。用无日期的通用名
  // （cover.jpg / cover_512k.jpg）会：① 与小红书等其它线互相覆盖；② 覆盖上传后 CDN 仍回旧图
  // → 平台抓到的是别人的封面（09-29 实测：视频号+抖音抓到了 09-28 小红书那张）。
  // 必须带 4 位日期唯一后缀（如 cover_0929_xjz.jpg），并且旧 key 一律不复用。
  const ck = String((form && form.coverKey) || c.key || '');
  const cbase = ck.split('/').pop() || '';
  if (!ck) add('FAIL', 'B3 ' + tag + ' 封面key', 'payload 缺 coverKey');
  else if (/\d{4}/.test(cbase)) add('PASS', 'B3 ' + tag + ' 封面key', cbase + '（带唯一日期后缀）');
  else add('FAIL', 'B3 ' + tag + ' 封面key', '「' + cbase +
    '」是无日期通用名 —— OSS key 同名会互相覆盖、且该 URL 被 CDN 缓存约 30 天，' +
    '平台会抓到别的帖子的封面。请改名带日期后重新上传（如 cover_MMDD_xjz.jpg），旧 key 不复用');

  // B4 成片 key 唯一性（2026-10-14 新增 · 串成片根因闸门）
  // 与封面同源：蚁小二 OSS 的**成片** key 同样按「文件名」派生（<ASCII前缀>_<hash>.mp4），
  // 同名 → 同 key → 同 URL。10-14 实测：与 10-07 同题成片同名 `AI时代最大的杠杆_完整版字幕.mp4`
  // → 两次都得到 `AI_6170f7bb.mp4`；上传虽覆盖成功（源站已是新片），但该 URL 被 CDN 缓存
  // 约 30 天不回源 → 平台抓到的是 10-07 的旧片（26448424B/56.73s），只能删帖重发。
  // 封面之所以从没出这事，是因为封面早已按 B3 带日期 —— 成片当时漏了这条。
  const vk = String(v.key || "");
  const vbase = vk.split("/").pop() || "";
  const dateTok = (s) => {
    const m8 = s.match(/20\d{2}(\d{2})(\d{2})/);
    if (m8) { const mo = +m8[1], dy = +m8[2]; if (mo >= 1 && mo <= 12 && dy >= 1 && dy <= 31) return m8[0]; }
    for (const t of (s.match(/\d{4}/g) || [])) { const mo = +t.slice(0, 2), dy = +t.slice(2); if (mo >= 1 && mo <= 12 && dy >= 1 && dy <= 31) return t; }
    return null;
  };
  const vt = dateTok(vbase);
  if (!vk) add("FAIL", "B4 " + tag + " 成片key", "payload 缺 video.key");
  else if (vt) add("PASS", "B4 " + tag + " 成片key", vbase + "（含日期标记 " + vt + "）");
  else add("FAIL", "B4 " + tag + " 成片key", "「" + vbase +
    "」不含日期 —— OSS 的成片 key 由【文件名】派生（<ASCII前缀>_<hash>.mp4），同名必同 key；" +
    "该 URL 又被 CDN 缓存约 30 天不回源 → 同题成片（跨周复用选题）会发成旧那一版。" +
    "请把成片改名为 <title>_完整版字幕_<MMDD>.mp4 后重传，旧 key 不复用。事故：2026-10-14");
}

// ---------- G（素材阶段）：只提示，等 payload 阶段再逐平台判 FAIL ----------
if (!payloadMode) {
  const keys = Object.keys(PUB.map);
  if (keys.length) {
    const detail = keys.map(k => k + '(' + (PUB.map[k].taskSetId || PUB.map[k].source) + ')').join('、');
    add('WARN', 'G 今日已发布', CHECK_DATE + ' 已发过：' + detail +
      '。若要补发未成功的平台，只传该平台 payload，勿全量重发');
  } else {
    add('PASS', 'G 今日已发布', CHECK_DATE + ' 未发布过（周计划' +
      (PUB.planFile ? '命中 ' + path.basename(PUB.planFile) : '未命中') + '，台账 ' + readLedger(CHECK_DATE).length + ' 条）');
  }
}

// ---------- 输出 ----------
const ICON = { PASS: '[OK]  ', FAIL: '[FAIL]', WARN: '[warn]' };
console.log('');
console.log('发布前自动质检 · profile=' + args.profile + (payloadMode ? ' · 全量' : ' · 仅素材阶段'));
console.log('='.repeat(64));
for (const r of results) console.log(ICON[r.level] + ' ' + r.item.padEnd(24, ' ') + ' ' + r.msg);
console.log('='.repeat(64));

const fails = results.filter(r => r.level === 'FAIL');
const warns = results.filter(r => r.level === 'WARN');
console.log('PASS ' + results.filter(r => r.level === 'PASS').length +
  ' / WARN ' + warns.length + ' / FAIL ' + fails.length);

if (fails.length) {
  console.log('');
  console.log('>>> 阻断发布。FAIL 项处理完再跑一次本脚本。');
  process.exit(1);
}
console.log('');
console.log('>>> 质检通过，可以发布。' + (warns.length ? '（有 ' + warns.length + ' 条 WARN，不阻断）' : ''));
if (!payloadMode) console.log('>>> 仅跑了素材阶段，构造 payload 后请再跑一次全量（加 --payload）。');
process.exit(0);
