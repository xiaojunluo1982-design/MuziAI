#!/usr/bin/env node
/**
 * B-roll 合成器（通用 · 可复现 · 6 道自检闸门）
 * ---------------------------------------------------------------
 * 为什么有这个东西（2026-09-29，同一天踩了两次）：
 *   ① 成片插片段整段是**冻结帧**（freezedetect: 6.008→8.317s, duration=2.31s）
 *   ② 换素材后**插片静默消失**（画面一直是人），却通过了「冻结检测」——人在那儿本来就动
 *   两次都因为合成是**手敲的一次性 ffmpeg 命令、没落盘**，事后无从复现、无从 diff。
 *   → 合成一律走本脚本；⛔ 不许再手敲 overlay 命令。
 *
 * 🔴 两个必须知道的知识点：
 *   A. `overlay` 的 `enable='between(t,…)'` 里 **t 是「叠加层自己的时间轴」**，不是主输入。
 *      叠加层只有 2.7s 时 between(t,5.7,8.5) 恒不成立 → 插片不显示、且不报错（坑 ②）；
 *      反之叠加层比窗口短、先在窗口之前 EOF → `repeatlast=1` 重复末帧贴满窗口 → 整段静止（坑 ①）。
 *      ✅ 正解：`setpts=PTS-STARTPTS+<AT>/TB` 把叠加层推到目标时刻，
 *         配 `overlay=0:0:eof_action=pass:repeatlast=0`，起止天然对齐、两个坑一起消掉。
 *   B. 口播底片常是 1080×1920，**必须先 `scale=720:1280` 再做 overlay**，
 *      否则成片分辨率跟着底片走、B-roll 只盖住左上角。
 *
 * 用法：
 *   node compose_broll.js --body body_1.2x.mp4 --subs subtitles.ass --out final.mp4 \
 *        --broll "/abs/path/素材.mp4" --b-in 0.15 --b-dur 2.74 --at 5.72 [--control-at 1.0] [--dry-run] [--trust-source]
 *
 * 闸门（任一 FAIL → 退出码 1，不许发布）：
 *   ⓿ 素材本身是「动态视频」：抽 3 帧比 md5，全同 = 静止素材 → FAIL
 *      ⚠️ 传 --trust-source 时跳过（晓君总本人经微云上传的素材 = 可信来源，2026-10-05 指令）
 *   ① 成片时长 ≈ body（±0.2s）      ② 分辨率 = 720×1280
 *   ③ 有音轨（只取口播原声）        ④ 插片窗内无冻结（freezedetect，冻结占比 ≤30%）
 *   ⑤ 插片**确实生效**：插片窗 PSNR(vs 底片) 比对照区低 ≥5dB 且 <30dB
 */
'use strict';

const { execFileSync, spawnSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const FF = process.env.FFMPEG || 'C:/Users/admin/.workbuddy/bin/ffmpeg/bin/ffmpeg.exe';
const FP = process.env.FFPROBE || 'C:/Users/admin/.workbuddy/bin/ffmpeg/bin/ffprobe.exe';

const argv = process.argv.slice(2);
function arg(name, def) {
  const i = argv.indexOf('--' + name);
  return i > -1 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : def;
}
const flag = (name) => argv.includes('--' + name);

const BODY = arg('body');
const BROLL = arg('broll');
const SUBS = arg('subs');
const OUT = arg('out');
const B_IN = parseFloat(arg('b-in', '0'));
const B_DUR = parseFloat(arg('b-dur', '0'));
const AT = parseFloat(arg('at', '0'));
const CONTROL_AT = parseFloat(arg('control-at', '0'));
const DRY = flag('dry-run');
const TRUST = flag('trust-source');  // 晓君总本人上传素材 = 可信来源，跳过闸门⓿（2026-10-05 指令）

if (!BODY || !BROLL || !SUBS || !OUT) {
  console.error('用法：node compose_broll.js --body <口播底片> --subs <字幕.ass> --out <成片> \\\n'
    + '        --broll <素材> --b-in <入点s> --b-dur <时长s> --at <成片插入起点s> [--control-at <对照点>] [--dry-run] [--trust-source]');
  process.exit(2);
}
const DIR = path.dirname(path.resolve(BODY));
for (const f of [BODY, BROLL, path.join(DIR, SUBS)]) {
  if (!fs.existsSync(f)) { console.error('[ERR] 文件不存在：' + f); process.exit(2); }
}
if (!(B_DUR > 0) || AT < 0) { console.error('[ERR] --b-dur 必须 >0，--at 必须 ≥0'); process.exit(2); }

const fails = [];
const ok = (m) => { console.log('  PASS  ' + m); };
const bad = (m) => { fails.push(m); console.log('  FAIL  ' + m); };

const probe = (f, a) => (spawnSync(FP, ['-v', 'error', ...a, f], { encoding: 'utf8' }).stdout || '').trim();
const duration = (f) => parseFloat(probe(f, ['-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1'])) || 0;
function videoWH(f) {
  const [w, h] = probe(f, ['-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0']).split(',').map(Number);
  return { w, h };
}
const hasAudio = (f) => !!probe(f, ['-select_streams', 'a:0', '-show_entries', 'stream=codec_name', '-of', 'csv=p=0']);
function freezes(f) {
  const r = spawnSync(FF, ['-v', 'info', '-i', f, '-vf', 'freezedetect=n=-60dB:d=0.30', '-map', '0:v', '-f', 'null', '-'], { encoding: 'utf8' });
  const log = (r.stderr || '') + (r.stdout || '');
  const st = [...log.matchAll(/freeze_start: ([\d.]+)/g)].map((m) => parseFloat(m[1]));
  const du = [...log.matchAll(/freeze_duration: ([\d.]+)/g)].map((m) => parseFloat(m[1]));
  return st.map((s, i) => ({ start: s, dur: du[i] || 0 }));
}
function psnrInWindow(out, body, at, dur) {
  const r = spawnSync(FF, ['-v', 'info', '-ss', String(at), '-t', String(dur), '-i', out,
    '-ss', String(at), '-t', String(dur), '-i', body,
    '-filter_complex', '[1:v]scale=720:1280,setsar=1[b];[0:v][b]psnr', '-an', '-f', 'null', '-'], { encoding: 'utf8' });
  const m = ((r.stderr || '') + (r.stdout || '')).match(/average:\s*([\d.]+|inf)/);
  return m ? (m[1] === 'inf' ? 99 : parseFloat(m[1])) : NaN;
}
const md5 = (f) => crypto.createHash('md5').update(fs.readFileSync(f)).digest('hex');

// ---------- 闸门 ⓿ 素材必须是动态视频 ----------
console.log('=== 闸门 ⓿ · 素材动态性 ===');
if (TRUST) {
  ok('素材来源可信（晓君总本人上传）→ 免检动态性（--trust-source，2026-10-05 指令）');
} else {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'brollchk-'));
  const md = duration(BROLL);
  const ts = [0.1, md * 0.5, Math.max(0.1, md - 0.2)].map((t) => Math.min(t, Math.max(0, md - 0.05)));
  const hashes = ts.map((t, i) => {
    const out = path.join(tmp, `f${i}.jpg`);
    spawnSync(FF, ['-v', 'error', '-ss', String(t), '-i', BROLL, '-frames:v', '1', '-q:v', '3', out, '-y']);
    return fs.existsSync(out) ? md5(out) : null;
  });
  const uniq = new Set(hashes.filter(Boolean)).size;
  console.log(`  素材 ${path.basename(BROLL)}  ${md.toFixed(2)}s  抽 3 帧 → ${uniq} 个不同帧`);
  uniq >= 3
    ? ok('素材本身是动态视频（3 帧互不相同）')
    : bad(`素材疑似静止画面（3 帧只有 ${uniq} 种）—— 静止素材不可作插片，换素材`);
  fs.rmSync(tmp, { recursive: true, force: true });
}

// ---------- 合成 ----------
console.log('\n=== 合成 ===');
const bodyDur = duration(path.join(DIR, BODY));
const { w: bw, h: bh } = videoWH(path.join(DIR, BODY));
const mat = videoWH(BROLL);
console.log(`  口播底片 ${BODY}  ${bodyDur.toFixed(3)}s  ${bw}×${bh}`);
console.log(`  插片素材 ${path.basename(BROLL)}  ${mat.w}×${mat.h}  入点 ${B_IN}s / 时长 ${B_DUR}s / 插在成片 ${AT}s`);

// 素材与成片比例差异 → 决定填充方式（都等比，绝不变形）
const matRatio = mat.w / mat.h, dstRatio = 720 / 1280;
let brollChain;
if (Math.abs(matRatio - dstRatio) < 0.02) {
  brollChain = '[1:v]fps=30,setpts=PTS-STARTPTS+' + AT + '/TB,scale=720:1280,setsar=1[broll]';
  console.log('  素材比例≈成片 → 直接等比铺满');
} else if (matRatio < dstRatio) {
  // 素材更窄（竖长）：fg contain 不裁切 + bg cover+blur 补左右
  brollChain = '[1:v]fps=30,setpts=PTS-STARTPTS+' + AT + '/TB,split=2[bg][fg];'
    + '[bg]scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,gblur=sigma=30,eq=brightness=-0.12[bgb];'
    + '[fg]scale=720:1280:force_original_aspect_ratio=decrease,fps=30[fgs];'
    + '[bgb][fgs]overlay=(W-w)/2:(H-h)/2[broll]';
  console.log('  素材更窄 → fg contain 居中（不裁切）+ bg cover+blur 补左右');
} else {
  // 素材更宽（横屏）：fg contain 居中 + bg cover+blur 补上下
  brollChain = '[1:v]fps=30,setpts=PTS-STARTPTS+' + AT + '/TB,split=2[bg][fg];'
    + '[bg]scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,gblur=sigma=30,eq=brightness=-0.12[bgb];'
    + '[fg]scale=720:1280:force_original_aspect_ratio=decrease,fps=30[fgs];'
    + '[bgb][fgs]overlay=(W-w)/2:(H-h)/2[broll]';
  console.log('  素材更宽 → fg contain 居中（不裁切）+ bg cover+blur 补上下');
}

const fc = [
  '[0:v]scale=720:1280,setsar=1[base]',
  brollChain,
  '[base][broll]overlay=0:0:eof_action=pass:repeatlast=0[vout]',
  '[vout]ass=' + SUBS + '[vsub]',
].join(';');

const args = ['-v', 'error', '-y', '-i', BODY,
  '-ss', String(B_IN), '-t', String(B_DUR), '-i', BROLL,
  '-filter_complex', fc, '-map', '[vsub]', '-map', '0:a',
  '-t', bodyDur.toFixed(3),
  '-c:v', 'libx264', '-preset', 'medium', '-crf', '20', '-pix_fmt', 'yuv420p', '-r', '30',
  '-c:a', 'aac', '-b:a', '128k', OUT];

if (DRY) { console.log('\n[dry-run] ' + fc.replace(/;/g, ';\n         ')); process.exit(0); }

const t0 = Date.now();
try {
  execFileSync(FF, args, { cwd: DIR, stdio: ['ignore', 'inherit', 'inherit'] });
  console.log(`  ffmpeg 完成（${((Date.now() - t0) / 1000).toFixed(1)}s）`);
} catch (e) {
  console.error('[ERR] ffmpeg 失败：' + e.message);
  process.exit(1);
}

// ---------- 闸门 ①–⑤ ----------
console.log('\n=== 闸门 · 成片自检 ===');
const outPath = path.join(DIR, OUT);
if (!fs.existsSync(outPath)) { console.error('[ERR] 未生成成片'); process.exit(1); }

const d = duration(outPath);
Math.abs(d - bodyDur) <= 0.2
  ? ok(`① 时长 ${d.toFixed(3)}s ≈ 底片 ${bodyDur.toFixed(3)}s`)
  : bad(`① 时长 ${d.toFixed(3)}s 与底片 ${bodyDur.toFixed(3)}s 差 >0.2s（尾部冻结帧/被拉长）`);

const { w, h } = videoWH(outPath);
(w === 720 && h === 1280) ? ok(`② 分辨率 ${w}×${h}`) : bad(`② 分辨率 ${w}×${h} ≠ 720×1280`);
hasAudio(outPath) ? ok('③ 含音轨（仅口播原声）') : bad('③ 无音轨');

const fz = freezes(outPath);
const win = { s: AT - 0.05, e: AT + B_DUR + 0.05 };
const frozen = fz.reduce((a, f) => {
  const s = Math.max(f.start, win.s), e = Math.min(f.start + f.dur, win.e);
  return a + Math.max(0, e - s);
}, 0);
const ratio = frozen / (win.e - win.s);
console.log('  冻结区间: ' + (fz.length ? fz.map((f) => `${f.start.toFixed(2)}+${f.dur.toFixed(2)}s`).join(' / ') : '无'));
ratio <= 0.30 ? ok(`④ 插片窗内运动正常（冻结占比 ${(ratio * 100).toFixed(0)}%）`)
  : bad(`④ 插片窗内是静止画面！冻结 ${frozen.toFixed(2)}s = ${(ratio * 100).toFixed(0)}%`);

const pWin = psnrInWindow(OUT, BODY, AT, B_DUR);
const pCtrl = psnrInWindow(OUT, BODY, CONTROL_AT, B_DUR);
const delta = pCtrl - pWin;
console.log(`  PSNR(vs 底片) 插片窗 ${pWin.toFixed(2)}dB / 对照区 ${pCtrl.toFixed(2)}dB`);
(delta >= 5 && pWin < 30) ? ok(`⑤ 插片确实生效（窗口比对照区低 ${delta.toFixed(1)}dB）`)
  : bad(`⑤ 插片疑似未生效！窗口 ${pWin.toFixed(2)}dB vs 对照 ${pCtrl.toFixed(2)}dB（差 ${delta.toFixed(1)}dB，需 ≥5dB）`);

console.log(`\n=== 汇总：FAIL ${fails.length} ===`);
if (fails.length) { fails.forEach((f) => console.log('  ✗ ' + f)); process.exitCode = 1; }
else console.log(`  ✅ 成片通过全部闸门 → ${OUT}  ${d.toFixed(2)}s  ${w}×${h}`);
