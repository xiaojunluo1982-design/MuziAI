#!/usr/bin/env node
/**
 * 通用口播字幕 ASS 生成（默认 t6：优设标题黑、黄字黑边 5px、下三分之一）。
 * 断句：一屏一个完整句，按语义切（句末标点 → 分句标点 → 虚词前软切），上限 18 字/屏。
 * 配合 make_cover.py 的默认 s7 使用（2026-09-03 拍板 s7+t6）。
 *
 * 用法：
 *   node gen_subtitles.js --segments segments.json --probe "G:/.../输出目录" --out subtitles.ass
 *   node gen_subtitles.js --segments segments.json --durations "15.042,15.042,15.042" --out subtitles.ass
 *
 * --probe 指向存放 part1.mp4 / part2.mp4 ... 的目录，自动用 ffprobe 读取各段真实时长。
 * 时间轴按「每段字数占比」分配，段首留白 0.35s，段尾留 0.25s。
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const k = argv[i].slice(2);
      a[k] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : true;
      if (a[k] !== true) i++;
    }
  }
  return a;
}

const args = parseArgs(process.argv);
const segFile = args['segments'];
const probeDir = args['probe'];
const out = args['out'] || path.join(process.cwd(), 'subtitles.ass');

if (!segFile) { console.error('需要 --segments <json>'); process.exit(1); }
const raw = JSON.parse(fs.readFileSync(segFile, 'utf8'));
const list = Array.isArray(raw) ? raw : (raw.segments || raw);
const texts = list.map(x => x.text || x);

let durations;
if (probeDir) {
  durations = texts.map((_, i) => {
    const f = path.join(probeDir, `part${i + 1}.mp4`);
    if (!fs.existsSync(f)) { console.error('缺少分段文件:', f); process.exit(1); }
    const d = execFileSync('ffprobe', [
      '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f
    ], { encoding: 'utf8' }).trim();
    return parseFloat(d);
  });
  console.log('分段时长:', durations.map(d => d.toFixed(3)).join(', '));
} else if (args['durations']) {
  durations = args['durations'].split(',').map(parseFloat);
} else {
  console.error('需要 --probe <dir> 或 --durations "a,b,c"');
  process.exit(1);
}
if (durations.length !== texts.length) {
  console.error(`段数不匹配：文本 ${texts.length} 段，时长 ${durations.length} 段`);
  process.exit(1);
}

// ---------- 断行：一屏一句，按语义切（2026-09-10 重写）----------
// 历史问题：旧逻辑是「满 10 字遇标点切 / 满 12 字就硬切」——硬切不管语义，会把句子劈开，
//   末尾剩 1-2 个字还会**单独占一屏**（晓君总反馈的「掉一个字到下一屏」）。
// 新逻辑，优先级从高到低：
//   ① 句末标点 。？！     → 一屏就是一个完整句
//   ② 整句超过 HARD_MAX  → 在分句标点 ，；： 处切（尾部标点随分句走，顿号 、 不切，
//                          因为顿号连的是并列成分，切开不成句）
//   ③ 分句仍超长         → 只在虚词/连词「前」软切，不在词中间劈开
//   ④ 硬切产生的残尾（≤ ALONE_MAX 字且不以标点结尾）→ 并回上一屏，绝不单独成屏
const HARD_MAX = 18;   // 一屏硬上限。720 宽 / t6 52px 下约两行，观感最稳
const ALONE_MAX = 3;   // 残尾阈值
const MIN_SUB   = 6;   // 分句最短长度，短于此不单独成屏
// 软切白名单：出现在这些字「前面」才允许切，保证切在语义边界上
const SOFT_BEFORE = ['的','了','和','与','就','也','还','把','被','让','给','在','是','有',
  '这','那','而','但','却','又','再','才','更','并','对','从','到','用','会','能','要','说',
  '做','去','来','个','们','我','你','他','她','它','谁','哪','往','向','又','谁'];

const cn = s => (s || '').replace(/\s/g, '').length;
const endsWithPunct = s => /[。？！，、；：,;:.!?]$/.test(String(s).trim());

// 超长句：先按分句标点切，仍过长才在虚词前软切
function splitLongSentence(sent) {
  const out = [];
  let buf = '';
  // 同句内的短分句能合就合（≤ HARD_MAX），避免「我是牧子琪，」这种 6 字屏单独闪一下
  const flush = () => {
    const cur = buf.trim();
    buf = '';
    if (!cur) return;
    const prev = out[out.length - 1];
    if (prev !== undefined && cn(prev) + cn(cur) <= HARD_MAX) out[out.length - 1] = prev + cur;
    else out.push(cur);
  };
  for (let i = 0; i < sent.length; i++) {
    const ch = sent[i];
    const insideAI = ch === 'A' && sent[i + 1] === 'I';   // 不拆 "AI"
    if ('，；：'.includes(ch) && !insideAI) {              // 顿号不切，见 ②
      buf += ch;
      if (cn(buf) >= MIN_SUB) flush();
      continue;
    }
    buf += ch;
    if (cn(buf) >= HARD_MAX && !insideAI) {
      const next = sent[i + 1] || '';
      if (SOFT_BEFORE.includes(next)) flush();
    }
  }
  flush();
  return out;
}

function splitLines(text) {
  // ① 按句末标点切成完整句
  const sentences = [];
  let s = '';
  for (const ch of text) {
    s += ch;
    if ('。？！'.includes(ch)) { sentences.push(s); s = ''; }
  }
  if (s.trim()) sentences.push(s);

  // ② ③
  const lines = [];
  for (const sent of sentences) {
    if (cn(sent) <= HARD_MAX) lines.push(sent);
    else lines.push(...splitLongSentence(sent));
  }

  // ④ 残尾合并：只有「短 + 不以标点结尾」才并回上一屏
  const merged = [];
  for (const ln of lines) {
    const prev = merged[merged.length - 1];
    if (prev !== undefined && cn(ln) <= ALONE_MAX && !endsWithPunct(ln)) {
      merged[merged.length - 1] = prev + ln;
    } else {
      merged.push(ln);
    }
  }
  return merged.map(x => x.trim()).filter(Boolean);
}

function fmt(t) {
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  const cs = Math.round((t - Math.floor(t)) * 100);
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

// events 生成移到样式定义之后（折行需要 SIZE 参数）

// ---------- 字幕样式（5 款主流风格，--style 选择） ----------
// ASS 颜色为 &HAA BBGGRR（BGR 顺序）。BorderStyle: 1=描边 3=不透明底框（BackColour 作底色）
//
// ⚠️ 2026-09-16 修正 Fontname（重要，改动前请读）：
//   libass 在 Windows 上走 DirectWrite，**只认「字体注册到系统的那个名字」**，
//   既不是文件名，也不一定是 name 表的 Family(1)。实测取值如下，改错就静默回退系统字体：
//     优设标题黑   → YouSheBiaoTiHei                    ✔ 本来就对
//     得意黑       → **Smiley Sans Oblique**（不是 'Smiley Sans'）← 本次修正
//     胡晓波男神体 → HuXiaoBo-NanShen                    ✔ 本来就对
//     锐字真言体   → ZhenyanGB                           ✔ 本来就对
//     阿里普惠体   → **Alibaba PuHuiTi 3.0 105 Heavy**（不是 'Alibaba PuHuiTi'）← 本次修正
//   换字体（尤其换了普惠体版本）后，必须用 scripts/../setup_check.js 的字体项重新确认。
//   本机已把 5 款字体装进 Windows 用户字体库，并用 fontsdir 兜底（见 SKILL.md Step 8）。
// 样式表已抽到 _sub_styles.js（与 asr_to_ass.js 共用，单一真相）。
const { SUB_STYLES } = require('./_sub_styles.js');

// 2026-09-04：默认 t6（9/3 晓君总拍板「封面和字幕就默认 s7+t6」），与 profile.defaults 一致。
// t1 与 t6 唯一差异是描边 6px vs 5px；需要老样式请显式 --style t1。
const styleKey = args['style'] || 't6';
const ST = SUB_STYLES[styleKey];
if (!ST) {
  console.error('未知字幕样式:', styleKey, '可选:', Object.keys(SUB_STYLES).join('/'));
  process.exit(1);
}

const PLAY_RES_X = args['resx'] || 720;
const PLAY_RES_Y = args['resy'] || 1280;
const FONT = args['font'] || ST.font || 'Microsoft YaHei';
const SIZE = args['size'] || ST.size;
const COLOR = args['color'] || ST.primary;
const OUTLINE = args['outline'] !== undefined ? parseInt(args['outline'], 10) : ST.outlineW;
const OUTLINE_COLOR = args['outline-color'] || ST.outline;
const MARGIN_V = args['marginv'] || ST.marginv;

// ---------- 折行（2026-09-16 新增，解决「字幕溢出屏幕」） ----------
// 根因：旧版一屏最多 18 字，却按单行输出 —— 720 宽 / 52px 单行只放得下约 12 字，
//   18 字必然左右溢出。现在按语义把超长屏折成两行（ASS 硬换行 \N），每行都不超宽。
const SUB_MARGIN_LR = 40;                                   // 与 Style 行的 MarginL/MarginR 一致
const AVAIL_W = (args['resx'] || 720) - SUB_MARGIN_LR * 2;   // 可用像素宽
const MAX_PER_LINE = Math.max(6, Math.floor(AVAIL_W / SIZE));  // 单行安全字数（按全宽汉字估）

/**
 * 把一屏文本按语义折成两行。返回不含换行符时表示无需折行。
 * 分层切点（分低者优先）+ 禁止切点（拆数字/英文词）。
 *   0 标点后（，。！？；：、）  1 关联词前  2 虚词前  9 其它可行位置
 * 禁止：数字中间（二十四）、英文单词中间（AI）。
 */
const PUNCT_AFTER = '，。！？；：、,;:';
const CONJ_BEFORE = ['但是', '然后', '因为', '所以', '如果', '其实', '而且', '不过', '这是',
  '这些', '这个', '现在', '那么', '于是', '另外', '同时', '只有', '只要', '无论', '虽然',
  '而是', '就是', '还有', '以及', '对于', '关于', '今天', '一样', '一起'];
const ADV_BEFORE = '不没很太更最就也还再又才都只把被让给和与在从向对要会能可这那而但却并';
const NUM_CHARS = '零一二三四五六七八九十百千万两〇';

function wrapTwoLines(text, maxPerLine) {
  const t = String(text).trim();
  if (cn(t) <= maxPerLine) return t;

  const isNum = ch => NUM_CHARS.includes(ch);
  const isLetter = ch => /[A-Za-z]/.test(ch);
  const forbidden = i => (isNum(t[i - 1]) && isNum(t[i])) || (isLetter(t[i - 1]) && isLetter(t[i]));
  const tier = i => {
    if (forbidden(i)) return -1;
    if (PUNCT_AFTER.includes(t[i - 1])) return 0;
    if (CONJ_BEFORE.some(w => t.startsWith(w, i))) return 1;
    if (ADV_BEFORE.includes(t[i])) return 2;
    return 9;
  };

  let best = null;
  for (let i = 1; i < t.length; i++) {
    const l1 = cn(t.slice(0, i)), l2 = cn(t.slice(i));
    if (l1 > maxPerLine || l2 > maxPerLine) continue;
    const k = tier(i);
    if (k < 0) continue;
    const score = k * 100 + Math.abs(l1 - l2);
    if (!best || score < best.score) best = { i, score };
  }
  const at = best ? best.i : Math.min(maxPerLine, Math.floor(t.length / 2));
  return t.slice(0, at).trim() + '\\N' + t.slice(at).trim();
}

const events = [];
let wrappedCount = 0;
texts.forEach((text, si) => {
  const lines = splitLines(text);
  const totalChars = text.replace(/\s/g, '').length;
  const segDur = durations[si];
  const start = durations.slice(0, si).reduce((a, b) => a + b, 0);
  let cursor = start + 0.35;
  const usable = segDur - 0.6;
  lines.forEach(line => {
    const shown = wrapTwoLines(line, MAX_PER_LINE);
    if (shown.includes('\\N')) wrappedCount++;
    const ratio = line.length / totalChars;
    const dur = Math.max(0.8, usable * ratio);
    events.push(`Dialogue: 0,${fmt(cursor)},${fmt(cursor + dur)},MuziqiSubtitle,,0,0,0,,${shown}`);
    cursor += dur;
  });
});
console.log(`折行：单行上限 ${MAX_PER_LINE} 字，${wrappedCount} 屏折成两行`);

const ass = `[Script Info]
ScriptType: v4.00+
PlayResX: ${PLAY_RES_X}
PlayResY: ${PLAY_RES_Y}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: MuziqiSubtitle,${FONT},${SIZE},${COLOR},${COLOR},${OUTLINE_COLOR},${ST.back},-1,0,0,0,100,100,0,0,${ST.border},${OUTLINE},${ST.shadow},2,40,40,${MARGIN_V},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
${events.join('\n')}
`;

fs.writeFileSync(out, ass, 'utf8');
console.log(`written: ${out}  [${styleKey} ${ST.name}]`);
console.log('字幕事件数:', events.length, '| 总字数:', texts.join('').length);

// 自检：原文是否完整（去空白后比对长度；折行插入的 \N 不计入）
const subText = events.map(e => e.split(',,').pop()).join('').replace(/\\N/g, '');
const srcText = texts.join('').replace(/\s/g, '');
console.log(subText.length === srcText.length
  ? 'OK 字幕字数与原文一致'
  : `WARN 字数不一致：字幕 ${subText.length} / 原文 ${srcText.length}`);
