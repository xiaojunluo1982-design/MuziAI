#!/bin/bash
# ============================================================
# 牧子琪成片推送：生成卡片并推送到指定渠道
#
# ⚠️ 两种口径，用 --mode 切换（**2026-09-22 起两个号都用 notify**）：
#    --mode notify（默认）：成片 preflight 全 PASS 即发 → 本卡片是**发布后简报**（不是审批单）。
#        牧子琪口径：2026-09-05 晓君总裁定「成片推给我就行，默认通过，到点自动发布」。
#        晓君总口径：2026-09-22 本人授权「以后不用问了，一旦发现有新内容，直接生成文案、制作视频并发布」。
#    --mode review（**旧口径，2026-09-22 已由晓君总本人撤销**）：推送=送审、必须本人确认才发。
#        保留仅为历史兼容；新任务一律不要用它。
#
# 用法:
#   bash notify_review.sh --video <成片.mp4> --cover <封面.jpg> \
#        --pkg <内容包.json> [--qclog <qc输出.txt>] [--mode notify|review] \
#        [--receipt "<发布回执文本>"] \
#        [--channel wecom|none] [--chat-id <企微会话ID>] [--dry-run]
#
# --receipt（2026-09-24 补）：发布回执，已发布时**必须传** ——
#     晓君总号是「发布后简报」，卡片里要让老板一眼看到"已经发了"（平台 / 发布号 / publishId / taskSetId）。
#     多行用 \n 分隔（在 bash 里写 $'...' 或直接传真实换行）。
# --channel none（默认）: 只生成卡片，不发送（用于人工确认后再发）
# --channel wecom      : 上传成片+封面 → 发视频/图片/摘要三条消息
#
# 约定:
#   - chat_id 必须取自 `wecom-cli message aibot sessions list` 的本次返回值，
#     不接受历史上下文里的值（企微服务端会轮换）。
#   - --qclog 必须传 **preflight_check.js 的输出文件**（含 `PASS x / WARN y / FAIL z` 那行）；
#     传 ffprobe 原样输出会被判成「未跑质检」。
#   - 邮箱渠道不在此脚本内（走 agent-mail MCP，由 agent 直接调用）。
# ============================================================
set -u
export PYTHONIOENCODING=utf-8 PYTHONUTF8=1 LC_ALL=C.UTF-8 LANG=C.UTF-8

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -W 2>/dev/null || pwd)"
NODE="$(command -v node 2>/dev/null || true)"
# 2026-09-16 修复：原写死 /c/Users/user/... 换机器探测不到 node
[ -z "$NODE" ] && for c in "$HOME"/.workbuddy/binaries/node/versions/*/node.exe; do [ -x "$c" ] && NODE="$c" && break; done
[ -z "$NODE" ] && { echo "FAIL 找不到 node"; exit 1; }
PY="$(command -v python3 2>/dev/null || command -v python 2>/dev/null || true)"

VIDEO=""; COVER=""; PKG=""; QCLOG=""; CHANNEL="none"; CHATID=""; DRY=0; MODE="notify"; OWNER="牧子琪"; RECEIPT=""
while [ $# -gt 0 ]; do
  case "$1" in
    --video) VIDEO="$2"; shift 2;;
    --cover) COVER="$2"; shift 2;;
    --pkg)   PKG="$2"; shift 2;;
    --qclog) QCLOG="$2"; shift 2;;
    --channel) CHANNEL="$2"; shift 2;;
    --chat-id) CHATID="$2"; shift 2;;
    --mode)  MODE="$2"; shift 2;;   # 默认 notify（两个号都用它）；review 是 2026-09-22 已作废的旧口径
    --owner) OWNER="$2"; shift 2;;  # 卡片抬头账号名，默认「牧子琪」；晓君总号必须传 --owner 晓君总（否则卡片串号）
    --receipt) RECEIPT="$2"; shift 2;;  # 发布回执（已发布时必传）
    --dry-run) DRY=1; shift;;
    *) shift;;
  esac
done

[ -z "$VIDEO" ] && { echo "FAIL 缺 --video"; exit 2; }
[ -s "$VIDEO" ] || { echo "FAIL 成片不存在: $VIDEO"; exit 1; }
WORK="$(cd "$(dirname "$VIDEO")" && pwd -W 2>/dev/null || pwd)"

# ---------- 读规格 ----------
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$VIDEO" 2>/dev/null)
RES=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "$VIDEO" 2>/dev/null)
FPS=$(ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate -of csv=p=0 "$VIDEO" 2>/dev/null)
HASA=$(ffprobe -v error -select_streams a:0 -show_entries stream=codec_type -of csv=p=0 "$VIDEO" 2>/dev/null)
SIZE=$(stat -c%s "$VIDEO" 2>/dev/null)
VOL=$(ffmpeg -i "$VIDEO" -af volumedetect -f null - 2>&1 | grep mean_volume | sed 's/.*mean_volume: //')
QCLINE="未跑质检"
[ -n "$QCLOG" ] && [ -s "$QCLOG" ] && QCLINE=$(grep -oE "PASS [0-9]+ / WARN [0-9]+ / FAIL [0-9]+" "$QCLOG" | tail -1)
[ -z "$QCLINE" ] && QCLINE="未跑质检"
# 段数优先从工作目录的 segments.json 读；成片目录没有就回退到内容包目录（--pkg 的邻居）。
# 路径一律走 argv 传参 —— 不要内插进 JS 源码，反斜杠会被吞（本机已踩过）。
SEG_N=$("$NODE" -e '
const fs=require("fs"),path=require("path");
const cands=[];
if(process.argv[1]) cands.push(path.join(process.argv[1],"segments.json"));
if(process.argv[2]) cands.push(path.join(path.dirname(process.argv[2]),"segments.json"));
for(const c of cands){
  try{ const s=JSON.parse(fs.readFileSync(c,"utf8")); const a=Array.isArray(s)?s:(s.segments||s.list); if(a&&a.length){ process.stdout.write(String(a.length)); process.exit(0);} }catch(e){}
}
' "$WORK" "$PKG" 2>/dev/null)
# python 子进程通过环境读取上面探测到的值
export DUR RES FPS HASA SIZE VOL QCLINE SEG_N MODE OWNER RECEIPT

# ---------- 生成卡片 ----------
CARD="$WORK/review_card.md"
# 注意：heredoc 必须加引号，否则正文里的反引号会被 bash 当命令替换执行
"$PY" - "$PKG" "$VIDEO" "$COVER" "$WORK" <<'PYEOF' > "$CARD"
# -*- coding: utf-8 -*-
import io, json, os, sys
pkg_p, video_p, cover_p, work = sys.argv[1:5]
d = {}
if pkg_p and os.path.exists(pkg_p):
    try: d = json.load(io.open(pkg_p, encoding='utf-8'))
    except Exception: pass
dur   = os.environ.get('DUR','').strip()
res   = os.environ.get('RES','').strip()
fps   = os.environ.get('FPS','').strip()
hasa  = os.environ.get('HASA','').strip()
size  = os.environ.get('SIZE','').strip()
vol   = os.environ.get('VOL','').strip()
qc    = os.environ.get('QCLINE','').strip()
try: mb = '%.2f MB' % (int(size)/1024/1024)
except Exception: mb = '-'
try: dur_s = '%.2fs' % float(dur)
except Exception: dur_s = dur or '-'
fps_s = fps.split('/')[0] if fps else '-'
print('## %s成片已完成 · %s（%s）' % (os.environ.get('OWNER') or '牧子琪', d.get('date','-'), d.get('weekday','-')))
print('')
print('**%s**' % d.get('title','-'))
print('')
print('> %s · 功能 %s' % (d.get('column','-'), d.get('function_no','-')))
print('> 场景：%s' % d.get('scene','-'))
print('')
print('| 项 | 值 |')
print('|---|---|')
print('| 规格 | %s / %s / %sfps |' % (res or '-', dur_s, fps_s))
print('| 大小 | %s |' % mb)
print('| 音轨 | %s |' % ('有' if hasa=='audio' else '**缺失**'))
print('| 音量 | mean %s |' % (vol or '-'))
segn = os.environ.get('SEG_N','').strip() or str(d.get('_segments','') or '')
seg_txt = (segn + ' 段') if segn else '-'
# 口播字数：优先 script；真人口播直剪（§2B）没有 script，正文在 segments[0] 里 —— 回退，别再显示 0 字
_body = d.get('script') or ''
if not _body and isinstance(d.get('segments'), list):
    _body = ''.join(d.get('segments') or [])
print('| 口播 | %s 字 / %s |' % (len(_body), seg_txt))
print('| 质检 | %s |' % qc)
print('')
print('成片：`%s`' % os.path.basename(video_p))
if cover_p: print('封面：`%s`' % os.path.basename(cover_p))
print('')
rec = (os.environ.get('RECEIPT') or '').strip()
if rec:
    print('**发布回执**  ')
    for line in rec.split('\n'):
        print('- %s' % line)
    print('')
mode = os.environ.get('MODE', 'notify')
if mode == 'review':
    print('⚠️ **这是送审，不是知会 —— 待您回复确认后才发布，未确认一律不发。**')
elif rec:
    print('已按「默认通过 + 事后可叫停」发出。要撤直接回「撤」，我删/隐藏并记 withdrawn；要改说哪儿。')
else:
    print('默认通过，自动发布（preflight 全量质检 PASS 才发）。要改直接说哪儿。')
PYEOF

echo "卡片已生成: $CARD"
echo "----------------------------------------"
cat "$CARD"
echo "----------------------------------------"

# ---------- 企微发送 ----------
# 上传 + 发送一条媒体。
# 坑（2026-09-04 实测）：upload 对 .jpg/.mp4 一律返回 type=file，不是 image/video。
# 发送时的 msg_type 必须与 upload 返回的 type 对齐，写死 image/video 会发送失败。
send_media() {
  local FP="$1"
  [ -s "$FP" ] || { echo "FAIL 文件不存在: $FP"; return 1; }
  wecom-cli media upload --json "{\"file_path\": \"$FP\"}" > "$WORK/_upload.json" 2>/dev/null
  local MT
  MT=$("$NODE" -e "
const fs=require('fs');
let j={}; try{ j=JSON.parse(fs.readFileSync('$WORK/_upload.json','utf8')); }catch(e){}
if(!j.media_id){ console.log('FAIL'); process.exit(0); }
const t = (j.type==='image'||j.type==='video'||j.type==='voice') ? j.type : 'file';
fs.writeFileSync('$WORK/_send_payload.json',
  JSON.stringify({chat_id:'$CHATID', msg_type:t, [t]:{media_id:j.media_id}}), 'utf8');
console.log(t);
" 2>/dev/null)
  if [ -z "$MT" ] || [ "$MT" = "FAIL" ]; then
    echo "FAIL 上传失败: $(basename "$FP")"; head -5 "$WORK/_upload.json"; return 1
  fi
  # ⚠️ exit 0 ≠ 发送成功：企微服务端偶发 `-202 server inner http request failed`，
  #    进程照样返回 0。必须看返回 JSON 的 success 字段，失败重试一次。
  local try=0 ok=0
  while [ $try -lt 2 ]; do
    try=$((try+1))
    wecom-cli message aibot send --json "$(cat "$WORK/_send_payload.json")" > "$WORK/_send_out.json" 2>&1
    if "$NODE" -e '
const fs=require("fs");
try{ const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.exit(j.success===true?0:1); }catch(e){ process.exit(1); }
' "$WORK/_send_out.json" 2>/dev/null; then ok=1; break; fi
    echo "  重试 ${try}/2 …"
  done
  if [ "$ok" = "1" ]; then
    echo "已发 [$MT]: $(basename "$FP")"
  else
    echo "FAIL 发送失败 [$MT]: $(basename "$FP")"; head -8 "$WORK/_send_out.json"; return 1
  fi
  rm -f "$WORK/_send_payload.json"
}

if [ "$CHANNEL" = "wecom" ]; then
  [ -z "$CHATID" ] && { echo "FAIL --channel wecom 需要 --chat-id"; exit 2; }
  if [ "$DRY" = "1" ]; then echo "[dry-run] 将发送到企微会话"; exit 0; fi

  echo "--- 推送中 ---"
  [ -n "$COVER" ] && send_media "$COVER"
  # 2026-09-24 补：企微机器人「文件」消息有体积上限，超限必失败（连试 2 次都是
  # `-202 server inner error http request failed`）。实测 66.5MB 成片必失败、
  # 158KB 封面正常 —— 直接按 20MB 闸门跳过，别再白等两轮重试、也别把"没发出去"
  # 误当"发过了"。成片路径已经在卡片正文里，老板可以直接从工作区/已发布平台看。
  VSZ=$(stat -c%s "$VIDEO" 2>/dev/null || echo 0)
  if [ "${VSZ:-0}" -gt 20971520 ]; then
    echo "跳过 [video]: 成片 $(( VSZ / 1048576 ))MB 超过企微文件上限(20MB)，只推卡片（成片路径见卡片正文）"
  else
    send_media "$VIDEO"
  fi

  "$NODE" -e "
const fs=require('fs');
fs.writeFileSync('$WORK/_md_payload.json', JSON.stringify({
  chat_id: '$CHATID', msg_type: 'markdown',
  markdown: { content: fs.readFileSync('$CARD','utf8') }
}), 'utf8');
"
  wecom-cli message aibot send --json "$(cat "$WORK/_md_payload.json")" > "$WORK/_md_out.json" 2>&1
  if "$NODE" -e '
const fs=require("fs");
try{ const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8")); process.exit(j.success===true?0:1); }catch(e){ process.exit(1); }
' "$WORK/_md_out.json" 2>/dev/null; then echo "已发 [markdown]: 审核卡片"; else echo "FAIL 卡片发送失败"; head -8 "$WORK/_md_out.json"; fi
  rm -f "$WORK/_md_payload.json" "$WORK/_upload.json" "$WORK/_send_out.json" "$WORK/_md_out.json"
  echo ">>> 企微推送完成"
fi
