#!/usr/bin/env node
/**
 * 真人素材字幕：**已有视频 + ASR 逐字时间戳 → ASS**
 *
 * 与 `gen_subtitles.js` 的分工（别用错）：
 *   gen_subtitles.js —— 即梦生成片：段时长靠 ffprobe，段内时间轴按「字数占比」估
 *   asr_to_ass.js    —— 真人原声素材：时间轴直接取 ASR 的**逐字毫秒时间戳**，与口型严丝合缝
 *
 * 用法：
 *   node asr_to_ass.js --in <asr.json> --out subtitles.ass --style t1 \
 *     [--slice "1.10-57.60,64.00-67.00"]   # 剪辑映射：原片时间 → 成片时间（可多个保留段）
 *     [--fix "木子琪=牧子琪"]                # ASR 识别错字纠正（**必须等长**，否则拒绝）
 *     [--resx 720 --resy 1280] [--max 12] [--target 14]
 *     [--dry-run]                            # 只打印分屏与时间轴，不写文件
 *
 * `--slice` 说明：成片由原片若干保留段拼接而成时，把原片时间戳重映射到成片时间轴。
 *   例 `"1.10-57.60,64.00-67.00"` = 取原片 1.10~57.60 接 64.00~67.00，中间 57.60~64.00 被剪掉。
 *   落在保留段之外的字**自动丢弃**，并在剪切点断开成两屏（不会串屏）。
 *
 * 输入 json：apiz `tasks get <task_id>` 的输出（`result.utterances[].words[]` 带逐字时间戳）。
 *
 * ⚠️ 两个实测要点（2026-09-17）：
 *   ① **以 `words` 为准，不用 `utterance.text`**：实测二者会不一致
 *      （``utterance.text`` 写「节省70以上」，而 `words` 是「节省70%以上」——words 更准且带时间戳）。
 *      脚本会打印二者的差异供人工确认。
 *   ② `words` 是**单字粒度**（「发展」「已经」都拆成单字，只有 `AI` / `70%` 是整词），
 *      所以**没有词边界可用**。切点靠三层依据：语义等级 → **字间停顿 gap** → 常用词保护表。
 *      词内 gap 通常为 0，词间才有停顿，因此 gap 是避坑主力。
 */
const fs = require('fs');
const path = require('path');
const { SUB_STYLES } = require('./_sub_styles.js');

function parseArgs(argv) {
  const a = {};
  for (let i = 2; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const k = argv[i].slice(2);
      a[k] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : true;
      if (a[k] !== true) i++;
    }
  }
  return a;
}

const args = parseArgs(process.argv);
const inFile = args['in'];
if (!inFile) { console.error('需要 --in <asr.json>'); process.exit(1); }
if (!fs.existsSync(inFile)) { console.error('找不到 ASR json:', inFile); process.exit(1); }

const outFile = args['out'] || path.join(process.cwd(), 'subtitles.ass');
const styleKey = args['style'] || 't1';
const ST = SUB_STYLES[styleKey];
if (!ST) {
  console.error('未知字幕样式:', styleKey, '可选:', Object.keys(SUB_STYLES).join('/'));
  process.exit(1);
}

const PLAY_RES_X = parseInt(args['resx'] || 720, 10);
const PLAY_RES_Y = parseInt(args['resy'] || 1280, 10);
const FONT = args['font'] || ST.font || 'Microsoft YaHei';
const SIZE = parseFloat(args['size'] || ST.size);
const COLOR = args['color'] || ST.primary;
const OUTLINE = args['outline'] !== undefined ? parseInt(args['outline'], 10) : ST.outlineW;
const OUTLINE_COLOR = args['outline-color'] || ST.outline;
const MARGIN_V = parseInt(args['marginv'] || ST.marginv, 10);
const DRY = !!args['dry-run'];

const SUB_MARGIN_LR = 40;
const AVAIL_W = PLAY_RES_X - SUB_MARGIN_LR * 2;
const MAX_PER_LINE = parseInt(args['max'] || Math.max(6, Math.floor(AVAIL_W / SIZE)), 10);
const TARGET = parseInt(args['target'] || (MAX_PER_LINE + 2), 10);
const MAX_SCREEN = MAX_PER_LINE * 2;   // 一屏最多两行
const GAP_MIN = 0.10;                  // 视为「词间停顿」的最小间隔（秒）
const MIN_TAIL = 4;                    // 切开后剩余不足这么多字就别切（避免 2 字碎屏）

// ---------- 参数解析辅助 ----------
function parseSlice(s) {
  if (!s || s === true) return null;
  const segs = String(s).split(',').map(x => x.trim()).filter(Boolean).map(seg => {
    const m = seg.split('-');
    const from = parseFloat(m[0]);
    const to = parseFloat(m[1]);
    if (!isFinite(from) || !isFinite(to) || to <= from) throw new Error('--slice 段格式应为 start-end：' + seg);
    return { from, to };
  });
  return segs.length ? segs : null;
}
const SLICES = parseSlice(args['slice']);
const OUT_DUR = SLICES ? SLICES.reduce((a, s) => a + (s.to - s.from), 0) : null;

/** 原片时间 → 成片时间；落在任何保留段之外 → null（该字已被剪掉） */
function remap(t) {
  if (!SLICES) return t;
  let acc = 0;
  for (const s of SLICES) {
    if (t >= s.from && t < s.to) return acc + (t - s.from);
    acc += s.to - s.from;
  }
  return null;
}

function parseFix(s) {
  const list = [];
  if (!s || s === true) return list;
  String(s).split(',').forEach(kv => {
    const i = kv.indexOf('=');
    if (i > 0) list.push([kv.slice(0, i), kv.slice(i + 1)]);
  });
  return list;
}
const FIXES = parseFix(args['fix']);
FIXES.forEach(([a, b]) => {
  if (a.length !== b.length) {
    console.error(`ERR --fix 只支持【等长】替换（否则字符级时间戳会错位）："${a}"(${a.length}) → "${b}"(${b.length})`);
    process.exit(1);
  }
});
function applyFix(text) {
  let t = text;
  FIXES.forEach(([a, b]) => { t = t.split(a).join(b); });
  return t;
}

function fmt(t) {
  if (!isFinite(t) || t < 0) t = 0;
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  let cs = Math.round((t - Math.floor(t)) * 100);
  if (cs >= 100) cs = 99;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

// ---------- 断句依据 ----------
function cnLen(s) { return String(s).replace(/[\s\\N]/g, '').length; }

const PUNCT_AFTER = '，。！？；：、,;:';
const CONJ_BEFORE = ['但是', '然后', '因为', '所以', '如果', '其实', '而且', '不过', '这是',
  '这些', '这个', '现在', '那么', '于是', '另外', '同时', '只有', '只要', '无论', '虽然',
  '而是', '就是', '还有', '以及', '对于', '关于', '今天', '一样', '一起',
  '可以', '能够', '我们', '你们', '他们'];
const ADV_BEFORE = '不没很太更最就也还再又才都只把被让给和与在从向对要会能可这那而但却并';
const NUM_CHARS = '零一二三四五六七八九十百千万两〇';

// 常用词保护：ASR 只给单字时间戳，没有词边界，靠这张表兜住「发展/已经/可以」这类被拦腰切开
const WORD_GUARD = [
  '可以', '发展', '已经', '现在', '我们', '你们', '他们', '这个', '那个', '什么', '怎么',
  '这样', '那样', '时候', '问题', '销售', '客服', '咨询', '团队', '解决', '需要', '觉得',
  '知道', '希望', '体验', '免费', '评论', '老板', '美女', '真人', '训练', '助理', '聊天',
  '扮演', '各种', '不同', '职业', '岗位', '对话', '看看', '沟通', '水平', '调教', '主要',
  '应用', '场景', '售前', '售后', '常规', '基础', '人力', '节省', '大量', '很多', '如果',
  '那么', '然后', '因为', '所以', '但是', '不过', '其实', '而且', '以及', '还有', '就是',
  '而是', '只有', '只要', '无论', '虽然', '一样', '一起', '对于', '关于', '能够', '帮你',
  '推荐', '一个', '不是', '自己', '以上', '以下', '到底', '已经', '还是', '或者', '然后',
  // ---- 2026-09-24 补：私域 / AI 落地线常用词（原表按 09-17 那批内容攒，
  //      「智能体」等被拦腰切成「私域智 | 能体」，实测踩到。新内容线先扫一遍再补 ----
  '智能体', '私域', '客户', '落地', '跟进', '求职', '入职', '邀约', '数据', '分析',
  '转化', '自动化', '优化', '改进', '讨论', '管理', '沟通', '回访', '解决方案', '技术',
  '公司', '企业', '类型', '需求', '能力', '理解', '内容', '部分', '非常', '效率',
  '流程', '平台', '服务', '交付', '场景', '系统', '工具', '团队', '凌晨', '第一天',
  // ---- 2026-09-24 补（二）：取自 chengfeng-videocut 的 AI 用词词典（只取中文词面 + 常见拉丁专名），
  //      用于「不把专名拦腰切开」。⚠️ 这张表只保护换行，**不做 ASR 纠错**（铁律 1 一个字不许改）----
  '大模型', '工作流', '提示词', '知识库', '数字人', '口播', '短视频', '直播间', '公众号',
  '小程序', '朋友圈', '视频号', '抖音', '小红书', '获客', '引流', '留存', '复购', '客单价',
  '成交', '线索', '话术', '素材', '剪辑', '成片', '封面', '字幕', '选题', '赛道',
  '合伙人', '员工', '团队', '成本', '预算', '复盘', '标准化', '可复制', '竞争对手',
  'Agent', 'Prompt', 'Workflow', 'Token', 'Skill', 'Codex', 'Claude', 'ChatGPT', 'DeepSeek',
  'Kimi', 'Qwen', 'Copilot', 'Cursor', 'GitHub', 'Gemini', 'Sora', 'Midjourney',
  // ---- 2026-09-29 补（三）：微云真人直剪实测踩到 —— 「评论区」被切成「评论 | 区」、
  //      「想法发给AI」切成「发 | 给」、「数字形象」被拆。原表只有「评论」，
  //      而 inWordGuard 是**整词匹配**，短词保护不了长词的尾部，故补整词。
  //      「视频」此前仅由「短视频」间接覆盖，单独补上（剪视频/发视频高频）----
  '评论区', '发给', '视频', '数字形象', '转发', '点赞', '关注',
  // ---- 2026-10-07 补（四）：微云真人直剪 IMG_0015 实测踩到 ——
  //      「有针对性」被切成「有针 | 对性」（表里只有「针对」不成立，inWordGuard 是整词匹配）----
  '针对性', '有针对性',
  // ---- 2026-10-09 补（五）：微云真人直剪 IMG_0017/0018 实测踩到 ——
  //      「在一起」切成「在 | 一起」、「手把手」切成「手 | 把手」（表里只有「一起」不成立）----
  '在一起', '手把手',
  // ---- 2026-10-09 补（五）：微云真人直剪 lv_0_20261008200558 dry-run 逐屏核对踩到 ——
  //      「重要」被切成「重 | 要」、「存在」被切成「存 | 在」----
  '重要', '存在', '消息量', '偏科',
  //      + 同轮换行核对：「所有」切成「所 | 有」、「比如」切成「比 | 如」----
  '所有', '比如',
  // ---- 2026-10-14 补（六）：微云真人直剪 IMG_0023（xjz11）逐屏核对踩到 ----
  //      「真人感」切成「真人 | 感」（表里有「真人」但整体匹配，短词罩不住长词尾部）、
  //      「成都」切成「成 | 都」、「发布」切成「发 | 布」、「一分钟」切成「一 | 分钟」、
  //      「帮我们」切成「帮 | 我们」（表里只有「帮你」不成立）----
  '真人感', '成都', '发布', '一分钟', '帮我们',
];

const isNumCh = ch => NUM_CHARS.includes(ch) || /[0-9]/.test(ch);
const isLetter = ch => /[A-Za-z]/.test(ch);

/** 切点 k 是否落在某个保护词内部（k 是下一屏首字下标） */
function inWordGuard(chars, k) {
  for (const w of WORD_GUARD) {
    const L = w.length;
    for (let p = Math.max(0, k - L + 1); p < k; p++) {
      if (p + L > chars.length) continue;
      let s = '';
      for (let q = p; q < p + L; q++) s += chars[q].ch;
      if (s === w) return true;
    }
  }
  return false;
}

/** 切点 k 的语义等级；-1 = 硬禁 */
function tierAt(chars, k) {
  const prev = chars[k - 1].ch;
  const cur = chars[k].ch;
  if (isNumCh(prev) && isNumCh(cur)) return -1;            // 不拆数字（含阿拉伯数字）
  if (isLetter(prev) && isLetter(cur)) return -1;          // 不拆英文词
  if (inWordGuard(chars, k)) return -1;                    // 不拆常用词
  if (PUNCT_AFTER.includes(prev)) return 0;
  const rest = chars.slice(k, k + 4).map(c => c.ch).join('');
  if (CONJ_BEFORE.some(w => rest.startsWith(w))) return 1;
  if (ADV_BEFORE.includes(cur)) return 2;
  return 9;
}

/** 切点 k 处的字间停顿（秒） */
function gapAt(chars, k) {
  return Math.max(0, chars[k].start - chars[k - 1].end);
}

/** 把一屏文本按语义折两行（不超单行上限）；无需折行则原样返回 */
function wrapTwoLines(text) {
  const t = String(text).trim();
  if (cnLen(t) <= MAX_PER_LINE) return t;
  const arr = t.split('').map(ch => ({ ch }));
  let best = null;
  for (let i = 1; i < t.length; i++) {
    const l1 = cnLen(t.slice(0, i));
    const l2 = cnLen(t.slice(i));
    if (l1 > MAX_PER_LINE || l2 > MAX_PER_LINE) continue;
    const k = tierAt(arr, i);
    if (k < 0) continue;
    const score = k * 30 + Math.abs(l1 - l2);
    if (!best || score < best.score) best = { i, score };
  }
  const at = best ? best.i : Math.min(MAX_PER_LINE, Math.floor(t.length / 2));
  return t.slice(0, at).trim() + '\\N' + t.slice(at).trim();
}

// ---------- 读 ASR ----------
const raw = JSON.parse(fs.readFileSync(inFile, 'utf8'));
const R = raw.result || raw;
const utts = R.utterances || [];
if (!utts.length) { console.error('ERR ASR json 里没有 utterances（需要开 show_utterances=true）'); process.exit(1); }

/** 把一个 utterance 的 words 展开成字符级时间戳（含词边界信息） */
function uttChars(u) {
  const out = [];
  (u.words || []).forEach(w => {
    if (w.start_time < 0) return;                      // 分隔符
    const txt = String(w.text).replace(/\s/g, '');
    if (!txt) return;
    const n = txt.length;
    const dur = (w.end_time - w.start_time) / 1000;
    for (let k = 0; k < n; k++) {
      out.push({
        ch: txt[k],
        start: w.start_time / 1000 + dur * (k / n),
        end: w.start_time / 1000 + dur * ((k + 1) / n),
      });
    }
  });
  return out;
}

// ---------- 分屏 ----------
const screens = [];      // { text, start, end, utt }
const diffNotes = [];    // words 与 utterance.text 的差异（供人工确认）

utts.forEach((u, ui) => {
  const chars = uttChars(u);
  if (!chars.length) return;

  const fromWords = applyFix(chars.map(c => c.ch).join(''));
  const fromText = applyFix(String(u.text || '').replace(/\s/g, ''));
  if (fromText && fromWords !== fromText) {
    diffNotes.push({ utt: ui, text: fromText, words: fromWords });
  }

  // 重映射 + 按保留段切成若干连续 run（剪切点自然断开，不会串屏）
  const runs = [];
  let cur = [];
  chars.forEach(c => {
    const s = remap(c.start);
    const e = remap(c.end);
    if (s === null || e === null) {
      if (cur.length) runs.push(cur);
      cur = [];
      return;
    }
    cur.push({ ch: c.ch, start: s, end: e });
  });
  if (cur.length) runs.push(cur);

  runs.forEach(run => {
    let i = 0;
    while (i < run.length) {
      const remain = run.length - i;
      let j;
      if (remain <= MAX_SCREEN) {
        j = run.length;
      } else {
        const lo = i + MAX_PER_LINE;                       // 至少凑满一行
        const hi = Math.min(i + MAX_SCREEN, run.length - 1);
        const cands = [];
        for (let k = lo; k <= hi; k++) {
          if (run.length - k < MIN_TAIL) continue;          // 别切出「水平」这种 2 字尾屏
          const t = tierAt(run, k);
          if (t < 0) continue;
          cands.push({ k, t, gap: gapAt(run, k) });
        }
        if (cands.length) {
          // ① 语义切点（标点后 / 关联词前 / 虚词前）优先，且取**等级最高**的那一档
          const minT = Math.min(...cands.map(c => c.t));
          let pool = minT <= 2 ? cands.filter(c => c.t === minT) : [];
          // ② 其次：字间有明显停顿的地方（词间停顿，切了最自然）
          if (!pool.length) {
            const maxGap = Math.max(...cands.map(c => c.gap));
            if (maxGap >= GAP_MIN) pool = cands.filter(c => c.gap >= maxGap - 0.03);
          }
          // ③ 兜底：全部候选
          if (!pool.length) pool = cands;
          pool.sort((a, b) => Math.abs(a.k - i - TARGET) - Math.abs(b.k - i - TARGET));
          j = pool[0].k;
        } else {
          j = Math.min(i + MAX_SCREEN, run.length);       // 实在无处可切
        }
      }
      const seg = run.slice(i, j);
      screens.push({
        text: applyFix(seg.map(c => c.ch).join('')),
        start: seg[0].start,
        end: seg[seg.length - 1].end,
        utt: ui,
      });
      i = j;
    }
  });
});

if (!screens.length) { console.error('ERR 分屏结果为空（--slice 是否把所有内容都剪掉了？）'); process.exit(1); }

// 时间轴修边：尾端留 0.10s；与下一屏重叠则收住
screens.forEach((s, k) => {
  s.end = s.end + 0.10;
  if (OUT_DUR != null && s.end > OUT_DUR) s.end = OUT_DUR;
  const next = screens[k + 1];
  if (next && s.end > next.start) s.end = next.start;
  if (s.end - s.start < 0.5) s.end = Math.min(s.start + 0.5, next ? next.start : s.start + 0.5);
});

// ---------- 输出 ----------
let wrapped = 0;
const events = screens.map(s => {
  const txt = wrapTwoLines(s.text);
  if (txt.includes('\\N')) wrapped++;
  return `Dialogue: 0,${fmt(s.start)},${fmt(s.end)},MuziqiSubtitle,,0,0,0,,${txt}`;
});

console.log(`分屏：${screens.length} 屏 | 单行上限 ${MAX_PER_LINE} 字 | ${wrapped} 屏折成两行`);
if (diffNotes.length) {
  console.log(`⚠️ ${diffNotes.length} 处 words 与 utterance.text 不一致（本脚本以 words 为准，请人工确认）：`);
  diffNotes.forEach(d => console.log(`   [utt ${d.utt}] text="${d.text}"  vs  words="${d.words}"`));
}
if (DRY) {
  screens.forEach((s, k) => {
    console.log(`[${String(k).padStart(2)}] ${s.start.toFixed(2)}→${s.end.toFixed(2)} (${(s.end - s.start).toFixed(2)}s, ${s.text.length}字) ${s.text}`);
  });
}

if (!DRY) {
  const ass = `[Script Info]
ScriptType: v4.00+
PlayResX: ${PLAY_RES_X}
PlayResY: ${PLAY_RES_Y}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: MuziqiSubtitle,${FONT},${SIZE},${COLOR},${COLOR},${OUTLINE_COLOR},${ST.back},-1,0,0,0,100,100,0,0,${ST.border},${OUTLINE},${ST.shadow},2,${SUB_MARGIN_LR},${SUB_MARGIN_LR},${MARGIN_V},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
${events.join('\n')}
`;
  fs.writeFileSync(outFile, ass, 'utf8');
  console.log(`written: ${outFile}  [--style ${styleKey} ${ST.name}]`);
  if (args['out-txt']) {
    const txt = screens.map(s => s.text).join('');
    fs.writeFileSync(args['out-txt'], txt, 'utf8');
    console.log(`written: ${args['out-txt']}  (字幕纯文本稿 ${txt.length} 字)`);
  }
  if (OUT_DUR != null) console.log(`成片时长（按 --slice 计算）: ${OUT_DUR.toFixed(2)}s`);
  const last = screens[screens.length - 1];
  console.log(`字幕覆盖: ${screens[0].start.toFixed(2)}s → ${last.end.toFixed(2)}s`);
  console.log(`字数核对: 字幕 ${screens.map(s => s.text).join('').length} 字`);
}
