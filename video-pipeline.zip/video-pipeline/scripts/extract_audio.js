#!/usr/bin/env node
/**
 * extract_audio.js —— 抽音轨为 ASR 可用的单声道 wav（通用）
 *
 * 云 ASR（火山录音识别 / Whisper 等）统一吃 **16k 单声道 16bit PCM**；
 * 直接把原始视频的音轨喂过去，常因采样率/声道数不被接受而白等一轮。
 * 这一步做归一化 —— 同时也是「音画分离」的落地点：后续所有转写/定界都只认这个 wav。
 *
 * 🔴 先跑 probe.js 确认有音轨：**无音轨的素材抽音频会失败**，别浪费一轮。
 *
 * 用法：
 *   node extract_audio.js --in IMG_0024.MP4 --out audio.wav
 *   node extract_audio.js --in a.mp4 --out a.wav --rate 16000 --channels 1
 */
const fs = require('fs');
const path = require('path');
const { FFMPEG, run } = require('./_ff.js');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--')) {
    const k = process.argv[i].slice(2);
    args[k] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
  }
}
for (const k of ['in', 'out']) if (!args[k]) { console.error('ERR 缺 --' + k); process.exit(2); }
if (!fs.existsSync(args['in'])) { console.error('ERR 素材不存在 ' + args['in']); process.exit(2); }

const rate = Number(args.rate || 16000);
const channels = Number(args.channels || 1);
const out = path.resolve(args.out);

console.log(`抽音频 ${path.basename(args['in'])} → ${out}（${rate}Hz / ${channels}ch / pcm_s16le）`);
run(FFMPEG, ['-y', '-v', 'error', '-i', args['in'],
  '-vn', '-ac', String(channels), '-ar', String(rate), '-c:a', 'pcm_s16le', out]);
console.log(`已输出 ${out} (${(fs.statSync(out).size / 1024).toFixed(0)} KB)`);
