#!/usr/bin/env node
/**
 * burn_subs.js —— 烧字幕出成片（通用 · 标准件）
 *
 * 两个「必须按规矩来」的点，都是踩过的坑，已固化成默认行为：
 *
 *  ① **用相对 ass 文件名 + cwd = ass 所在目录**
 *     ffmpeg 的 ass 滤镜对路径里的 `:` 和 `\` 都要转义，走到 Windows 中文路径时
 *     尤其脆弱 —— 常报 `Unable to parse option value`，或者静默不烧字幕、
 *     交出一份没字幕的成片。改成 cwd + 相对文件名，这问题直接绕开。
 *
 *  ② **显式给 fontsdir**
 *     不给的话 libass 走 fontconfig，指不到指定字体就**静默回落系统默认字体**，
 *     成片字体「莫名变了」。默认取 VP_FONTS_DIR，或 <skill>/fonts。
 *
 * 用法：
 *   node burn_subs.js --in body.mp4 --ass subtitles.ass --out final.mp4
 *   node burn_subs.js --in body.mp4 --ass subs.ass --out final.mp4 --fontsdir /data/fonts
 *   node burn_subs.js --in body.mp4 --ass subs.ass --out final.mp4 --crf 18 --preset medium
 */
const fs = require('fs');
const path = require('path');
const { FFMPEG, run } = require('./_ff.js');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--')) {
    const k = process.argv[i].slice(2);
    args[k] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
  }
}
for (const k of ['in', 'ass', 'out']) if (!args[k]) { console.error('ERR 缺 --' + k); process.exit(2); }
for (const k of [args['in'], args.ass]) if (!fs.existsSync(k)) { console.error('ERR 文件不存在 ' + k); process.exit(2); }

const inAbs = path.resolve(args['in']);
const outAbs = path.resolve(args.out);
const assAbs = path.resolve(args.ass);
const assDir = path.dirname(assAbs);
const assName = path.basename(assAbs);

const fonts = path.resolve(args.fontsdir || process.env.VP_FONTS_DIR || path.join(__dirname, '..', 'fonts'));
if (!fs.existsSync(fonts)) {
  console.warn('WARN 字体目录不存在：' + fonts + ' —— libass 会回落到系统默认字体，成片字体与预期不符');
}

// ffmpeg 滤镜内的路径：统一正斜杠 + 冒号转义
const esc = (p) => p.replace(/\\/g, '/').replace(/:/g, '\\:');
const vf = `ass=${assName}:fontsdir='${esc(fonts)}'`;

const crf = String(args.crf || 18);
const preset = args.preset || 'medium';

console.log(`烧字幕：${path.basename(inAbs)} + ${assName}（cwd=${assDir}）`);
const t0 = Date.now();
run(FFMPEG, ['-y', '-v', 'error',
  '-i', inAbs,
  '-vf', vf,
  '-map', '0:v', '-map', '0:a?',
  '-c:v', 'libx264', '-crf', crf, '-preset', preset, '-pix_fmt', 'yuv420p',
  '-c:a', 'copy', '-movflags', '+faststart', outAbs], { cwd: assDir });
console.log(`已输出 ${outAbs} (${(fs.statSync(outAbs).size / 1048576).toFixed(1)} MB, ${((Date.now() - t0) / 1000).toFixed(0)}s)`);
