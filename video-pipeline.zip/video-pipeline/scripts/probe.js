#!/usr/bin/env node
/**
 * probe.js —— 素材体检（通用）
 *
 * 动手剪之前，先看清「手里这坨素材到底有什么」：时长、分辨率、帧率、**有没有音轨**、
 * 是竖版还是横版。剪辑链上最容易白干的两件事，都能在这一步挡掉：
 *   ① 素材根本没有音轨，却先去抽音频、跑 ASR（跑完才发现没声音）；
 *   ② 分辨率猜错，缩放时把画面拉变形。
 *
 * 用法：
 *   node probe.js --in IMG_0024.MP4
 *   node probe.js --in a.mp4 --json          # 结构化输出，给后面的脚本吃
 *
 * 退出码：0 = 正常；2 = 参数/文件问题；3 = 无音轨（可据此跳过口播链路）。
 */
const fs = require('fs');
const { FFPROBE, capture } = require('./_ff.js');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--')) {
    const k = process.argv[i].slice(2);
    args[k] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true;
  }
}
if (!args['in']) { console.error('ERR 缺 --in <素材文件>'); process.exit(2); }
if (!fs.existsSync(args['in'])) { console.error('ERR 文件不存在 ' + args['in']); process.exit(2); }

const j = JSON.parse(capture(FFPROBE, ['-v', 'error', '-print_format', 'json',
  '-show_format', '-show_streams', args['in']]));
const v = (j.streams || []).find((s) => s.codec_type === 'video');
const a = (j.streams || []).find((s) => s.codec_type === 'audio');
const num = (s) => { const p = String(s || '0/1').split('/').map(Number); return p[1] ? p[0] / p[1] : 0; };

const info = {
  file: args['in'],
  bytes: Number(j.format && j.format.size) || fs.statSync(args['in']).size,
  duration: Number(j.format && j.format.duration) || 0,
  video: v ? { codec: v.codec_name, width: v.width, height: v.height, fps: +num(v.r_frame_rate).toFixed(3) } : null,
  audio: a ? { codec: a.codec_name, sampleRate: Number(a.sample_rate) || 0, channels: a.channels } : null,
};
info.mb = +(info.bytes / 1048576).toFixed(1);
info.portrait = !!(v && v.height > v.width);

if (args.json) {
  console.log(JSON.stringify(info, null, 2));
} else {
  console.log(`文件       ${info.file}`);
  console.log(`大小/时长  ${info.mb} MB / ${info.duration.toFixed(2)}s`);
  console.log(`画面       ${v ? `${info.video.width}x${info.video.height} ${info.video.codec} ${info.video.fps}fps ${info.portrait ? '(竖版)' : '(横版)'}` : '⛔ 无视频轨'}`);
  console.log(`音轨       ${a ? `${info.audio.codec} ${info.audio.sampleRate}Hz ${info.audio.channels}ch` : '⛔ 无音轨'}`);
}
if (!v) { console.error('\nWARN 没有视频轨：这可能是纯音频文件，剪辑链路不适用。'); process.exit(3); }
if (!a) { console.error('\nWARN 没有音轨：抽音频 / 转写 / 口播链路无法进行，先确认素材。'); process.exit(3); }
