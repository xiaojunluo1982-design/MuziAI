'use strict';
/**
 * _ff.js —— ffmpeg / ffprobe 定位与调用（跨机通用）
 *
 * 定位顺序：环境变量 VP_FFMPEG / VP_FFPROBE（指向可执行文件）→ PATH 里的裸命令。
 * 环境变量指向的文件不存在时**显式 WARN** 再回落，不静默换工具。
 * 两条路都没有时，后续调用会以 ENOENT 明确失败 —— 好过「跑出一个空文件」。
 *
 * 用法：const { FFMPEG, FFPROBE, run, capture } = require('./_ff.js');
 */
const { execFileSync } = require('child_process');
const fs = require('fs');

const resolveBin = (envVar, bare) => {
  const v = process.env[envVar];
  if (v) {
    if (fs.existsSync(v)) return v;
    console.error(`WARN ${envVar} 指向的文件不存在：${v} —— 回落 PATH 里的 ${bare}`);
  }
  return bare;
};

const FFMPEG = resolveBin('VP_FFMPEG', 'ffmpeg');
const FFPROBE = resolveBin('VP_FFPROBE', 'ffprobe');

const run = (bin, args, opts) =>
  execFileSync(bin, args, Object.assign({ stdio: 'inherit', timeout: 3600000 }, opts || {}));

const capture = (bin, args) =>
  execFileSync(bin, args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });

module.exports = { FFMPEG, FFPROBE, run, capture };
