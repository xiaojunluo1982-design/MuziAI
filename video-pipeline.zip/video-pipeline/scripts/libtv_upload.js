#!/usr/bin/env node
/**
 * libtv_upload.js —— 把本地文件按 LibTV 的签名分片票据 PUT 到 OSS（LibTV 通道第 ② 步）
 *
 * 为什么要有它（2026-09-30 收进 skill）：
 *   LibTV 的 MCP **没有「直接传文件」的工具**，必须走三步：
 *     ① `mcp__LibTV__upload_ticket {file_name, file_size}`   → parts[]（带签名 URL）
 *     ② **本脚本**：逐片 PUT，收集 ETag
 *     ③ `mcp__LibTV__upload_complete {path, upload_id}`      → `url`（长期有效）/ `file_ref`
 *   这份实现原来只存在于某个交付物的 `_libtv/upload.js` 里 —— 那不是"可复用资产"，
 *   换个项目就得重写。收进 skill 后跨项目共用。
 *
 * 用法:
 *   node libtv_upload.js <本地文件> <ticket.json> [etags输出.json]
 *
 * 要点（都是踩过的）:
 *   - 分片大小默认 5MB；**偏移必须按 partNumber 现算**，不能假设票据里只有 1 片。
 *   - 🔴 **只能用 `upload_complete` 返回的 `url`**（形如
 *     `https://libtv-res.liblib.art/upload-images/<uuid>/<sha1>.<ext>`，长期有效）。
 *     `file_ref` 是**一次性**的 —— 拿它去调 `resource_info` 会报 `invalid opaque token`。
 *   - 🔴 票据里的 url 带 `Expires` 签名 → **拿到就尽快传，别拖延**。
 *   - ETag **不用回传**给服务端（`upload_complete` 只要 `path` + `upload_id`，服务端自己
 *     ListParts），但打印出来便于排查。
 *   - 上传目录叫 `upload-images/` —— **图片和视频都走这一个目录**，别被名字误导。
 */
const fs = require('fs');
const path = require('path');

const [file, ticketPath, outPath] = process.argv.slice(2);
if (!file || !ticketPath) {
  console.error('用法: node libtv_upload.js <本地文件> <ticket.json> [etags输出.json]');
  process.exit(2);
}
if (!fs.existsSync(file)) { console.error('文件不存在:', file); process.exit(2); }
if (!fs.existsSync(ticketPath)) { console.error('票据不存在:', ticketPath); process.exit(2); }

const t = JSON.parse(fs.readFileSync(ticketPath, 'utf8'));
const buf = fs.readFileSync(file);
const PART = 5242880;

(async () => {
  console.log('file bytes =', buf.length, ' parts =', (t.parts || []).length);
  const etags = [];
  for (const p of t.parts) {
    const i = p.partNumber - 1;
    const start = i * PART;
    const end = Math.min(start + PART, buf.length);
    const body = buf.subarray(start, end);
    const res = await fetch(p.url, { method: 'PUT', body });
    const etag = res.headers.get('etag');
    console.log('part', p.partNumber, 'status', res.status, 'bytes', body.length, 'etag', etag);
    if (!res.ok) {
      console.log('ERROR BODY:', (await res.text()).slice(0, 400));
      process.exit(1);
    }
    etags.push({ partNumber: p.partNumber, etag });
  }
  const out = { path: t.path, uploadId: t.uploadId, etags };
  const dst = outPath || path.join(path.dirname(ticketPath), 'upload_etags.json');
  fs.writeFileSync(dst, JSON.stringify(out, null, 2));
  console.log('UPLOAD_DONE →', dst);
})();
