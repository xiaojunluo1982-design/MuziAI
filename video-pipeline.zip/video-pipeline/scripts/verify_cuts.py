#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_cuts.py — 成片剪接自检（渲染后回抽帧）

设计来自 browser-use/video-use 的「渲染后自评」机制：
不看全片，只抽帧 + 判「人脸是否还在画面里」，自动找出

  (1) 段内持续离画   —— 手机转向拍天花板/大屏、走开、长时间甩动
  (2) 段内断续离画   —— 缓慢转头（人脸在画率掉下来，但从不出现长空档）
  (3) 剪接点跳变     —— 构图位移、人脸尺度突变、一侧人脸消失

为什么需要它：
  2026-09-24 那条微云素材直剪，ASR 显示 96.7–99.5s 是正常说话段、silencedetect 也测不到，
  但镜头其实 92.75s 就开始转了（人脸在画率从 ~95% 掉到 47%）。
  语音层面看不见的问题，只能在像素层面查。

用法：
  python verify_cuts.py --video <成片.mp4> [--segments "1.60-66.90,67.27-75.50,..."] \
         --out-dir <输出目录>

  --segments 用「源时间」，与 asr_to_ass --slice 同一套值；给了才会做剪接点跳变检查。
  不给则只做段内巡检（查原片素材的问题段）。

退出码：0=PASS  1=WARN  2=FAIL  3=环境/入参错误
"""
import argparse
import json
import os
import re
import subprocess
import sys

import numpy as np
import cv2

try:
    cv2.setNumThreads(0)   # 0=自动用满多核；单线程跑 Haar 会慢很多
except Exception:
    pass

# 级联顺序 = 尝试顺序，命中即短路（速度关键）
CASCADES = (
    ("haarcascade_frontalface_default.xml", 1.0),   # 面积下限系数（× --min-face-area）
    ("haarcascade_frontalface_alt2.xml", 1.0),
    ("haarcascade_profileface.xml", 3.0),           # 侧脸误检多，门槛抬高
)
DEFAULT_FFMPEG_DIR = "C:/Users/admin/.workbuddy/bin/ffmpeg/bin"
FONT_CANDIDATES = (
    "C:/Users/admin/.workbuddy/fonts/NotoSansSC-Bold.ttf",
    "C:/Users/admin/.workbuddy/fonts/NotoSansSC-Regular.ttf",
    "C:/Windows/Fonts/msyhbd.ttc",
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
)


def log(msg):
    sys.stderr.write(msg + "\n")
    sys.stderr.flush()


# ---------- 基础工具 ----------

def which(name, extra_dir=None):
    import shutil
    p = shutil.which(name)
    if p:
        return p
    if extra_dir:
        for cand in (name, name + ".exe"):
            fp = os.path.join(extra_dir, cand)
            if os.path.isfile(fp):
                return fp
    return None


def _rotation_swap(ffprobe, video, w, h):
    """竖屏素材带 rotation 侧数据，ffprobe 报的宽高是「编码尺寸」，要换回来。"""
    out = subprocess.run(
        [ffprobe, "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height:stream_side_data=rotation",
         "-of", "json", video],
        capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    st = ((json.loads(out or "{}").get("streams") or [{}])[0])
    rot = 0
    for sd in (st.get("side_data_list") or []):
        if "rotation" in sd:
            rot = abs(int(float(sd["rotation"])))
    if rot == 0:
        t = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream_tags=rotate", "-of", "json", video],
            capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
        try:
            tg = ((json.loads(t or "{}").get("streams") or [{}])[0].get("tags") or {})
            rot = abs(int(float(tg.get("rotate", 0))))
        except Exception:
            rot = 0
    return (h, w) if rot % 180 == 90 else (w, h)


def probe_display_size(ffprobe, video):
    out = subprocess.run(
        [ffprobe, "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "json", video],
        capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    st = ((json.loads(out or "{}").get("streams") or [{}])[0])
    return _rotation_swap(ffprobe, video, int(st.get("width") or 0), int(st.get("height") or 0))


def probe_duration(ffprobe, video):
    out = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", video],
        capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip()
    try:
        return float(out)
    except ValueError:
        return 0.0


class Detector:
    """人脸在画检测器：级联按顺序试，命中（且面积过门槛）即返回。"""

    def __init__(self, w, h, min_face_area):
        self.w, self.h, self.area = w, h, float(w * h)
        self.min_face_area = min_face_area
        self.min_side = max(16, int(w * 0.09))
        self.max_side = max(self.min_side + 16, int(w * 0.80))
        self.cas = []
        for name, fac in CASCADES:
            path = os.path.join(cv2.data.haarcascades, name)
            if os.path.isfile(path):
                c = cv2.CascadeClassifier(path)
                if not c.empty():
                    self.cas.append((c, min_face_area * fac))
        if not self.cas:
            raise RuntimeError("OpenCV 自带级联都加载失败")

    def _one(self, c, gray, floor):
        r = c.detectMultiScale(gray, 1.15, 5,
                               minSize=(self.min_side, self.min_side),
                               maxSize=(self.max_side, self.max_side))
        if len(r) == 0:
            return None
        x, y, bw, bh = (int(v) for v in max(r, key=lambda b: int(b[2]) * int(b[3])))
        pct = bw * bh / self.area * 100.0
        if pct < floor:
            return None
        return {"x": x, "y": y, "w": bw, "h": bh, "area_pct": pct,
                "cx": (x + bw / 2.0) / self.w, "cy": (y + bh / 2.0) / self.h}

    def measure(self, bgr):
        g = cv2.equalizeHist(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY))
        for c, floor in self.cas:
            m = self._one(c, g, floor)
            if m is not None:
                return m
        return None


def read_frames(ffmpeg, video, fps, w, h, total_hint=0):
    """流式抽帧：ffmpeg 管道出 rawvideo bgr24，免落盘、免中文路径坑。"""
    cmd = [ffmpeg, "-v", "error", "-i", video,
           "-vf", "fps=%s,scale=%d:%d" % (fps, w, h),
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    nbytes = w * h * 3
    i = 0
    try:
        while True:
            buf = p.stdout.read(nbytes)
            if len(buf) < nbytes:
                break
            yield i / float(fps), np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            i += 1
            if total_hint and i % 400 == 0:
                log("  ... 已巡检 %d 帧 / 约 %d" % (i, total_hint))
    finally:
        try:
            p.stdout.close()
        except Exception:
            pass
        p.wait()


def grab_at(ffmpeg, video, t, w, h):
    if t < 0:
        t = 0.0
    cmd = [ffmpeg, "-v", "error", "-ss", "%.3f" % t, "-i", video,
           "-frames:v", "1", "-vf", "scale=%d:%d" % (w, h),
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    out = subprocess.run(cmd, capture_output=True).stdout
    n = w * h * 3
    if len(out) < n:
        return None
    return np.frombuffer(out[:n], np.uint8).reshape(h, w, 3)


# ---------- 时间映射 ----------

def parse_segments(spec):
    segs = []
    for part in (spec or "").replace("，", ",").split(","):
        part = part.strip()
        if not part:
            continue
        m = re.match(r"^([\d.]+)\s*-\s*([\d.]+)$", part)
        if not m:
            raise ValueError("段格式不对：%r（应形如 1.60-66.90）" % part)
        a, b = float(m.group(1)), float(m.group(2))
        if b <= a:
            raise ValueError("段起止反了：%r" % part)
        segs.append((a, b))
    return segs


def build_map(segs):
    table, cum = [], 0.0
    for a, b in segs:
        table.append((cum, cum + (b - a), a, b))
        cum += (b - a)
    return table, cum


def to_source(t_render, table):
    for r0, r1, s0, s1 in table:
        if r0 - 1e-6 <= t_render <= r1 + 1e-6:
            return s0 + (t_render - r0)
    return None


def merge_spans(spans):
    if not spans:
        return []
    spans = sorted(spans)
    out = [list(spans[0])]
    for a, b in spans[1:]:
        if a <= out[-1][1] + 1e-6:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


# ---------- 主流程 ----------

def main():
    ap = argparse.ArgumentParser(description="成片剪接自检（渲染后回抽帧）")
    ap.add_argument("--video", required=True, help="要检查的成片（或原片）")
    ap.add_argument("--segments", default="", help="保留段（源时间）a-b,c-d,...")
    ap.add_argument("--out-dir", default=".", help="输出目录")
    ap.add_argument("--report", default="cut_report.md", help="报告文件名")
    ap.add_argument("--sheet", default="contact_sheet.jpg", help="拼接图文件名")
    ap.add_argument("--json", dest="json_out", default="cut_report.json", help="机器可读结果；留空=不写")
    ap.add_argument("--fps-scan", type=float, default=4.0, help="段内巡检采样率")
    ap.add_argument("--scale-w", type=int, default=240, help="巡检缩放宽（越小越快）")
    ap.add_argument("--min-face-area", type=float, default=2.0, help="人脸面积绝对下限（占画面 %%）")
    ap.add_argument("--baseline-factor", type=float, default=0.25, help="人脸面积相对基线下限")
    ap.add_argument("--min-run", type=float, default=2.0, help="连续离画多久判 FAIL（秒）")
    ap.add_argument("--window", type=float, default=4.0, help="在画率滑动窗口（秒）")
    ap.add_argument("--min-ratio", type=float, default=0.60, help="窗口内在画率下限")
    ap.add_argument("--junction-window", type=float, default=0.15, help="剪接点前后取样间隔（秒）")
    ap.add_argument("--no-sheet", action="store_true", help="不生成拼接图")
    a = ap.parse_args()

    fdir = DEFAULT_FFMPEG_DIR if os.path.isdir(DEFAULT_FFMPEG_DIR) else None
    ffmpeg, ffprobe = which("ffmpeg", fdir), which("ffprobe", fdir)
    if not ffmpeg or not ffprobe:
        log("找不到 ffmpeg/ffprobe")
        return 3
    if not os.path.isfile(a.video):
        log("找不到视频：%s" % a.video)
        return 3

    os.makedirs(a.out_dir, exist_ok=True)
    dw, dh = probe_display_size(ffprobe, a.video)
    dur = probe_duration(ffprobe, a.video)
    if dw <= 0 or dh <= 0:
        log("取不到视频尺寸")
        return 3

    sw = max(160, a.scale_w - (a.scale_w % 16))
    sh = int(round(sw * dh / float(dw)))
    sh -= sh % 16
    if sh <= 0:
        sh = 16

    segs = parse_segments(a.segments)
    table, seg_total = build_map(segs) if segs else ([], 0.0)
    det = Detector(sw, sh, a.min_face_area)

    # --- 1) 段内巡检 ---
    log("巡检中：%s @%gfps scale=%d" % (os.path.basename(a.video), a.fps_scan, sw))
    samples = []
    for t, frame in read_frames(ffmpeg, a.video, a.fps_scan, sw, sh,
                                int(dur * a.fps_scan) if dur else 0):
        samples.append({"t": round(t, 3), "m": det.measure(frame)})
    if not samples:
        log("没抽到帧")
        return 3

    areas = [s["m"]["area_pct"] for s in samples if s["m"]]
    base = float(np.median(areas)) if areas else 0.0
    thr = max(a.min_face_area, a.baseline_factor * base)
    for s in samples:
        s["ok"] = bool(s["m"] and s["m"]["area_pct"] >= thr)

    step = 1.0 / a.fps_scan

    # 2a) 连续离画
    raw_gaps, run = [], None
    for s in samples:
        if not s["ok"]:
            run = run or [s["t"], s["t"]]
            run[1] = s["t"]
        else:
            if run:
                raw_gaps.append(run)
            run = None
    if run:
        raw_gaps.append(run)
    gaps = [(g0, g1 + step) for g0, g1 in raw_gaps]
    hard = [(g0, g1) for g0, g1 in gaps if g1 - g0 >= a.min_run]
    soft = [(g0, g1) for g0, g1 in gaps if 0.3 <= g1 - g0 < a.min_run]

    # 2b) 滑动窗口在画率（抓「缓慢转头」：从不出现长空档，但在画率塌了）
    nwin = max(1, int(round(a.window * a.fps_scan)))
    low_spans, ratios = [], []
    for i in range(len(samples)):
        seg = samples[i:i + nwin]
        if len(seg) < max(2, nwin // 2):
            break
        r = sum(1 for x in seg if x["ok"]) / float(len(seg))
        ratios.append({"t0": samples[i]["t"], "t1": seg[-1]["t"], "ratio": round(r, 3)})
        if r < a.min_ratio:
            low_spans.append((samples[i]["t"], seg[-1]["t"]))
    low = [(x, y) for x, y in merge_spans(low_spans) if y - x >= a.window * 0.6]

    # --- 3) 剪接点跳变 ---
    junctions = []
    if segs:
        acc = 0.0
        for i, (s0, s1) in enumerate(segs):
            acc += (s1 - s0)
            if i == len(segs) - 1:
                break
            tj = acc
            fa = grab_at(ffmpeg, a.video, tj - a.junction_window, sw, sh)
            fb = grab_at(ffmpeg, a.video, tj + a.junction_window, sw, sh)
            ma = det.measure(fa) if fa is not None else None
            mb = det.measure(fb) if fb is not None else None
            j = {"t": round(tj, 3), "before": ma, "after": mb, "flags": []}
            if ma and mb:
                dcx, dcy = abs(ma["cx"] - mb["cx"]), abs(ma["cy"] - mb["cy"])
                darea = abs(ma["area_pct"] - mb["area_pct"]) / max(ma["area_pct"], mb["area_pct"], 1e-6)
                j.update(d_cx=round(dcx, 3), d_cy=round(dcy, 3), d_area_rel=round(darea, 3))
                if dcx > 0.35 or dcy > 0.35:
                    j["flags"].append("构图横向跳变（人脸位移 %.2f）" % max(dcx, dcy))
                if darea > 0.60:
                    j["flags"].append("人脸尺度突变 %.0f%%（疑似跳帧/换镜）" % (darea * 100))
            elif (ma is None) != (mb is None):
                j["flags"].append("一侧人脸消失（可能剪到离画内容）")
            j["ok"] = not j["flags"]
            junctions.append(j)
            log("  剪接点 %.2fs → %s" % (tj, "OK" if j["ok"] else "；".join(j["flags"])))

    # --- 4) 判定 ---
    jbad = [j for j in junctions if not j["ok"]]
    if hard or low or jbad:
        verdict = "FAIL"
    elif soft:
        verdict = "WARN"
    else:
        verdict = "PASS"

    # --- 5) 拼接图 ---
    sheet_name = ""
    if not a.no_sheet:
        try:
            from PIL import Image, ImageDraw, ImageFont
            pick = set()
            for g0, g1 in (hard + low):
                for s in samples:
                    if g0 - 1e-6 <= s["t"] <= g1 + 1e-6:
                        pick.add(s["t"])
            stride = max(1, len(samples) // 24)
            for k in range(0, len(samples), stride):
                pick.add(samples[k]["t"])
            for j in junctions:
                for dt in (-a.junction_window, a.junction_window, 0.0):
                    tt = j["t"] + dt
                    pick.add(min((s["t"] for s in samples), key=lambda x: abs(x - tt)))
            chosen = sorted(p for p in pick if p is not None)[:60]
            bad_t = set()
            for g0, g1 in (hard + low):
                for p in chosen:
                    if g0 - 1e-6 <= p <= g1 + 1e-6:
                        bad_t.add(p)

            tw = 162
            th = int(round(tw * sh / float(sw)))
            cols = max(1, min(6, len(chosen)))
            rows = (len(chosen) + cols - 1) // cols
            pad, lh = 6, 22
            cw, chh = tw + pad * 2, th + lh + pad * 2
            sheet = Image.new("RGB", (cols * cw, rows * chh), (244, 245, 248))
            dr = ImageDraw.Draw(sheet)
            font = None
            for fp in FONT_CANDIDATES:
                if os.path.isfile(fp):
                    try:
                        font = ImageFont.truetype(fp, 15)
                        break
                    except Exception:
                        pass
            if font is None:
                font = ImageFont.load_default()
            for idx, t in enumerate(chosen):
                fr = grab_at(ffmpeg, a.video, t, sw, sh)
                if fr is None:
                    continue
                im = Image.fromarray(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)).resize((tw, th))
                gx, gy = (idx % cols) * cw, (idx // cols) * chh
                bx, by = gx + pad, gy + lh + pad
                sheet.paste(im, (bx, by))
                bad = t in bad_t
                dr.rectangle([bx - 2, by - 2, bx + tw + 1, by + th + 1],
                             outline=(214, 40, 40) if bad else (150, 155, 165), width=3 if bad else 1)
                src = to_source(t, table) if table else None
                dr.text((gx + pad, gy + pad - 1),
                        "%.1fs" % t + (" →源%.1f" % src if src is not None else ""),
                        fill=(214, 40, 40) if bad else (60, 64, 74), font=font)
            sheet.save(os.path.join(a.out_dir, a.sheet), quality=88)
            sheet_name = a.sheet
        except Exception as e:
            log("拼接图生成失败（不影响判定）：%s" % e)

    # --- 6) 报告 ---
    L = ["# 剪接自检报告", "",
         "- 视频：`%s`" % os.path.basename(a.video),
         "- 时长：%.2fs ｜ 显示尺寸 %d×%d ｜ 巡检 %g fps（%d 帧）"
         % (dur, dw, dh, a.fps_scan, len(samples)),
         "- 人脸面积基线：%.2f%% ｜ 判定阈值：%.2f%%" % (base, thr)]
    if segs:
        L.append("- 保留段：%s → 成片 %.2fs（切点 %d 个）"
                 % (", ".join("%.2f-%.2f" % s for s in segs), seg_total, len(junctions)))
    L += ["", "## 结论：**%s**" % verdict, ""]

    if verdict == "PASS":
        L += ["段内人脸全程在画（窗口在画率 ≥ %.0f%%），剪接点构图与尺度连续。"
              % (a.min_ratio * 100), ""]

    if hard:
        L += ["**① 段内持续离画（≥%.1fs，需处理）**" % a.min_run, "",
              "| 成片段内时间 | 源时间 | 时长 | 推断 |", "|---|---|---|---|"]
        for g0, g1 in hard:
            s0 = to_source(g0, table) if table else None
            s1 = to_source(g1, table) if table else None
            src = ("%.2f-%.2f" % (s0, s1)) if (s0 is not None and s1 is not None) else "—"
            L.append("| %.2f-%.2fs | %s | %.2fs | 镜头转向/走开/长时间甩动 |"
                     % (g0, g1, src, g1 - g0))
        L.append("")

    if low:
        L += ["**② 段内断续离画（%.0fs 窗口内在画率 < %.0f%%，疑似缓慢转头）**"
              % (a.window, a.min_ratio * 100), "",
              "| 成片段内时间 | 源时间 | 窗口在画率 |", "|---|---|---|"]
        for x, y in low:
            s0 = to_source(x, table) if table else None
            s1 = to_source(y, table) if table else None
            src = ("%.2f-%.2f" % (s0, s1)) if (s0 is not None and s1 is not None) else "—"
            rs = [r["ratio"] for r in ratios if x - 1e-6 <= r["t0"] <= y + 1e-6]
            rtxt = ("最低 %.0f%%" % (min(rs) * 100)) if rs else "—"
            L.append("| %.2f-%.2fs | %s | %s |" % (x, y, src, rtxt))
        L.append("")

    if soft:
        L += ["**③ 短暂离画（<%.1fs，多为甩动过渡/单帧误检，可忽略但要扫一眼）**：%s"
              % (a.min_run, "、".join("%.2f-%.2fs" % g for g in soft)), ""]

    if jbad:
        L += ["**④ 剪接点异常**", "", "| 成片位置 | 问题 |", "|---|---|"]
        for j in jbad:
            L.append("| %.2fs | %s |" % (j["t"], "；".join(j["flags"])))
        L.append("")
    elif segs:
        L += ["剪接点 %d 个全部通过（构图与尺度连续）。" % len(junctions), ""]

    if sheet_name:
        L += ["拼接图：`%s`（红框=可疑帧，标注成片时间与对应源时间）" % sheet_name, ""]

    L += ["---",
          "*verify_cuts.py ｜ 判据：人脸面积 ≥ max(%.1f%%, %.2f×基线)；在画率窗口 %.0fs / 下限 %.0f%%*"
          % (a.min_face_area, a.baseline_factor, a.window, a.min_ratio * 100)]

    report = "\n".join(L)
    rp = os.path.join(a.out_dir, a.report)
    with open(rp, "w", encoding="utf-8") as f:
        f.write(report + "\n")

    result = {
        "video": a.video, "duration": round(dur, 3), "display": [dw, dh],
        "baseline_area_pct": round(base, 3), "threshold_pct": round(thr, 3),
        "samples": len(samples), "verdict": verdict,
        "gaps_hard": [{"render": [round(g0, 3), round(g1, 3)],
                       "source": ([round(to_source(g0, table), 3), round(to_source(g1, table), 3)]
                                  if table and to_source(g0, table) is not None else None),
                       "dur": round(g1 - g0, 3)} for g0, g1 in hard],
        "gaps_soft": [{"render": [round(g0, 3), round(g1, 3)], "dur": round(g1 - g0, 3)}
                      for g0, g1 in soft],
        "low_ratio": [{"render": [round(x, 3), round(y, 3)]} for x, y in low],
        "junctions": junctions, "sheet": sheet_name, "report": a.report,
    }
    if a.json_out:
        with open(os.path.join(a.out_dir, a.json_out), "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    print("结论：%s" % verdict)
    print("基线 %.2f%% / 阈值 %.2f%% / 采样 %d 帧" % (base, thr, len(samples)))
    for g0, g1 in hard:
        s0 = to_source(g0, table) if table else None
        print("  [持续离画] 成片 %.2f-%.2fs (%.2fs)%s"
              % (g0, g1, g1 - g0,
                 ("  源 %.2f-%.2f" % (s0, to_source(g1, table))) if s0 is not None else ""))
    for x, y in low:
        print("  [断续离画] 成片 %.2f-%.2fs (%.2fs)" % (x, y, y - x))
    for j in jbad:
        print("  [剪接异常] %.2fs  %s" % (j["t"], "；".join(j["flags"])))
    if not hard and not low and not soft and not jbad:
        print("  无异常")
    print("报告：%s" % rp)
    return {"PASS": 0, "WARN": 1, "FAIL": 2}[verdict]


if __name__ == "__main__":
    sys.exit(main())
