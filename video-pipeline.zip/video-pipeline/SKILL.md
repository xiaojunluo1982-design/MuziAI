---
name: 'video-pipeline'
display_name: '牧子AI-口播数字人视频生成剪辑'
display_name_en: 'MuziAI - AI Avatar Video Producer & Editor'
description: '通用口播短视频生产与发布技能（账号无关）——从内容包到即梦视频生成、面部马赛克一致性、字幕烧录、封面制作、剪辑拼接、质检、多平台发布，通过 profile 适配不同 IP 账号。当用户要求"做视频""生成视频""剪辑发布""发到抖音/视频号/小红书"时使用。Covers Dreamina/Seedance video generation, mosaic consistency, subtitles, cover, yxer publishing.'
description_zh: '账号无关的口播短视频生产链路：从内容包出发，做即梦/Seedance 视频生成、面部马赛克一致性、字幕烧录、封面制作、剪辑拼接、质检，再到抖音/视频号/小红书的发布。具体 IP 的路径、即梦会话、人物外观、发布账号都放在 profiles/ 下，换账号只需换 profile，核心规则不用重写。'
description_en: 'An account-agnostic short-video production pipeline. Starting from a content package, it handles Dreamina/Seedance video generation, face-mosaic consistency, subtitle burning, cover design, editing/concatenation, QA, and multi-platform publishing to Douyin/WeChat Channels/Xiaohongshu. Account-specific paths, Dreamina sessions, character appearance and publishing accounts live under profiles/ — switching accounts means switching profiles, not rewriting core rules.'
version: '2.3.0'
---

# 通用短视频生产与发布

**账号无关**的生产链路。具体 IP 的路径、即梦会话、人物外观、发布账号都在 `profiles/` 下。

> **要新增一个角色？** 看 `references/new-account-guide.md`（三层架构 + 6 步清单 + 换电脑硬约束）。
> 判断标准：只有某个账号适用的规则 → 放进 profile；所有口播短视频都适用 → 才写进本文件或脚本。

## 0. 第一步：确定 profile

```
profiles/
  muziqi.md        牧子琪（AI 数字人 · AI 销冠）  会话 10593619372812
  xiaojunzong.md   晓君总（真人老板号 · 企业 AI 落地专家）  会话 10559080744972
  _template.md     新账号配置模板
```

判定顺序：用户明说 → 用对应 profile；没说但工作区能判断 → 对应 profile；
判断不了 → **问用户**，不要猜。

> **两个号是两台戏，别串**：牧子琪＝AI 数字人，可免审核直发「AI牧子琪」三平台；
> 晓君总＝真人本人 IP，**默认通过 + 事后可叫停**（2026-09-22 晓君总授权，见 §「发布与审核」），且只发他自己的号
> （视频号 **按内容线分流**：即梦数字人线 →「晓君总和他的AI助理」/ 微云真人素材线 →「晓君总-销售智能体」；
> 抖音「晓君总 私域智能体」/ 小红书「晓君总和他的AI助理」）。
> 🔴 **2026-10-09 晓君总指令 · 视频号按内容线分流**：① **即梦生成的数字人**（每日 05:00 自动化）默认只发
> 「晓君总和他的AI助理」`6a9bae4e…`；② **微云下载的真人视频** 默认只发「晓君总-销售智能体」`6a9a6188…`
> （15970 粉，2026-10-08 重启）。两条线**各发各号、不混发**；需要变更由晓君总另行通知。
> 2026-10-08「单出口 = 销售智能体」口径作废。
> **账号口径一律以 `profiles/xiaojunzong.json` 为准**（见 `publishAccounts._lineRouting`），本行只是摘要，换号后别只改这里。
> 即梦会话也各用一个（见上），**不得混用**。

profile 配套同名 `.json`（路径/账号/生成参数，给脚本与发布环节读）。

**本 Skill 从「内容包已有」开始接手。** 还没文案就先用 `video-copywriter`（通用文案生成）
并指定对应 profile，拿到内容包后再回到这里。内容包自检：

```bash
node <video-copywriter>/scripts/validate_package.js "<内容包.json>" --profile <账号>
```

## 默认样式（2026-08-31 定）

**封面 `--style s1` + 字幕 `--style t1`**（爆款大字报 + 经典亮黄；封面字体 = **思源粗宋 `song-bold` + 斜体 `--italic`**，字幕字体 = 优设标题黑 ——
**封面与字幕字体不必同款**，各自以 profile 的 `defaults.coverFont / subtitleFont` 为准，见 §2B.9）。
两脚本的默认值即为此组合，**不传参数就是它**。不确定用什么风格时，不要选，用默认。
12 款封面 + 10 款字幕的完整参数、配色与配套关系见 `references/style-guide.md`。

## 1. 铁律（违反即返工）

| # | 规则 | 原因 |
|---|---|---|
| 1 | **不改写用户已给的口播文案** | 只能切分，不能删减/补充/调序/润色 |
| 2 | **音轨必须保留**：拼接用 `concat=n=N:v=1:a=1`，**禁止 `a=0`** | 曾丢音被投诉"没声音" |
| 3 | **prompt 禁止写地域气质**（如"四川妹子可爱气质"） | 导致普通话/方言口音混用 |
| 4 | **prompt 禁止饮用/进食动作**（喝水、喝咖啡、咀嚼、端杯） | 干扰口型与音频；杯具可作道具 |
| 5 | **prompt 禁止模型自带字幕/水印** | 与后期烧录字幕重影 |
| 6 | **part1 参考帧必须先打面部马赛克**才能给 part2+ 用 | 防面部逐段漂移；面部一律以身份图为准 |
| 7 | **场景默认用 profile 指定的真实照片目录**，禁止 AI 想象场景；**例外**：项目方（晓君总）明确授权时可用 AI 生成场景，但必须**高度写实 + 人眼验收后才落库**（2026-09-30 授权：《800 官网 · 牧子琪口播片》——「拍摄场景可以 AI 生成，但必须高度真实」） | 真实感要求；默认与例外必须分界清楚，防止拿"AI 场景"当万能借口 |
| 8 | **当天只做当天 1 条**，不批量做；**成片无需人工审核**，生产完成 + 自动质检全 PASS 即直发（2026-09-02 晓君总裁定） | 工作流约定 |
| 9 | 发布前 **preflight_check.js 质检 → validate → dry-run → publish**，四步不能跳 | 质检替代人工审核 |
| 10 | **只发 profile 指定的账号**（`publishAccounts` 主号 + `extraPublishAccounts` 附加号）；找不到该账号则停止并询问，不得发别的号 | 防串号（牧子琪 ≠ 晓君总） |
| 10b | **附加号必须与主号同步发布，一条都不能漏**（2026-09-06 晓君总铁律）；发完主号只算做了一半 | 矩阵号漏发等于当天任务没做完 |
| 10c | **账号暂停 = profile 加 `_suspendFrom: "YYYY-MM-DD"`**，该日起 preflight 的 **C0** 条会对该账号的所有 payload 报 FAIL 阻断（2026-09-29 新增）；恢复发布就删掉该字段。**暂停期间不得换别的号顶替** | 老板指令必须硬拦，不能只写成注释（注释没人读） |
| 11 | **preflight 任一 FAIL 立即停止**，不得绕过、"先发再说"或降级为警告 | 护栏只在被遵守时才是护栏 |
| 12 | **剪辑按来源分两种口径**（🔴 **2026-10-19 晓君总指令：即梦数字人线不剪气口**）：<br>· **即梦生成段（数字人 / 本线默认）** → 只裁片首片尾空白，**段内停顿与气口一个字不剪**（`trim_silence.py --head-tail-only`）<br>· **晓君总本人实拍** → 仍走气口语义：每句话前留 0.30-0.50s + 整体 1.1x（2026-10-14 口径，见 §2B.4 / §2B.6）<br>两种都要**按内容插入营销素材（铺全屏）**——🔴 **素材按产品线归属取用，本线没有就不插，不跨线顶替**（2026-09-21 校正） | 数字人念白的呼吸本来是自然节奏，剪掉反而像机器；素材是证据，宁可素片也不造假证据 |

## 2. 流程

> **↓ 先分流素材来源（2026-09-17 新增）**
>
> | 素材来源 | 走哪条 |
> |---|---|
> | **即梦生成片**（默认） | 下面 Step 1-9 ｜ 视频号出口 = 「晓君总和他的AI助理」 |
> | **已有真人原声视频**（如微云 `MUZIAI/晓君总视频` 上传的素材） | **跳过 Step 1-5**，直接看 **§2B 真人素材直剪链路** ｜ 视频号出口 = 「晓君总-销售智能体」 |

### Step 1 · 取内容包

读 profile 的 `paths.contentPackageDir` 下 `YYYY-MM-DD_内容包.json`（或周计划当天条目）。核心字段：

```json
{
  "title": "…",
  "script": "…",              // 口播原文，不可改
  "scene": "<场景照片文件名>",
  "outfit_action": "【着装】<季节>：<款式>，<面料>，<剪裁或配色>，<场景气质>；【动作】…；【拍摄】…",  // 着装须有质感/高级感/时尚，只写款式不合格
  "segment_materials": [
    {"segment": 2, "type": "image", "file": "…", "seconds": 1},
    {"segment": 3, "type": "video", "file": "…", "seconds": 3}
  ]
}
```

`outfit_action` 三要素已直接给视频模型，**prompt 里不再另写服装/动作/机位**。
`scene` 文件若不在 profile 的 `paths.sceneDir` 中 → 停止并报告，禁止用 AI 场景替代。

### Step 2 · 分段

```bash
node <skill>/scripts/segment_script.js --script-file script.txt --out segments.json
```

- 🔴 **2026-10-11 起「时长优先制」**（晓君总指令，旧字数三档作废）：总量 **220-330 字**（⇄ 成片 30-45s，语速实测 7.3 字/s）；**每段 ≤101 字**（≤15s 安全区，2026-10-23 由 109 下调）；按语义自然分段，优先按 `。？！` 切，其次按 `，、；：`；段数不定死（一般 2-4 段）
- 脚本输出每段 `duration = clamp(ceil(段字数/7.3*1.08), 4, 15)` —— **比例富余**（r=1.08），生成时按此传 `--duration`，不再一律 15s
- 🔴 **单段 >101 字必须拆段**，不是砍内容：101 字 ×1.08÷7.3 = 14.94 → 15s 刚好不撞顶；102 字 = 15.09 → 16s 被 clamp 回 15s，该段语速会被迫比别的段快 10%+（2026-10-21 seq3 实测 12.4%，晓君总原话「不同 part 语速不太一样」）
- **dialogue 条目按「交织后」字数算**：`dialogue_lines` 里按 `seg` 归段的搭档台词会被追加到该段末尾，校验看的是合并后的字数，不是 `segments` 原文（`validate_plan.js` 已按此校验）

### Step 2.5 · 形态分支：solo / dialogue（2026-09-21 新增）

周计划条目带 `format` 字段：`solo` = 单人口播（默认）；`dialogue` = 双人对话（主 IP 主讲，
搭档在旁插话 / 附和 / 补充）。

**先看门**：顶层 `plan.dialogueGate.status`
- **非 `pass` → 降级 solo**：由主 IP 一人念完 `segments`（`dialogue_lines` 里搭档的台词转为转述），
  场景着装用 `productionDefaults`，并在简报里写明「本条按 solo 执行（原因）」。
  ⚠️ 降级是**默认路径**，不是异常 —— 剧本必须写成「一个人念也成立」。
- `pass` → 按双人执行。

**双人执行相对单人的四处差异**：

| 环节 | solo | dialogue |
|---|---|---|
| 参考输入 | `--video <本人参考>` | `--video <本人参考>` + `--image <dialoguePartner.identityImage>` |
| 场景/着装 | 条目级优先，缺失才回落 `productionDefaults` | **必须用条目级** `scene` / `outfit_action`（双人同框与单人不同） |
| 打码 | 一张脸 | 两位出镜人的脸都要遮；`--rect` 逐个区域传，仍不得遮书架/绿植/落地窗 |
| 台词 | `segments` | `segments` + `dialogue_lines`（搭档台词单列，只做插话附和） |

其余（part2+ 只传 `--image <part1_mosaic_ref.jpg>` 锁一致性、prompt 禁写场景服装文字、音轨直接用）
与单人链路完全一致。

🔴 **但 part2+ 的 `--image` 要挂两张（2026-09-24 实战固化，坑 31）**：只有打码帧不够 —— 打码帧上
**两人的脸都被码住**，模型看不到搭档长什么样，会逐段重编一张脸。正确链条：

| 段 | 传参 |
|---|---|
| part1 | `--video <identityVideo>` + `--image <dialoguePartner.identityImage>` |
| part2+ | `--video <identityVideo>` + `--image <dialoguePartner.identityImage>`（第 1 张）+ `--image <part1_mosaic_ref.jpg>`（第 2 张） |

prompt 里固定一句消歧：**「第 1 张是搭档的人物形象，第 2 张是服装/背景/机位/光线的唯一依据」**
（不含任何画风描述，仍守硬口径 ③）。

🔴 **单段口播安全区 = 101 字**（2026-10-23 由 109 下调；实测约 7.3 字/秒 × 15s，再乘 1.08 比例富余）。
为什么不是 109：`duration = clamp(ceil(字数/7.3*1.08), 4, 15)`，102 字算出来 15.09s → ceil 16 → 被 clamp 回 15s，
**富余被吃光、该段语速被迫快 10%+**；101 字 = 14.94s → 15s 刚好落在上限内。
`dialogue_lines` 的搭档台词往正文里并之前先算**合并后**总字数：**并入后 >101 字就挪到别的段**（她的戏留在别的段），
否则该段会被压着念。单段字数校验：**>101 字 = ERROR**（`validate_plan.js` 对 segments 原文与交织后各查一遍）。

🔴 **prompt 必读 `references/prompt-templates.md` §1.6（双人模板）**，三条硬口径（2026-09-21 晓君总现场校正）：
① **主叙事对镜头讲，但视线要自然** —— 说话对象是镜头那头的观众，不是跟搭档对谈；
   ⚠️ **偶尔看搭档是允许且必要的**（应答插话、点头示意、指涉时看一眼），**不要写成「只能看一秒 / 必须立刻回镜头」**
   （2026-09-21 晓君总二次校正：太死板会拍出僵硬感）。只禁「长时间互看、一问一答」的访谈感 —— 记法：**对观众讲，顺手看她一眼**；
   🔴 **对称约束（2026-10-10 晓君总反馈「她一直盯着我」后追加）：搭档的视线同样锚在镜头** —— 身体可微侧向主讲人，
   但脸与视线默认朝镜头，只在插话 / 被指涉 / 应答时顺手看主讲人一眼再收回；
   **禁止「搭档面朝主人物方向倾听」这类写法**（旧 part1 模板就这句，10-07 / 10-09 两条成片她都全程侧脸盯人）——
   记法：**两人都对观众讲，互看只是顺手**；
② **固定机位**，双人中景平视，不推拉不摇移、不切景别；
③ **不描述搭档形象源的画风、不写「重生成真人脸 / 转成真人」之类的话** —— 只写
「搭档以参考图片中的人物形象出现」，**模型自己知道怎么读参考图**，多写反而干扰。

**实测事实（2026-09-21 探针，别重复踩）**：
- ✅ `seedance2.0mini` 接受 `--video` + `--image` 多参考（image ≤9 / video ≤3 / 合计 ≤12），
  5s 双人镜头一次过，72 积分（`output/_probe_out/`）
- ✅ 片内两人稳定、背景与着装一致、本人细金属框眼镜等身份特征保留
- 🔴 **搭档形象一律直传 profile 指定图**：`--image <profile.extra.dialoguePartner.identityImage>`，
  不做任何预处理 / 换图 / 定妆照中间步骤（2026-09-21 晓君总明确指令）。
  ⚠️ 知悉：插画类形象源会被模型当「气质参考」、重生成真人脸 —— 两人同框与主 IP 一致性稳，
  但搭档脸部**跨集可能漂移**。**仅当晓君总反馈「不像 / 每集脸不一样」时**才启用备选流程
  `references/identity-anchor.md`（探针 → 裁侧脸 → image2image 定妆照 → 他挑一张 → 复跑验证）；
  会话与自动化**不得**自行发起该流程

### Step 3 · 生成 part1

prompt 模板见 `references/prompt-templates.md`——**必须整段复制，含全部禁令**，
其中 `<人物外观描述>` 从 profile 的「人物外观」一节注入。

#### 前置 0：积分预检（2026-09-26 新增 —— **先查再提交，别等 ret=1006**）

```bash
dreamina user_credit     # → {"total_credit": <余额>, "user_id": …, "vip_level": …}
```

按 **单段 132 积分**（`seedance2.0mini` / 720p / 15s，实测）算 `段数 × 132` 作**上限预检**
（🔴 2026-10-11 起生成秒数按段字数算、多数段 <15s，实际消耗低于此上限）：

- 余额 ≥ 需求 → 继续
- **余额 < 需求 → 切备用通道 LibTV**（🔴 2026-09-29 晓君总裁定，**取代原「立即停止并报告」**）：
  · LibTV = 自定义连接器（`~/.workbuddy/mcp.json` 的 `LibTV`，端点 `https://mcp.liblib.tv/mcp`），
    工具前缀 `mcp__LibTV__*`；OAuth 授权；算力走 **liblib.tv 账号**，与即梦**不是同一个池**
  · **工具可见且授权有效 → 用 LibTV 通道生成**（工具名 / 参数 / 上传与建节点流程见 `references/libtv-channel.md`，2026-09-29 已跑通并回填）
  · 🔴🔴 **但 LibTV 上「视频参考」整体不可用**（2026-09-29 实测 **12 次全失败**，含 Kling O3 特批样片实验）：
    4 个模型（Seedance 2.0 Mini / 2.5 / Happy Horse / Kling O3）× 2 个模式（`mixed2video` / `videoEdit2video`）
    × 2 种素材（mov / 转码 H.264 mp4）**全部失败**；`validate_generation_plan` 却会返回 `valid:true`
    （**预检过 ≠ 能提交**）。根因在平台侧：图片提交时会被转成 `asset://` 资产并正常入队，
    **视频走到这一步就 `LibTV video: failed.`** → 详见 `references/libtv-channel.md` §4。
    → **切到 LibTV = 参考形式从「参考视频」降为「单图参考」**（`singleImage2video`），prompt 措辞同步改成「参考图片」；
    素材节点必须用 `nodeType:"video-clip"`（用 `video` 会取不到素材 url）。
    ⚠️ **口播不要用 Kling O3**：图参考虽能出片，但画面近乎静帧、不按 prompt 重绘场景（同文件 §6 观感对比）。
    ⚠️ 这是**口径变化**：即梦的 `identityRef=video` 在 LibTV 上不成立，需晓君总点头后才可发（或改用图参考先出片并交底）
  · **工具不可见（未授权，或本会话开始于授权之前）→ 停止并报告**：
    不提交即梦、不换 apiz、不降级（维持原口径）
  🔴 **仍不得擅自切 apiz**（坑 39 ② 不变：apiz 无端到端 runbook）
  ⚠️ 连接器工具可见性是**会话级**的 —— 授权后必须**新开会话**才拿得到 `mcp__LibTV__*`

🔴 **LibTV 通道有个部署约束（2026-09-30 实测补）**：LibTV 是**用户级 MCP 连接器**，
OAuth 凭据由宿主托管、**不落明文文件**（`~/.workbuddy/` 下只有 `mcp.json` 配置，没有 token，
`secrets/` 里也只有企微/微云/红狐那几个）→ **脚本拿不到凭据、连不上 `https://mcp.liblib.tv/mcp`**。
推论：**「走 LibTV 出片」的路线只能由 agent 会话执行，也就是挂 WorkBuddy 自动化；
挂不了 Windows 计划任务**（那种无人值守脚本是纯本地进程，没有 MCP 客户端）。
要么这条路线走自动化，要么回即梦或换本地可脚本化的通道 —— 别在脚本里硬试连 MCP。

🔴 **本机口径 ≠ 技能内 profile（2026-09-30）**：`profiles/muziqi.json` 的 paths 指向
另一台机器的 `G:\牧子琪\`、libtv/apiz 的 exe 指向 `C:\Users\user\...`，本机两者都不存在；
而这份 profile 会**随技能包在机器间同步**（微云 `MUZIAI/video-pipeline.zip`）→
**直接改它会污染另一台机器**。本机自用的口径请放**项目侧**独立配置文件，示例：
`D:\内容生产线\800官网推广\daily\oral_config.json`（本机素材路径 + 场景策略 + 通道参数 + 发布账号 + 合规），
配套自检脚本 `800官网推广/scripts/check_oral_assets.js`（缺素材直接 FAIL，避免白烧算力）。

🔴 **口播片的声音：台词必须原文写进生成 prompt（2026-09-30 端到端实测）**

- `Seedance 2.0 Mini` + `enableSound=on` 是**自带 TTS**：它念 **prompt 里给出的台词**并同步生成口型。
  **prompt 不写台词 = TTS 无词可念** —— 产物音轨仍**照样有人声**（波形是音节状的人声，不是静音），
  但内容是模型自己编的、跟产品无关。**所以定稿文案必须一字不差地嵌进 prompt 的台词段。**
- prompt 固定三段：① 人物与场景（`参考图片中的这位女性……` + 场景 + 自然光/浅景深/真实摄影质感）；
  ② 身份与负面清单（`严格保持参考图片里同一张脸、同一发型、同一同一着装` + 不要文字/水印、不要第二个人）；
  ③ 台词段（`她说的话（请用自然亲切、有说服力的中文女声一字不差地念出来）：` + 文案原文）。
- **锁脸是怎么生效的**：平台把 `singleImage2video` **自动转成 `mixed2video`**、参考图注册成 `asset://…`，
  并给 prompt **前置 `{{Portrait 1}}` 占位符** —— 那就是「人物位绑定」。⚠️ `taskParams.imageList` 会是**空的**，
  真正生效的是 `imageListV2` + `mixedList`，别据 imageList 空就判断「参考图没绑上」。
  实测证明 **LibTV 单图参考锁得住脸**（第 0/7.5/14.5s 三帧同一个人），详见 `references/libtv-channel.md` §9。
- ⚠️ **这一条线不要指望自动核对 TTS** —— 本机虽然装了 Vosk（见 `muzi-local-asr-edit`，**模型路径必须纯 ASCII**），
  但小模型精度不足、**不能用来验证「一字不差」**；云通道 apiz 需余额 ≥10 元（见 §2B.1）。所以仍按老口径：
  ① 文案原文必须嵌 prompt；② 成片路径必须在汇报里给出来，供**人耳复核**。**别在脚本里硬试 ASR**，浪费的是时间不是积分。

🔴 **身份源必须是「写实照片」—— 插画锁不住脸（2026-09-30 实测）**：品牌形象资产常常是**插画**
（例：`牧子数智/营销素材/牧子琪形象.png` —— 彩铅 + 客厅背景），而图参考会把【画风 + 背景】
一起复刻。更关键的是，同一段 prompt、同一张插画参考、连出 4 张，**出来了 4 个完全不同的人**
（连人种都不稳定）→ **插画 → 写实 ≠ 同一个人，这是模型能力边界、prompt 修不了**。

正解：**先用插画/现成素材定出一张写实脸，之后一律以那张写实图当身份源**。
工具 `800官网推广/scripts/gen_oral_portrait.py`（apiz 图生图 · `fal-ai/nano-banana-pro` · 9:16），
**两种模式别用错**：

| `--subject` | 源图 | 用途 |
|---|---|---|
| **`photo`（默认，产线用）** | 写实照片 | **保脸换场景** —— 攒「场景板库」，锁脸不漂移 |
| `illustration` | 插画 | 只用来"先找一张脸"，⚠️ 锁不住身份；出图后人选定稿并立刻冻成写实图 |

- `--n=4` 出候选（挑脸）→ 人选定稿 → 落盘成**长期身份图**（`oral_config.paths.identityImage`）；
- `--src=<写实定妆图> --scene=bookshelf|meeting|window` → **换场景保脸**；
- 场景一律 **AI 生成但必须高度真实**，生成后**必须人眼验收**（脸有没有变 / 多手多字 / 一眼假）
  才许落库 —— 无人值守任务**不得自动采纳**未验收的图。
- 捷径：**别自己造那张脸** —— 本机已有现成写实定妆照
  （`牧子数智/output/_probe_out/_未采用-定妆照方案/定妆照/*.png`，1728×2304 四张同一张脸）。

📖 细节：`references/libtv-channel.md` §7（本地图 → 公网 URL，`apiz upload` 返回的是
**`public_url`** 不是 `url`）、§8（身份源为什么必须是写实照片 + 实测数据）。

🔴 即梦积分**全产线共用一个池子**——「晓君总」10559080744972 与「牧子琪」10593619372812
是**同一个账号额度**，不是各自独立。当天第二条（临时新增）会让消耗翻倍，**一天两发前先算总账**。

#### 前置：确认即梦登录态（设备码流程，2026-09-16 踩坑固化）

```bash
node <skill>/scripts/dreamina_login.js status    # 有有效登录态才继续
```

没有登录态时，**用封装脚本走两段式**（它会把 device_code 暂存下来，避免中间丢码）：

```bash
node <skill>/scripts/dreamina_login.js code      # ① 取链接 + 暂存 device_code，把链接发给用户
#   —— 等用户回复「授权好了」——
node <skill>/scripts/dreamina_login.js done      # ② 落地 token
```

手工版等价于：`dreamina login --headless` → 给人 → **等他授权完** → `dreamina login checklogin --device_code=<码> --poll=5`。

| 坑 | 事实 |
|---|---|
| 设备码有效期 | **约 10 分钟**（看返回的 `expires_at`），不是几小时 |
| `checklogin --poll=N` | **不是长轮询**——实测约 **40 秒**就返回「等待登录超时，请重试」并退出 |
| 后台常驻 `dreamina login` | stdout 被缓冲，**读不到授权码**，等于白跑 |
| `~/.dreamina_cli/logs/` | **不记录**授权码，别去日志里找 |

> 所以**不要**设计成「先起后台轮询、等用户慢慢点」。
> 正确姿势是：先取码 → 给人 → **等人授权完** → 再 checklogin。

> 🔴 **`--poll` 一律写 0，不要用 `--poll 60`**（2026-09-21 实测，见坑 24）：
> `--poll N` 会在**任务已成功提交**之后因 `get_history_by_ids failed: ret=1015` 退出 1 ——
> 自动化里会被当成「提交失败」→ 重复提交、白烧积分。改成 `--poll 0`：命令立刻返回一段干净 JSON
> （含 `submit_id` / `gen_status` / `credit_count`），再用独立轮询脚本查 `query_result` 直到落盘。

```bash
# ── 方式 A（2026-09-16 起 xiaojunzong 默认）：形象参考走【视频】，场景由模型生成 ──
dreamina multimodal2video \
  --video "<profile.paths.identityVideo>" \
  --prompt "<prompt：人物外观 + 用文字描述的真实场景 + 全部禁令>" \
  --duration <本段秒数> --ratio 9:16 --video_resolution 720p \
  --model_version <profile.videoGeneration.model> \
  --session <profile.videoGeneration.session> --poll 0

# ── 方式 B（旧式，仍可用；profile.generationMode.identityRef=image 时走这条）──
dreamina multimodal2video \
  --image "<profile.paths.identityImage>" \
  --image "<profile.paths.sceneDir>\<scene>" \
  --prompt "$(cat prompts/part1.prompt.txt)" \
  --duration <本段秒数> --ratio 9:16 --video_resolution 720p \
  --model_version <profile.videoGeneration.model> \
  --session <profile.videoGeneration.session> --poll 0

dreamina query_result --submit_id=<id> --download_dir "<输出目录>"   # 存为 part1.mp4
# 落盘文件名是 <submit_id>_video_1.mp4，需自己重命名为 partN.mp4
```

**参考实现**：`output/short_video/2026-09-21_获客越来越贵/{gen.js, poll.js}` ——
`gen.js <partN>` 读 prompt 文件 → `--poll 0` 提交 → 打印 `SUBMIT_ID=`；
`poll.js <submit_id> <partN>` 每 30s 查一次，success 即下载并改名 `partN.mp4`。
（prompt 用 node 读文件再传参，绕开本机 PATH 缺 coreutils 导致 `$(cat …)` 失败的问题。）

**选哪条**看 profile 的 `generationMode.identityRef`（`video` / `image`）。当前状态：

| profile | identityRef | 场景 | 说明 |
|---|---|---|---|
| `xiaojunzong` | **video** | **model_generated** | 传 `晓君总形象.mov`；场景写进 prompt；2026-09-16 晓君总定 |
| `muziqi` | image | 真实场景图 | 沿用旧链路 |

> `--video` 约束（`dreamina multimodal2video --help` 实测）：seedance2.0 系列 **≤3 段、每段 2–15 秒**；
> `seedance2.5` 视频 ≤10 段、每段 2–30 秒。传超范围会被拒：
> `upload video: duration X is out of allowed range [2, 15]`。

#### 🔴 生成出来的音轨必须丢（2026-09-16 实测修正）

旧文档写「即梦是无音轨纯视觉通道」——**已过时**。实测生成结果**带 AAC 音轨**，
但**那不是本人的声音**：把它与参考视频音轨做归一化互相关，只有 **0.050~0.123**
（且不是静音，RMS 0.081~0.095 与真人同量级）→ 模型另行合成了一段语音。

```bash
# 丢弃生成音轨，换成本人真实录音
ffmpeg -y -i part1.mp4 -i "<voiceDir>/<本人原声>.wav" \
  -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest part1_final.mp4
```

- 这**不违反** prompt-templates 第 3.5 节「禁止音频驱动重建」——那条禁的是喂 `--audio` 驱动画面；
  这里是画面照常生成、后期替换音轨，属 Step 8 既有链路。
- **禁止**直接采用生成音轨；**禁止**任何音色克隆（项目红线：只用本人真实原声）。

#### ⚠️ 提交前必做：先查残留任务（2026-09-10 根因固化）

```bash
dreamina list_task          # 看有没有 gen_status=querying 的残留任务
```

- **即梦按模型通道分别限并发**，且 **CLI 没有 cancel/delete 子命令**——任务一旦卡在
  `querying`，会一直占着该通道的并发额度，清不掉，只能等服务端释放。
- 实测（2026-09-10）：一条 fast 任务卡在队列 `queue_length=57 万` **31 小时未出片**，
  此后所有 fast 提交（含跨时段）一律被拒：
  `api error: ret=1310, message=ExceedConcurrencyLimit`。
  切到 mini 通道立刻成功——**因为 mini 是另一条并发额度**。
- 所以 `ExceedConcurrencyLimit` **不是**「凌晨高峰限流」，而是**自己账号有僵尸任务占坑**。
  处理顺序：
  1. 先 `list_task`；有 `querying` 残留且已超 30 分钟 → **别再试那个通道**，直接切备用模型。
  2. `query_result` 看 `queue_info.queue_length`：> 10 万基本不可能出片，同上直接切。
  3. 切模型时**不要干等**——等不出结果，只会多一个僵尸。
- 记录被放弃任务的 `submit_id`，下次开工前复查一次是否已释放。

🔴 **本段秒数怎么算（2026-10-11 晓君总指令 · 不再一律 15s；2026-10-23 修正公式）**：
**`<本段秒数> = clamp(ceil(段字数 ÷ 7.3 × 1.08), 4, 15)`**——段字数含标点；
7.3 字/s 是实测语速基准；**乘 1.08 = 比例富余**（旧写法是固定 `+1s`，对短段富余 11%、对长段富余被上限吃掉 →
目标语速随段长漂移，正是「不同 part 语速不一样」的根因，2026-10-23 废掉）；
下限 4s（太短镜头不自然）、上限 15s（seedance2.0 硬限，所以单段文案必须 ≤101 字）。
旧模式「89 字也按 15s 生成」会留 2.8s 死空白、「104 字按 15s」会被压着念（不是截尾，是变快），
**文案、语速、时长三者必须匹配**。`segment_script.js` 输出的每段 `duration` 字段已按此公式算好，直接取用。
⚠️ 公式只保证「目标语速一致」，管不住模型：每段是独立生成，实测净语速仍会落在 7.4-8.7 →
**必须再走 Step 7.5 的段级净语速归一**（`speed_normalize.js`）拉齐。

### Step 4 · 抽帧 + 面部马赛克

```bash
ffmpeg -y -ss 5 -i part1.mp4 -frames:v 1 -q:v 2 part1_ref_raw.jpg

# ⚠️ --rect 是 x,y,w,h（左上角 + 宽 + 高），【不是 x1,y1,x2,y2】！
python <skill>/scripts/mosaic_face.py part1_ref_raw.jpg mosaic_ref.jpg \
    --rect 225,245,215,290            # 只框住脸；默认码区偏大，容易吃掉背景
```

- 默认码区 `default_rect`：宽 26%~74%、高 4%~38%；`--extra-rect` 为**追加**补码，格式同 `x,y,w,h`
- 🔴 **打码区不能遮住要参考的背景元素**（书架/绿植/窗/桌面）。参数格式写错会把背景一起码掉，
  模型看不到 → 生成结果直接丢元素。**事故（2026-09-16）**：误把 `--rect` 当 `x1,y1,x2,y2`
  写 `190,30,350,580`，实际覆盖 x190-540 / y30-610，把身后书架整个码没 →
  part2/3 书架消失、背景与 part1 不一致，返工两轮。
- 脚本内部用 ASCII 临时目录中转，规避 cv2 中文路径读取失败
- 打完后**必须目视确认两件事**：① 脸部已不可辨 ② **要参考的背景元素仍完整可见**

### Step 5 · 生成 part2+

**传什么由 `generationMode.identityRef` 决定，但「服装/场景一致性」一律靠 part1 打码参考帧锁，不靠文字。**

| 模式 | 命令参数 |
|---|---|
| `identityRef = "image"`（旧式） | `--image <identityImage>` + `--image <sceneDir>\<scene>` + `--image <mosaic_ref.jpg>` |
| `identityRef = "video"`（xiaojunzong 现行） | `--video <identityVideo>`（面部 + 声音） + `--image <mosaic_ref.jpg>`（服装/场景/机位/光线） |

🔴 **part2+ 的 prompt 禁止写任何场景/服装的文字描述**（2026-09-16 晓君总纠正）：
**文字描述会压过参考图的视觉信息** —— 写了「落地窗、绿植」却没写「书架」，模型就把书架删了，
各段背景各写各的。part2+ 一律只说「服装/场景以参考图片为唯一依据，保持一致」，**不逐项描述**。
模板见 `references/prompt-templates.md` 第 1.5 节。

> 事故记录：曾给 part2/part3 各写一套场景描述（漏写「书架」），结果两段背景都与 part1 不一致。
> **用图锁，不用字写。**

🔴 **`segment_materials` 不参与生成**（2026-09-21 晓君总指令，**推翻旧的 B-roll 流程**）：
素材插片（录屏 / 聊天截图 / 客户好评）**只在后期剪辑叠加**，生成阶段**一律不传** ——
不要再把素材做成 B-roll 片段喂给 `--video` / `--image`，也不要为素材单独生成镜头。
生成阶段只传两样：`--video <identityVideo>`（本人面部参考）+ `--image <mosaic_ref.jpg>`（一致性）。
理由：素材是**证据画面**，不是「要生成的场景」；递进去只会被模型重画一遍，既失真又白烧积分。

> ⚠️ 旧流程「素材 → img2video 做成 ≥2s 短片 → 当 `--video` 传」**已作废**（连同它配套的
> 「即梦只接受 [2,15] 秒」时长约束）。素材叠加见 Step 7.5 ③。

### Step 6 · 字幕

```bash
node <skill>/scripts/gen_subtitles.js --segments segments.json --probe "<输出目录>" --out subtitles.ass
```

`--probe` 自动读 part*.mp4 真实时长做时间轴。

> 🔴🔴 **`--probe` 必须指向【已经过去气口裁剪】的段**（2026-09-22 实测修正 · 旧写法是错的）。
> **坑**：本文件把 Step 6（字幕）排在 Step 7.5（`trim_silence`）**之前**，`--probe "<输出目录>"` 读到的是**未裁剪**的段长；
> 裁剪会缩短段（实测 part1 15.10s → 12.70s，**−2.4s**；part4 15.10s → 14.05s）→ 烧完字幕**整体前漂**，
> 越往后错得越多，最后一段字幕压在下一段画面上。
> **正确姿势**：先跑 Step 7.5 的 `trim_silence.py`，再把裁剪结果**复制成 `probe/partN.mp4`**，
> 用 `--probe "<输出目录>/probe"` 生成字幕，最后拼接烧录：
>
> ```bash
> # ① 裁剪（Step 7.5 提前）
> python scripts/trim_silence.py part1.mp4 seg/part1_trim.mp4    # …每段
> # ② 建 probe 目录放裁剪后的段（命名必须仍是 partN.mp4）
> mkdir probe && cp seg/part*_trim.mp4 probe/                    # 再重命名成 part1.mp4…partN.mp4
> # ③ 按裁剪后时长算字幕
> node scripts/gen_subtitles.js --segments segments_sub.json --probe "<输出目录>/probe" --out subtitles.ass --style t1
> # ④ 拼接 + 烧字幕（输入用 seg/partN_trim.mp4）
> ```
>
> 参考实现：`output/short_video/2026-09-22_临时新增_老板不该做内容/_burn.js`（自动建 probe + 重算 + 烧录，一条命令跑完 ②③④）。
脚本内置默认是 `t6`（优设标题黑·黄字黑边，配 s7）—— 但**不要依赖内置默认**：
**一律显式 `--style` 传当次 profile 的 `defaults.subtitleStyle` / `defaults.coverStyle`**，
封面与字幕按配套表成对选。各 profile 的当前值：

| profile | 封面 | 封面字体 | 字幕 | 依据 |
|---|---|---|---|---|
| `muziqi` | `s7` 标题条风 | `douyin` 优设标题黑 | `t6` 优设标题黑·黄字黑边 | 2026-09-03 拍板 |
| `xiaojunzong` | `s1` 爆款大字报 | **`song-bold` 思源粗宋 + `--italic`** | `t1` 经典亮黄 | 2026-09-16 按文案 profile 数值反查样式表（s1 是唯一 708/832；t1 是唯一 52px/6px/MarginV260）+ 同日晓君总定封面字体改用思源粗宋 |

> 🔴 **`defaults.coverStyle` 和 `defaults.coverFont` 必须一起读、一起显式传**（2026-09-29 教训）：
> 只传 `--style` 会退回该风格的推荐字体，**脚本不报错、画面照样有字，肉眼当天不一定看得出**。
> xiaojunzong 现行命令：`make_cover.py --style s1 --font song-bold --italic …`，详见 **§2B.9**。

> ⚠️ **口径冲突待确认**：项目 MEMORY.md 另记「当前发布口径 = 封面 S1 + 字幕 T10（思源黑体 Bold）」，
> 但该条与样式表不符（s1 描述错、t10 是真言体、样式表无「思源黑体」）。**以 profile 的 defaults 为准**，
> 确认后再统一改。「不要照抄旧注释里的 t1/s1」这句是 2026-09-03 针对 muziqi 说的，**不适用于 xiaojunzong**。

12 款封面 + 10 款字幕的完整参数、配色、配套关系见 **`references/style-guide.md`**。

脚本自检「字幕字数 == 原文字数」，不一致会 WARN（折行插入的 `\N` 不计入）。

**语义折行（2026-09-16 新增，解决「字幕溢出屏幕」）**：旧版一屏最多 18 字却按**单行**输出，
720 宽 / 52px 单行只放得下约 12 字 → 必然左右溢出。现在脚本按 `AVAIL_W / SIZE` 算单行安全字数
（720 宽 52px → 12 字），超长屏**按语义折成两行**（ASS 硬换行 `\N`）。切点分层（低者优先）：
`标点后` > `关联词前` > `虚词前` > `其它可行位置`；**禁止切在数字/英文词中间**（「二十四」「AI」不拆）。
改 `PLAY_RES_X` 或字号后上限自动重算。运行日志会打印「折行：单行上限 N 字，M 屏折成两行」。

> 🔴 **断句与折行的完整规范见 `references/subtitle-linebreak.md`**（2026-09-26 新增）：
> 两条路径（A 口播原文→ASS / B 实拍 ASR→ASS）的常量表、分屏优先级、折行切点分层与硬禁、
> 校验判据、常见坑、换电脑必做动作，全都在那一份里。**改脚本参数时必须同步改该文件。**

⚠️ **字体配错不报错、只是字不对**（2026-09-16 实测重写，**推翻了「靠 fonts.conf」的旧方案**）：
- **Windows 上 libass 走 DirectWrite 字体提供者**（启动日志 `Using font provider directwrite (with GDI)`），
  因此 **`FONTCONFIG_FILE` / `fonts.conf` / `<dir>` 全部无效**，加别名也没用 ——
  实测 5 款字体**全部静默回退微软雅黑**（画面照样有字幕，肉眼看不出来）。
- **正确解法（两条都要）**：
  1. 烧字幕命令必须带 **`:fontsdir='<VP_FONTS_DIR 转义形式>'`**（libass 原生参数，跨字体提供者都有效）。
     Windows 盘符冒号转义成 `C\:/path`，整体加单引号。
  2. **ASS `Fontname` 写「字体注册到系统的名字」** —— 不是文件名、也不一定是 name 表的 Family(1)。
     已实测：得意黑 = `Smiley Sans Oblique`（`Smiley Sans` 会回退）、
     普惠体 = `Alibaba PuHuiTi 3.0 105 Heavy`（`Alibaba PuHuiTi` 与 `Alibaba PuHuiTi 3.0` 都会回退）。
- 字体目录由 `VP_FONTS_DIR` 决定；**`setx` 落的变量只对新进程生效**，已运行的终端读不到 ——
  脚本已按候选链自动兜底（见 `setup-checklist.md` 3.3.1），不要因此误判「字体目录不可访问」。
- 5 款字体的完整对照表与免费商用出处见 `references/setup-checklist.md` 第 3 节。
- **配完必须验**：`setup_check.js` 的「字幕字体端到端实测」项（真的烧帧做像素比对）。
  **`--offline` 下也必须出现这一项**；若消失说明被跳过了。

### Step 7 · 封面

底帧**从 part1 抽**（part2+ 开头可能是素材全屏帧，不适合做封面）：

```bash
ffmpeg -y -ss 4 -i part1.mp4 -frames:v 1 -q:v 2 cover_base.jpg

python <skill>/scripts/make_cover.py --base cover_base.jpg \
    --line1 "<第一行>" --line2 "<第二行>" \
    --out-png cover.png --out-jpg cover_512k.jpg
```

完整参数与配色见 **`references/style-guide.md`**。
**默认 `s1`（爆款大字报·优设标题黑）**——不传 `--style` 即用它。

**思源粗宋 + 斜体（2026-09-16 晓君总要求，xiaojunzong 现行）**：加 `--font song-bold --italic`。
思源宋体**没有斜体版**，`--italic` 用**逐行水平切变合成斜体**（默认 shear `0.30`，
可 `--italic-shear` 调整；**< 0.25 肉眼几乎看不出**）。合成斜体会略微增宽字面，已内置扩边不裁切。
> 注意这是合成斜体，非真斜体字体；如需真斜体得另找带 Italic 的免费商用宋体。

**视频号封面必须 < 512KB**（`--out-jpg` 自动降质量）。
两行字号差 > 12px 时会 WARN——每行 5-8 字最均衡。

### Step 7.5 · 剪辑修整（2026-09-16 晓君总指令，默认动作）

> 🔴🔴 **执行顺序修正（2026-09-22；2026-10-23 加语速归一）**：本步的 **① 去气口必须提前到 Step 6 之前做** ——
> 因为 `gen_subtitles.js --probe` 要读**裁剪后**的段长，否则字幕整体漂移（详见 Step 6 的坑）。
> **① 裁剪 → ①c 段级语速归一 → ② 字幕 → ③ 封面 → 拼接烧录。**
> 🔴 ①c 会改变段长，所以**必须排在字幕之前**；归一后的 `seg_norm/partN.mp4` 才是 probe 与拼接的输入。

拼接前对每段做三件事：

```bash
# ① 即梦生成段（partN）：🔴 2026-10-19 晓君总指令「不用剪气口」
python scripts/trim_silence.py part2.mp4 part2_trim.mp4 --head-tail-only --edge 0.10
#   只裁片首/片尾大段空白（取「片头连续静音结束点 / 片尾连续静音起点」，各留 0.10s 余量）
#   🔴 **段内停顿、气口、呼吸一律不动**（0 处改动）—— 数字人念白的自然节奏不再被压平
#   首尾本来就没空白 → 直接 copy，不重编码
#   ⚠️ 连带影响：段长比旧口径长（实测同段 8.10s vs 剪气口后 7.32s）
#      → ① 动效 --segDurs **必须传裁剪后 ffprobe 实测值**；② 字幕 probe 读的也是裁剪后段长（顺序不能乱）

# ①b 晓君总「实拍」素材：气口 + 整体提速（🔴 2026-10-14 当前口径 = 气口 0.30-0.50s + 1.1x）
python scripts/trim_silence.py joined.mp4 body_1.1x.mp4 --speed 1.1 \
    --min-dur 0.30 --gap-min 0.30 --gap-max 0.50 --edge 0.30 --dump-keeps keeps.json
#   ⚠️ 气口还要在**拼接**那一步先垫回来（见 §2B.6「拼接留气口」），否则这里没有静音可留

# ①c 段级净语速归一（🔴 2026-10-23 新增，即梦生成段必做）
node scripts/speed_normalize.js --segdir seg --segments 内容包.json --apply
#   默认输出 <segdir>/../seg_norm/partN.mp4 + _speed.json
#   先跑一遍不加 --apply 看报告：目标取各段净语速【中位数】，只动跑偏的段，其余 |r-1|<2% 直接 copy
#   实测 10-21 seq3：p1 7.59 / p2 7.43 / p4 7.44 全部 copy，只有 p3 8.35 走 atempo 0.900（15.10s→16.78s）
#   🔴 setpts + atempo 同时作用、比例一致 → 音画同步且保音调（只 atempo 会音画不同步）
#   🔴 归一后 `seg_norm/` 才是下游唯一输入：probe 复制、字幕、拼接、动效 --segDurs 全用新时长
```

🔴 **倍速按素材来源分两档，别混**（2026-10-14 更新：实拍 = 1.1x）：

| 素材来源 | 倍速 | 说明 |
|---|---|---|
| **晓君总本人实拍**（手机原片 / 微云下载 / `营销素材/晓君总视频/`） | **1.1**（默认 · 2026-10-14 起） | 去停顿/空白/重复**之后**再整体提速，且**句间留 0.30-0.50s 气口**；`setpts=PTS/1.1` + `atempo=1.1`（**保音调，人声不变尖**） |
| **即梦生成段**（Step 5 产出的 partN） | **1.0（不变速）** | 生成段落是为定稿文案卡过时长的，**整体**再提速会顶穿字幕节奏；⚠️ 唯一例外是 ①c 的**段级拉齐**——那是对跑偏的段做微调（通常 ≤10%），目的是让各段一样快，不是整体提速 |

> 参数细节、帧率处理、字幕/素材时间点换算见 **§2B.6**。

🔴 **为什么必须有 ①c（2026-10-23 晓君总反馈「不同 part 语速不太一样」）**：
即梦**每段是独立生成**，`--duration` 只是建议不是约束 —— 模型倾向于「把台词塞进给定时长、说完就留空尾」。
实测 10-15 ~ 10-21 五条片子，四段净语速极差 0.43~1.18 字/s，最长那段永远最快（10-15 p1 8.35、10-21 p3 8.35）。
公式只能保证「目标语速一致」，管不住模型的随机性 → **必须用 ①c 在后期按段拉齐**，否则永远会有「这段赶」。
判定口径统一用**净语速 = 段字数 ÷ 有声时长**（有声时长 = 总时长 − 静音合计，silencedetect −35dB/0.2s）——
用总时长算会把「停顿多」误判成「说得慢」。

② **查重复语句**：无法可靠自动检测（需转写）。AI 生成段台词来自定稿文案（口播文案「一个字不许改」），
一般无重复；**真人原声素材在送审环节人工确认**，有口误重复先剪掉再进 ①。

③ **按内容插营销素材（铺全屏）**：周计划条目 `segment_materials` 有声明时，按声明秒数在对应台词点插入
（画面全屏替换、音频连续）。产品类内容**素材就位就多插**（增强可信度），每条 1-2 个为宜；
每条视频 ≤4s、图片 ≤1s（🔴 2026-10-04 起视频上限由 3s 放宽到 4s：条目素材多带 `speed:1.5`，4s 按 1.5 倍速播 ≈2.67s 时间线，与旧「时间线 ≤3s」等价；`validate_plan.js` 硬闸同口径），缩放裁剪到 720×1280。
🔴 **只取条目自己声明的素材**（2026-09-21 晓君总指令）：**禁止**在声明为空时跑去 `materialDir` 里
「自己挑一个用」——那正是串线的高发点（旧流程这么写过，已废）。
🔴 **严格按产品线归属，跨线不得顶替**：归属以 `营销素材/_素材归属清单.md` 为准。
现状（2026-09-28 更新）：**获客内容自动生产线素材已补齐** —— 微云 `MUZIAI/自动内容生产线/内容生产线素材/` 15 条录屏已下载到 `营销素材/内容生产线素材/` 并登记归属，内容线条目会**声明插片**（不再默认素片）；早期「内容线暂无素材」的口径作废
即**本条不插片**，正常素片出片。**不许用私域智能体的客户好评 / 聊天截图顶替** ——
拿别条线的证据冒充本条线的效果是**造假证据**，比不插素材严重得多。素材到位后回填 + 登记台账。
🔴 **素材只在后期这一步进场，绝不参与生成**（2026-09-21 晓君总指令）：直接用 ffmpeg `overlay` 叠到成片对应时间点，
**不送模型、不做 img2video、不为素材生成镜头**。Step 5 生成阶段只传本人参考与一致性参考帧。

**overlay 落法（2026-09-23 首次实操，已验证）** —— 与 concat、烧 ASS **一次成片**（别分两趟重编码）：

```
# 输入顺序：0..3 = partN_trim.mp4，4 = 素材视频，5 = 素材图片(-loop 1 -t <秒> -i xx.jpg)
FC='[0:v][0:a][1:v][1:a][2:v][2:a][3:v][3:a]concat=n=4:v=1:a=1[vc][a];[4:v]trim=0:3,setpts=PTS-STARTPTS+<T1>/TB,scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1[m1];[5:v]scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1,setpts=PTS-STARTPTS+<T2>/TB[m2];[vc][m1]overlay=enable='"'"'between(t,<T1>,<T1+D1>)'"'"':eof_action=pass:repeatlast=0[v1];[v1][m2]overlay=enable='"'"'between(t,<T2>,<T2+D2>)'"'"':eof_action=pass:repeatlast=0[v2];[v2]ass=subtitles.ass:fontsdir='"'"'C\:/Users/admin/.workbuddy/fonts'"'"'[vs]'
ffmpeg -y -i part1_trim.mp4 … -i "<素材视频>" -loop 1 -t 1 -i "<素材图片>" -filter_complex "$FC" \
  -map "[vs]" -map "[a]" -c:v libx264 -crf 18 -preset medium -r 60 -c:a aac -b:a 192k -movflags +faststart "<title>_完整版字幕_<MMDD>.mp4"
```

- **时间点怎么定（🔴 2026-09-28 改为自动匹配，别再手写关键词 —— 见坑 41）**：先把 `subtitles.ass` 生成出来，然后**从条目 `note` 的「…」引号短语出发，在该段自己的字幕行里做最长公共子串（LCS）模糊匹配** → `score ≥ 4` 取该行起点，`< 4` 回落该段首行（段区间由 probe 段时长累加切分）；行文本先去掉标点再比。**别按字数比例估算**，字幕文件就是权威时间轴。
  - 单行匹配示例（2026-09-28 实跑）：note「客户都挂在销售个人微信上」→ 命中字幕「客户全都挂\N在销售个人的微…」score=5 → T=16.67；note「按节奏提醒」→ 命中「该回访的按节奏提醒。」score=5 → T=37.83。
  - ⛔ **禁止**把某一天的台词原文写成 `m.segment===2 ? '卡在哪一步' : …` 这种硬编码 —— 换条目会**静默不插**（只打一行 SKIP 日志）。
- `setpts=PTS-STARTPTS+<T>/TB` 是把素材平移到 T 起播的**关键**；少了它 overlay 会去取素材在 T 时刻的帧（早放完了 → 黑/卡）。
- `eof_action=pass:repeatlast=0` 必须带，否则素材放完会**停在最后一帧糊住后面所有画面**。
- 素材音频**不接**（只 `[N:v]`），成片音轨始终是口播原声 → 天然「音频连续」。
- 图片素材多为横图（如 1552×1010），`force_original_aspect_ratio=decrease` + `pad` 会**留黑边**，这是预期效果（证据截图），不要强行拉伸。
- 落完**必须抽帧复核 4 个点**：素材入点、素材中段、素材出点、下一段起点（确认已切回人物）。ffmpeg 会打
  `More than 1000 frames duplicated` 警告 —— 这是 `-loop 1 -t 1` 图片输入的正常现象，**不影响成片**，别当报错。
- 插入区间写进成片目录 `manifest.json` 的 `overlayManifest`（`seg` / `mode` / `start` / `dur` / `filter`）。

🔴 素材语义必须与该段台词对得上（`note` 里写了对应关系），**对不上就跳过、不许硬塞**；
素材文件不存在或缺失 → 跳过并在简报里列出缺哪个，**不得拿别的素材顶替**（含不得跨线顶替）。
插入用 ffmpeg 在 Step 8 拼接时一并完成（先对插了素材的段落重排时间线，再 concat），插入位置记进成片目录 manifest。

### Step 8 · 拼接烧录（音轨 + 字体！）

```bash
# FONTCONFIG_FILE 给 fontconfig 型 libass 用；:fontsdir= 给 DirectWrite 型 libass 用。
# 两个都带上最稳（2026-09-16 实测：Windows 上多数构建是 DirectWrite，fontsdir 才有效）。
FONTCONFIG_FILE="<fontconfig配置>" ffmpeg -y \
  -i part1.mp4 -i part2.mp4 -i part3.mp4 \
  -filter_complex "[0:v][0:a][1:v][1:a][2:v][2:a]concat=n=3:v=1:a=1[v];[v]ass=subtitles.ass:fontsdir='<VP_FONTS_DIR 的转义形式>'[vs]" \
  -map "[vs]" -map "[a]" \
  -c:v libx264 -crf 18 -preset medium -r 60 -c:a aac -b:a 192k -movflags +faststart \
  "<title>_完整版字幕_<MMDD>.mp4"
```

- `concat` **必须 `v=1:a=1`**，且**两个输出标签都要写**：`concat=n=3:v=1:a=1[v][a]`。
  只写 `[v]` → `Output with label 'a' does not exist in any defined filter graph`，**直接不出文件**（坑 18）；
  写成 `a=0` 会静默丢音。
- **🔴 字体必须用 `fontsdir` 兜底（2026-09-16 实测结论）**：Windows 上 libass 走
  **DirectWrite 字体提供者**，`FONTCONFIG_FILE` / `fonts.conf` 对它**完全无效**。
  实测 5 款字体全部静默回退微软雅黑 —— 画面照样有字幕，肉眼看不出，只有做像素比对才发现。
  `:fontsdir='<目录>'` 里的 Windows 盘符冒号要转义成 `C\:/path`，并整体加单引号。
- 双保险：本机已把 5 款字体**装进 Windows 用户字体库**（HKCU，无需管理员），
  这样即使忘了传 `fontsdir` 也能命中。
- 若模型仍自带字幕：用 `boxblur + overlay` 压底部白字区，再烧 ASS。
- **改完字体相关配置后，务必跑 `setup_check.js`**——它的「字幕字体端到端实测」项会真的
  烧一帧做像素比对，能抓出这类静默回退。

### Step 8.5 · Remotion 漂浮动效叠加（2026-10-18 晓君总指令）

> 原话：「使用 remotion 动画，适当在视频上漂浮一些动画效果，强调和体现重点内容，增强画面吸引力。」
> **在 Step 8 烧完字幕之后、Step 9 质检之前做**：字幕在下三分之一、动效在中上部安全区，互不遮挡。

```bash
NODE=<managed node>
RM=D:/牧子数智/remotion-motion

# ① 按周计划某条的 motion 编排算出帧位并渲染透明层（vp9 / yuva420p）
"$NODE" "$RM/scripts/render_float_fx.js" \
  --plan "D:/牧子数智/内容计划/短视频周计划-<周一>.json" --seq <n> \
  --out "<工作目录>/motion/fx.webm" \
  --faceRect "<part1 打码用的 x,y,w,h>" 
  # 拿到各段 trim 后音轨实测时长时，务必传 --segDurs "5.1,9.2,13.8,12.4"（最准）
  # 🔴 --faceRect 复用 mosaic_face.py 的那组坐标 → 动效禁带按本片真实脸位算，不靠猜

# ② 叠到成片（音轨 copy，不动一个字）
"$NODE" "$RM/scripts/apply_motion.js" \
  --video "<title>_完整版字幕_<MMDD>.mp4" \
  --fx "<工作目录>/motion/fx.webm" \
  --out "<title>_完整版字幕_<MMDD>.mp4"
```

**硬规则**

| # | 规则 | 为什么 |
|---|---|---|
| 1 | 动效**只做强调**，3-5 个/条；🔴🔴 **2026-10-19 晓君总指令「动画元素不要挡着眼睛」** —— 居中动效只允许落**上部安全区 y 195–290** 或**下部安全区 y 760–880**；**面部禁带（默认 y 330–700）内一个都不许放**。渲染时传 `--faceRect "<x,y,w,h>"`（直接复用 part1 打码的那组坐标，脚本自动 ±30px 换算禁带），组件层还有 `clampAwayFromFace` 兜底：写 `pos:"mid"` 或 custom 坐标也没用，落进禁带照样被推出去 | 盖住眼睛，观众第一眼就出戏，再好的内容也白搭 |
| 1b | **动效落库后必须抽帧核对**：在动效出现的时间点抽 3 帧，看清眼睛/眉毛有没有被压住 | 组件兜底是按估算半高做的，实际字号超预期时仍可能擦边 |
| 2 | 渲染参数必须是 `--codec=vp9 --image-format=png --pixel-format=yuva420p` | 少 `--image-format=png` 直接报错；只写 `yuva420p` 但产物显示 `yuv420p` 属正常（alpha 在 vp9 side data 里），**以叠加后是否黑底为准** |
| 3 | 叠加时 `-c:v libvpx-vp9` 解码动效层 | 不指定就按 yuv420p 解，整片盖一层黑 |
| 4 | overlay 用 `eof_action=pass` | 动效播完透出原片，而不是冻结最后一帧 |
| 5 | 段边界 = **生成时请求的秒数**（durationFormula），不是「字数 ÷ 语速」 | 按字数算会整体提前 5–6 秒，末尾 CTA 动效落空 |
| 6 | 浏览器用 `C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe` | 本机 Chrome 路径不存在；`MOTION_BROWSER` 可覆盖 |
| 7 | 渲染时 stderr 会报 `WMIC.exe blocked`，**属无害**，产物正常 | 别去「修」它，也别据此判失败（看产物文件大小） |

**动效类型**（`src/components/FloatLayer.tsx`）：`keyword` 紫底白字关键词 / `accent` 黄底黑字最强强调 /
`stat` 数字 / `check` 对勾清单 / `label` 细边框次要标注 / `cta` 收口条。

### Step 9 · 质检（交付前必做）

**9.1 剪接自检（机械化，真人素材直剪链路必跑）**

```bash
"<python>" <skill>/scripts/verify_cuts.py \
  --video "<成片>.mp4" --segments "<保留段源时间 a-b,c-d,...>" \
  --out-dir "<输出目录>" --fps-scan 4 --scale-w 240
# 退出码 0=PASS 1=WARN 2=FAIL；FAIL 一律回去改剪点，不许带病发布
```

产 `cut_report.md` / `cut_report.json` / `contact_sheet.jpg`（红框=可疑帧 + 成片时间与源时间）。
它自动查三类语音层面看不见的问题：**段内持续离画**、**段内断续离画（缓慢转头）**、**剪接点构图跳变**。
判据：人脸面积 ≥ max(2%, 0.25×基线)；在画率窗口 4s / 下限 60%。来历见坑 31/32/**35/36**。

**9.2 编码与音量**

```bash
ffprobe -v error -show_entries format=duration,size \
        -show_entries stream=codec_type,codec_name,width,height,r_frame_rate \
        -of default=noprint_wrappers=1 "<成片>.mp4"
ffmpeg -i "<成片>.mp4" -af volumedetect -f null - 2>&1 | grep -E "mean_volume|max_volume"
```

| 检查 | 期望 |
|---|---|
| 流 | 同时有 video(h264) 与 **audio(aac)** |
| 分辨率 / 帧率 | 720×1280 / 60fps |
| 音量 | mean **-20 ~ -10 dB**；-91 dB = 静音，必须重做 |
| 时长 | ≈ 总字数 ÷ 7.3（时长优先制，目标 30-45s）；不再是「段数 × 15s」 |

⚠️ **画面观感中能机检的部分已在 9.1 覆盖**（人脸在不在画、剪接点跳变）；
剩下的人工项（口型对不对、有无饮用/杂动作、有没有双字幕、素材是否全屏）
仍需读图或交用户确认 —— **不要仅凭「脚本 PASS」就下结论说"画面已确认无误"**。
（旧版此处写"当前模型不支持读图"已过时：现在能读图，但读图要挑关键帧，仍不能替代全片过目。）

### Step 10 · 发布

见 `references/publishing.md`（通用流程）；账号与平台差异参数见 profile。

**⚠️ 审批口径按账号分叉（2026-09-16 修正文档缺口）**——本文件此前把「免审核直发」写成通用规则，
**用在晓君总号上会直接违反红线**。以 profile 的 `approval.workflow` 为准：

| 账号 | `approval.workflow` | 推送的性质 | 发不发的判据 |
|---|---|---|---|
| 牧子琪 `muziqi` | `auto_after_preflight` | **知会**，不是审批 | `preflight_check.js` 全 PASS 即发（2026-09-02 晓君总裁定「以后不用我审核」，是针对牧子琪说的；profile 的 `approval._scope` 已限定范围） |
| 晓君总 `xiaojunzong` | `auto_publish_with_post_hold` | **事后简报**，不是审批 | **默认通过**：`preflight_check.js` 全 PASS 即发（视频号 + 抖音 + 小红书，三平台串行），发布后立刻推企微简报。**不再等回复** —— 2026-09-22 晓君总本人授权「以后不用问了，一旦发现有新内容，直接按内容要求生成文案、制作视频并发布」。叫停靠两个入口：生产前 `hold: true`；发布后口述「撤」（平台删除/隐藏 + 台账 `withdrawn`） |

- 晓君总号发布简报里**不要**写「回复通过才发」——那是旧口径，会让人误以为还没发。简报写「已发布 + 回执」。
- 牧子琪号不要等回复（会白等）。
- 🔴 **旧口径作废**：`manual_confirm_before_publish` 是 2026-09-16 ~ 09-21 的规则，已于 2026-09-22 撤销。任何地方（含 muziqi.json 的 `_scope`）若仍写「晓君总号必须本人确认才发」，**以本表为准并顺手改掉**。
- **两种模式共同的前置闸门**：发布前必须跑全量（带 `--payload`），全 PASS 才能继续：

```bash
node scripts/preflight_check.js --profile muziqi \
  --video "<成片.mp4>" --cover "<封面.jpg>" \
  --ledger "D:/牧子数智/output/published_log.json" \
  --payload "<payload_抖音.json>" --payload "<payload_小红书.json>"
```

🔴 **`--ledger` 不能省**（坑 25）：台账默认路径跟 cwd 走，从 `output/short_video/<日期_场景>/` 里跑
会指向不存在的 ledger → G 项判重永远报「未发布过」。G 项报 OK 时先确认路径。
登记台账的 `--record` 也要带同一个 `--ledger`。

它拦的是四类公开事故：① **串号**（payload 的 id/账号名必须同时等于 profile 与线上实录）；
② **成片硬伤**（非 720×1280、无音轨、时长越界、封面 ≥512KB）；③ **文案违规**（价格/百分比/效果数字/绝对化用语）与平台字数超限；
④ **同天同平台同一账号重复发布**（2026-09-02 补，见下）。
**任一 FAIL → 停止，修完重跑，禁止绕过。**

**④ 重复发布拦截（G 项）**：脚本默认自动扫两处来源，互为交叉验证：
- `output/周计划/*_周计划.json` 里当天条目的 `published` 块（agent 回写）
- `output/published_log.json` 发布台账（`--record` 追加，机器写）
- `status` 为 `skipped` / `failed` 不算已发，**允许补发**（如视频号离线后恢复授权）。
- 素材阶段（无 `--payload`）重复只报 WARN；**全量阶段（有 `--payload`）逐平台判 FAIL**。
- 确需删了重发才用 `--allow-republish`（降级为 WARN），**必须在汇报里写明理由**。
- **判重粒度是「平台 + platformAccountId」，不是平台**（2026-09-06 改）：
  矩阵号与主号同平台不同号，主号发完**不会**误拦附加号，附加号可以照常补发；
  但同一账号仍严格拦死。**写台账时务必带上 `platformAccountId`**，否则退化成平台级通配，会误锁同平台其他号。
- 周计划 `published` 块里 `_` 开头的 key（如 `_附加号`）是说明字段，脚本跳过，勿当成发布记录。

**一平台多号 / 矩阵号同步发布（2026-09-06 新增，牧子琪铁律）**：
profile 里的 `extraPublishAccounts` 是**必须同步发布**的附加号白名单（如牧子琪的「私域智能体牧子琪」三平台号）。
- **发完主号 = 任务只做了一半**：必须同内容、同封面、同视频再发一遍所有附加号。漏发要在汇报里点名。
- 附加号 payload 的构造：复制主号 payload，**只替换 `platformAccountId`**，其余字段不动。
- preflight C1/C3 对主号与附加号白名单**都放行**（标记「主号/附加号」），都不在白名单才算串号。
- 附加号离线 → 跳过该号并汇报，主号与其他号照发，**绝不换号顶替**。
- 附加号失败（如新号风控）→ 失败即停不重试；台账/周计划记 `failed`，**failed 不会被 G 项锁死**，验证通过后可补发。

**发布三步走（机械顺序，勿跳）**：`validate` → `publish --dry-run` → `publish`，三步都必须 `ok:true`。
dry-run 会回显 `meta.accountIds`，**先核对账号 ID 与 profile 一致再真发**（这一步能拦住串号）。

```bash
YX="<node_modules>/@yixiaoermail/cli/bin-native/yxer.exe"
"$YX" validate "视频号" video payload.json --json           # 🔴 validate = <平台> <type>
"$YX" publish  video "视频号" payload.json --dry-run --json # 🔴 publish  = <type> <平台>
"$YX" publish  video "视频号" payload.json --json          # 只返回 taskSetId = 已提交
```
🔴 **validate 与 publish 的参数顺序相反**（v3.2.14 起）。本文件此前写成 `validate video "视频号"`，
2026-09-24 实跑踩到 —— 报 `validate <platform> <type> <payload.json>` + `retryable: true`，
看着像"格式对不上"，实际就是**顺序反了**。权威写法见 `references/publishing.md`（第 44/125/150 行）。
**多平台一律串行发**，不要并行（微信系登录态互斥，并发会报「登录失效」）。

**发布后先复核、再登记台账**（缺一不可）：`publish` 的 `ok:true` 只是「任务已提交」，
**不代表已发出**（坑 22）。必须复核：
```bash
"$YX" query details <taskSetId> --json   # 逐 task 确认 stageStatus=success 且 errorMessage 为空
```
复核通过后**必须登记台账**，否则下一跑的拦截只剩周计划单一来源：
```bash
node scripts/preflight_check.js --ledger "D:/牧子数智/output/published_log.json" \
  --record '{"date":"<YYYY-MM-DD>","note":"<说明>",
  "platforms":[{"platform":"抖音","platformAccountId":"<id>","taskSetId":"<id>","status":"submitted"}]}'
```

**账号在线判定（2026-08-31 新增，勿省）**：`yxer accounts list <平台> --status 1 --json`，
返回里**必须能看到 profile 记录的 `platformAccountName`** 才算可发。
- `status=1` 在线可发；`status=2` = **授权过期/离线**，发必然失败，需先在蚁小二重新扫码授权。
- profile 里的账号 id 会长期存在但授权定期过期，**只看 id 对不对不够，必须看 status**。
- 若目标账号离线：**跳过该平台、其余平台照发**，并在汇报里注明「未发布—账号离线（status=2），需重授权」。
  绝不允许改用同平台其他账号顶替（发错号是重大事故）。

🔴 **`status=1` ≠ 云通道真能发（2026-09-24 实测，勿省）**：视频号「牧子AI」在 accounts list 里
`status=1`、`isLock=false`，看着完全正常，但 `publish` 后 `query details` 报
`获取用户信息失败登录失效`（`stageStatus=fail`）。**账号列表的 status 只反映蚁小二侧记录，
看不到微信/平台侧的真实登录态。**
→ 所以**唯一可信的成功判据是 `query details` 里 `stageStatus=success` 且 `errorMessage` 为空**，
`status=1` 和 `publish` 的 `ok:true` 都只是"能试"，不是"发成了"。
→ 视频号这类失败 **payload 可原样复用**：让老板在蚁小二客户端重扫该账号授权后直接补发，素材不用重传。

✅ **补发闭环（2026-09-24 当天实测走通，可直接照抄）**：重扫授权后**不用重新 prepare / 不用重传素材**
（`video.key` / `cover.key` 还在云通道，直接引用），照原样跑：

```bash
YX=".../yxer.exe"; P="<项目>/_临时/payload"
"$YX" validate  视频号 video "$P/视频号.json"              # 退出码 0
"$YX" publish video 视频号 "$P/视频号.json" --dry-run      # effectivePublishChannel=cloud
"$YX" publish video 视频号 "$P/视频号.json"                # 取 taskSetId
"$YX" query details <taskSetId>                          # 轮询到 stageStatus=success
```
实测时间线：提交 → 50s 后 `stageStatus=doing` / `stages=transcoding`（**这一步已证明登录态正常**，
原来失败时是秒级 `fail`）→ 再 60s 后 `success`。视频号转码要等 **1~2 分钟**，
`doing` 是正常中间态，**别当失败重发**（重发会产生重复作品）。
⚠️ **账号名不能当凭证——一律用 `platformAccountId` 核对**（2026-09-24 踩到）：视频号下同时存在
「牧子AI」`6a56f7a20f6b3a417a56e3f1`、「AI牧子琪」`69b8c394aa3c0dc7e737f122`、「晓君总和他的AI助理」、
「晓君总-销售智能体」四个号，名字高度相似；分组「牧子AI」的成员其实是
**小红书·牧子琪AI + 视频号·牧子AI + 抖音·牧子AI**（跨平台不同名）。
汇报和排障都要回查 `accounts list` 把 id 翻成真名，**别按分组名或印象写账号名**（我当天就写错过一次）。

**两类「重试无意义」的失败，识别后立即停手交人工**（重试还会加重风控）：

| errorMessage 特征 | 含义 | 人工动作 |
|---|---|---|
| `官方平台检测到您的账号存在风险…前往《创作者中心》里登录后单独发布一个作品` | 抖音风控，要求做一次人工验证 | 抖音创作者中心手动发一条作品，跳出验证并通过后恢复一键发布 |
| `获取用户信息失败登录失效` | 蚁小二侧登录态失效（微信系最常见） | 蚁小二客户端重扫该账号授权，再复用原 payload 补发 |

本次实测：抖音该错误连试两次均失败（不是偶发），别浪费轮次。

**取字段的权威入口（别凭记忆手写 payload）**：
- `yxer prepare <平台> video --json` → `form.businessFields` 给字段约束，`form.fieldPlacements` 给每个字段在 payload 里的落点
- `yxer publish init <平台> video --output tpl.json` → 生成可直接改的模板
- 三平台字段上限（2026-09-24 实测）：抖音 title ≤30 ／ 视频号 title ≤80、short_title ≤80 ／ 小红书 title **≤20**；description 三平台均 ≤1000
- 落点统一在 `publishArgs.accountForms[].contentPublishForm.*`，`video` / `cover` 挂 `accountForms[]` 下
- 小红书提交时蚁小二会自动把 description 转 HTML、把 `#话题` 转 `<topic text="...">`，不用自己拼
- 抖音 `tags` 是 string 数组可直接写；抖音话题要真实存在才有意义（实测「GEO官网」不存在，可用「GEO」「企业官网搭建」「AI获客」）

**等云发布审核（本机 `sleep` 不可用，PATH 缺 coreutils）**：
```bash
node -e "Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,60000)"
```
小红书从 `doing/review` 到 `success` 通常 1.5~2 分钟；🔴 **晚间（21:00 后）明显更慢 —— 实测 2026-10-12 卡在 `stages=review`（审核中）约 11 分钟才转 success**。
`review` **是审核中、不是失败**（只要 `errorMessage` 为空就别判失败），轮询窗口一律给足 **≥30 轮 / 15 分钟**；别因为视频号/抖音 4 轮就 success、小红书还在 review 就提前收工。

### Step 10.5 · 发布简报 / 推送（`scripts/notify_review.sh`）

成片 + 封面 + 发布回执推企微。**脚本存在但此前没写进本文件，补上（2026-09-16）**。

```bash
export PATH="/usr/bin:$PATH"          # 本机 PATH 缺 coreutils，脚本里的 grep/sed/stat/head 才找得到
bash scripts/notify_review.sh \
  --video "<成片.mp4>" --cover "<封面.jpg>" --pkg "<内容包.json>" \
  --qclog "<preflight 输出.txt>" \
  --mode notify --owner 晓君总 \
  --channel wecom --chat-id "<本次 sessions list 返回的 chat_id>"
```

| 参数 | 说明 |
|---|---|
| `--mode` | `notify`（**默认，两个号都用这个**：牧子琪＝知会；晓君总＝**发布后简报**，卡片写「已发布 + 回执」）。`review` 是旧口径（送审、等确认），**2026-09-22 起晓君总号不再使用** |
| `--owner` | 卡片抬头账号名，**默认「牧子琪」**。晓君总号**必须传 `--owner 晓君总`**，否则卡片串号（2026-09-16 修） |
| `--channel` | `none` 只出卡片（先干跑看文案）／`wecom` 真推 |
| `--chat-id` | **必须取当次 `wecom-cli message aibot sessions list` 的返回值**，不接受历史上下文里的值 |

三条硬规矩：

1. **`--qclog` 必须传 preflight 的输出文件**（含 `PASS x / WARN y / FAIL z` 那行）。传 ffprobe 原样输出会被判成「未跑质检」。
2. **发送成功看返回 JSON 的 `success` 字段，不看 exit code**（坑 20，脚本已内置校验 + 重试 1 次）。
3. **推送时机**：晓君总号**先发布、再推简报**（默认通过 + 事后可叫停）；卡片里写清发布回执（平台 / publishId / 是否补发），让他一眼看到"已经发了"。**旧口径「推送完就停、等回复才 publish」已作废**（2026-09-22 晓君总授权）。
   → 回执用 `--receipt "<多行文本>"` 传（2026-09-24 新增），不传的话卡片只会说"已自动发布"，看不到发到哪个号、publishId 是多少。
4. 🔴 **成片附件有 20MB 闸门（2026-09-24 实测）**：企微机器人「文件」消息超限必失败，
   报 `-202 server inner error http request failed`，**重试也过不去**。实测 66.5MB 成片失败、158KB 封面正常。
   脚本已内置闸门（>20MB 自动跳过视频只推卡片）。**别把这个失败当成"内容问题"去改片子**；
   成片路径在卡片正文里，老板从工作区或已发布平台看。同理**别无限重试**——按规矩只推 1 次。

## 2B. 真人素材直剪链路（已有视频，不走即梦）

> 🧩 **通用版见 skill `muzi-edit`（「牧子剪辑」）** —— 2026-10-16 把本链路的**剪辑标准件**抽成了账号无关的独立 skill（可直接对外复用 / 上 ima 知识库）。本节保留**本项目生产落地版**（绑定账号、出口、预检与发布），逻辑与 `muzi-edit` 一致。
> 🔴 **改剪辑逻辑时：先改 `muzi-edit` 的上游标准件，再同步本节**（`_ff` / `probe` / `extract_audio` / `build_join` / `burn_subs` 这五件在 `muzi-edit/scripts/` 里是**唯一上游**，本节调用时不要各改一份）。
> ✅ **2026-10-16 23:45 已把五件复制进本节 `scripts/` 并实测通过**（probe / extract_audio / build_join / burn_subs 各跑一遍，字幕样式核验正确）——
> 从此本链路**不再临场手写脚本**。⚠️ 两处同名文件必须**逐字节一致**，改完上游用这条同步（改完立刻核对 md5）：
> ```bash
> ME=~/.workbuddy/skills/muzi-edit/scripts; VP=~/.workbuddy/skills/video-pipeline/scripts
> cp "$ME"/{_ff.js,probe.js,extract_audio.js,build_join.js,burn_subs.js} "$VP"/
> ```
> 🔴 **本机无需任何环境变量即可跑**（已实测）：Node 子进程的 PATH 里**有** `~/.workbuddy/bin/ffmpeg/bin/ffmpeg`，`VP_FONTS_DIR` 也已存在（`~/.workbuddy/fonts`）。换机才需要照 `muzi-edit` §三 设 `VP_FFMPEG` / `VP_FONTS_DIR`。
> 📌 **本文档里所有 `scripts/xxx` 一律指本 skill 的 `scripts/` 目录**（`~/.workbuddy/skills/video-pipeline/scripts/`），**不是**片子目录下的 `scripts/` —— 片子目录只放当轮产物（`_setup.js` 那套工作簿脚本 + 成片 + payload）。执行时按需写绝对路径，别指望 cwd 恰好对。

**适用**：手上有拍好的**真人原声视频**（如微云 `MUZIAI/晓君总视频` 上传的素材）。
不需要 AI 生成画面 —— 只要 **去口误 → 字幕 → 封面 → 缩放到 720×1280 → 质检 → 送审**。
2026-09-17 首次跑通（晓君总真人素材 · 59.5s 成片 · preflight 8 PASS）。

🔴 **前置 0 · 素材体检（必做）**：`node scripts/probe.js --in "<素材>"` ——
先确认**有音轨**（无音轨退出码 3：抽音频 / ASR / 整条口播链路都不适用，**别白跑一轮**）；
同时拿到真实时长 / 分辨率 / 朝向，后面 `--scale` 与抽帧时刻表照它写，**别猜**。
（要结构化结果给后续脚本吃，加 `--json`。）
🔴 **本线视频号出口 = 「晓君总-销售智能体」`6a9a618819a8a4f0948f8396`**（2026-10-09 晓君总指令）：
本线 payload 的视频号 `platformAccountId` **显式取该 id**（它在 `extraPublishAccounts.视频号` 白名单内，preflight C1 认，
只是不参与自动通发）；⛔ **不要**用 `publishAccounts.视频号`（那个是**即梦线**出口「晓君总和他的AI助理」）。
抖音两线共用「晓君总 私域智能体」，不随本规则变。

| 步骤 | 即梦链路 | 真人直剪链路 |
|---|---|---|
| 1 内容包 | video-copywriter 产出 | **没有**（内容即素材）。送审卡片需要时，按实情补一个**最小 json**（date/title/scene/script + `_source`/`_pipeline`/`_cut` 说明字段） |
| 2 分段 / 3 生成 / 4 打码 / 5 part2+ | 需要 | **全部跳过**（素材本身就是完整一条） |
| 6 字幕 | `gen_subtitles.js`（段内时间轴按**字数占比估**） | **`asr_to_ass.js`**（ASR **逐字时间戳**，与口型对齐） |
| 7 封面 | 同 | 同（底帧从**要发布的那条素材**上抽） |
| 7.5 剪辑修整 | trim_silence + **speed_normalize** + 插 B-roll | **掐头尾静音 + 段级语速拉齐 + 插素材**（见 §2B.4 / Step 7.5 ①c） |
| 8 拼接烧录 | concat part*.mp4 + ass | **`build_join.js`（剪段+拼接+scale）→ `burn_subs.js`（烧字幕）** 两条标准件（见 §2B.3） |
| 9 / 10 / 10.5 | 同 | 同（质检 → 送审；发布规则完全不变） |

### 2B.1 ASR 转写（apiz 火山录音识别 2.0）

```bash
# ① 抽音频（16k 单声道：够 ASR 用，体积小）—— 标准件，不再手写 ffmpeg
node scripts/extract_audio.js --in "<源视频>" --out "<纯ASCII名>.wav"
# ② 上传到 apiz CDN，拿 public_url
apiz upload "<本地音频>" --folder muzi-xjz
# ③ 调识别（⚠️ audio_url 是必填**参数**；位置参数只是占位，不传会报 requires at least 1 arg）
apiz generate "transcribe" \
  --params '{"audio_url":"<public_url>","show_utterances":true}' \
  --model volcengine/speech-to-text/bigmodel-v2 --wait
# ④ 结果落盘 —— 用 task_id 复查，**不重复计费**
apiz tasks get <task_id> > raw_asr.json
```

- **抽音频用 `scripts/extract_audio.js`**（2026-10-16 标准件化，实测通过）：输出 **16k 单声道 pcm_s16le wav**。
  比原来手写 `libmp3lame 64k` 更省事、且 wav 是无损、ASR 的标准输入（不再有 mp3 编码损失）。
  73s 素材 ≈ **2.3 MB**，上传无压力。音频文件名**仍要纯 ASCII**（规避中文路径老问题）。

- 计费 **2 积分/分钟**（不足 1 分钟按 1 分钟）；70s 素材约 4 积分，不构成瓶颈。
  → 178s 素材 ≈ 6 积分 = **约 0.06 元**（1 积分 = 0.01 元）。**贵不贵不是问题，「余额需 ≥10 元」的门槛才是问题。**
- 🔴 **apiz 上还有一个「识别类」模型，用途不同别搞混**（2026-10-14 全量盘点 `apiz models list`，audio 类共 8 个）：
  - `volcengine/speech-to-text/bigmodel-v2` —— **本节这个**，**无原文自动识别**，2 积分/分钟。
  - `volcengine/captioning/ata-speech`「火山字幕打轴(说话)」—— **强制对齐(forced alignment)**，
    需**音频 + 已知文本**，回句级+字级毫秒戳，**10 积分/分钟**（CLI：`apiz align "<文本>" --audio <url> --mode speech`）。
    💡 **数字人线尤其该用这个**：口播文案本就是「一个字也不许改」的定稿，
    喂进去拿到的是**零同音错字**的精确时间轴，比自动识别更准（代价是贵 5 倍，且消耗同一余额池）。
    微云真人线没有原文，仍只能用 `bigmodel-v2`。
  - ⛔ 其余 audio 类（`minimax/t2a`、`minimax/voice-clone`、`minimax/voice-design`、`minimax/music-gen`、
    `leonardo/seed-audio-1.0`、`volcengine/captioning/ata-singing`）都是**生成/TTS，不是识别**，别拿来转写。
- 返回 `result.utterances[]`，每项带 `start_time`/`end_time`（**毫秒**）与 `words[]`（**逐字**时间戳）。
- 音频文件名**用纯 ASCII**（规避中文路径老问题）。

🔴 **ASR 是「微云真人直剪」的硬前置，而它只有一条云通道 —— apiz 余额**（2026-10-07 实测踩到）：
- 余额不足时 `apiz generate transcribe` 直接回 **`HTTP 429 余额不足: 至少需要 10.0 元，当前余额: -9.0 元`**
  —— 注意**门槛是「余额 ≥10 元」而不是「够本次计费」**，余额被扣穿成负数后**所有** apiz 调用全灭
  （`apiz upload` 可能仍可用，别被「上传成功」误导成「通道没问题」）。
- 先 `apiz account balance` 预检，再抽音频上传，**别倒过来**。
- **本机兜底有两条路，精度都不够直接出片**（详见 `muzi-local-asr-edit` 第 0 / 2B 节）：
  - **Vosk small**（秒级）：错词多，实测出过「我们 看看 他 是不是 去 二十号 加大 网上 烦 烦 烦」
    → **只够粗剪定位，烧进画面就是事故**。
  - 🔴 **faster-whisper（2026-10-14 实测可跑）**：`muzi-local-asr-edit/scripts/fw_transcribe.py`，
    tiny/int8 约 **0.19x 实时**（178s 素材 ≈ **15 分钟**），出**词级时间戳**、质量明显好于 Vosk，
    但仍有同音错字（「剪辑」→「剪级」）→ **可做粗稿，必须过 `--fix` 词表 + 人工校对才可发布**。
    ⚠️ 旧记录「faster-whisper 段错误(139)」系**误判** —— 当年那个 `TypeError: metadata_errors` 是 **PyAV 版本旧**，与 AVX2 无关；
    `fw_transcribe.py` 用 ffmpeg 直接解码绕开，已实测跑通（57 words / 15s，输出与 float32 完全一致）。
  - ⛔ 云通道不可用时**优先级**：能等 → faster-whisper 粗稿 + 校对；不能等/要零错字 → 归档 + 报阻塞 + 顺延。
- ⇒ 🔴 **通道不可用时的正确处置：「下载归档 + 台账标 `downloaded` + 汇报写明阻塞」，剪辑顺延，**
  **⛔ 绝不用 Vosk 字幕顶替、⛔ 绝不跳过字幕直接发**（属「不降级」红线，与即梦积分不足同型）。

### 2B.2 字幕：`scripts/asr_to_ass.js`

```bash
# 先 --dry-run 逐屏核对切点，**定稿再真写**
node scripts/asr_to_ass.js --in raw_asr.json --out subtitles.ass --out-txt script.txt \
  --style <profile.defaults.subtitleStyle> \
  --slice "1.10-57.60,64.00-67.00" \     # 剪辑映射：原片时间 → 成片时间（可多段）
  --fix "木子琪=牧子琪" \                  # ASR 同音错字纠正（**必须等长**）
  --dry-run
```

- `--slice` 把原片时间轴重映射到成片时间轴；落在保留段外的字**自动丢弃**，并在剪切点**断屏**（不会串屏）。
- `--fix` 只支持**等长**替换（否则字符级时间戳错位，脚本直接拒绝退出）。
- `--out-txt` 顺便导出字幕纯文本稿（送审内容包 / 存档都用得上）。
- 样式表在 **`scripts/_sub_styles.js`，与 `gen_subtitles.js` 共用**（单一真相）——改样式只改那一处，别在调用方再抄一份。

### 2B.3 剪辑 + 缩放 + 烧字幕（两条标准件命令）

🔴 **2026-10-16 起改用标准件，不再手写 `filter_complex`**（原写法降级为本节末尾的「排错参考」）：

```bash
# ① 按 segments.json 精确剪段 + 拼接 + 缩放到 720×1280（段尾气口由 segments 带进来）
node scripts/build_join.js --in "<源视频>" --segments segments.json \
    --out joined.mp4 --scale 720:1280 --fps 30
# ② 烧字幕出成片（内部已 cwd=ass 目录 + 显式 fontsdir，两个老坑都固化了）
node scripts/burn_subs.js --in joined.mp4 --ass subtitles.ass --out "<成片>.mp4"
```

- 🔴 **`build_join.js` 会自检气口**：segments 缺 `gap` 字段、或段尾气口合计 ≈ 0 → 直接 WARN
  「你多半在用裸区间手写 segments」。**看到 WARN 先回去用 `plan_cut_by_words.js` 重出 segments**，
  ⛔ 别硬着头皮往下烧字幕（硬切的 joined 里根本没有静音可留，后面再宽松的 `--gap-*` 也补不回来）。
- 🔴 **缩放默认等比 + 黑边填充（不变形）**；要精确拉伸必须**显式**加 `--stretch`（会变形，仅在明确要拉伸时用）。
- `--fps 30` 建议显式给（与产出平台一致）；不给则沿用源帧率。
- **`burn_subs.js`** 把两条坑当默认行为固定下来：① `cwd = ass 所在目录` + 相对文件名 → 绕开 Windows 中文路径在 ass 滤镜里的转义地狱；② 显式 `fontsdir`（取 `VP_FONTS_DIR`，或 `<skill>/fonts`）→ 不会静默回落系统字体。
  ⚠️ 字体目录不存在时它**只打 WARN 继续跑** —— 成片字体「莫名变了」时**先看这行 WARN**。
- 两步 = 两次编码（原手写版一步完成）。实测 720×1280 / 73s 量级：拼接 ≈ 34s、烧字幕 ≈ 20s，**代价可忽略**；
  换来的是「不再每轮手写滤镜」+ 气口机器自检。
- 源带 `rotation` 元数据时 ffmpeg 会自动摆正，filter 里拿到的已是显示方向 → `--scale 720:1280` 直接对（**别再手动转 90°**）。

<details>
<summary>排错参考：原手写 filter_complex 版本（标准件报错时可对照）</summary>

```bash
ffmpeg -y -i "<源视频>" \
 -filter_complex "[0:v]split=2[vA][vB];[0:a]asplit=2[aA][aB];\
[vA]trim=start=1.10:end=57.60,setpts=PTS-STARTPTS,scale=720:1280,setsar=1[v0];\
[aA]atrim=start=1.10:end=57.60,asetpts=PTS-STARTPTS[a0];\
[vB]trim=start=64.00:end=67.00,setpts=PTS-STARTPTS,scale=720:1280,setsar=1[v1];\
[aB]atrim=start=64.00:end=67.00,asetpts=PTS-STARTPTS[a1];\
[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a];\
[v]ass=subtitles.ass:fontsdir='C\:/Users/admin/.workbuddy/fonts'[vs]" \
 -map "[vs]" -map "[a]" -c:v libx264 -crf 18 -preset medium \
 -c:a aac -b:a 192k -movflags +faststart "<输出>.mp4"
```

- 同一路输入被两个 `trim` 消费 → **必须 `split` / `asplit`**，否则 ffmpeg 报流被重复占用。
- `setsar=1` 让两段 SAR 一致，`concat` 才不失败。
- ass 滤镜的路径要转义（`: ` → `\:`），这就是标准件改用 cwd + 相对名的原因。
</details>

### 2B.4 剪什么、不剪什么（2026-09-17 定 · 09-29 修订 · 10-05 / 10-06 放宽 · 🔴 **2026-10-14 三次放宽 = 气口语义**）

> 🔴 2026-09-29 晓君总原话：「剪辑时**去气口，去空白，去重复，去啰嗦或无意义的话**」——
> 比 09-17 版更紧。下表已按新口径更新，**旧「句间停顿 0.5–0.7s 不剪」的表述作废**。
>
> 🔴🔴 **2026-10-05 第一次放宽（已作废）**：晓君总听后反馈「**气口剪太多，听起来紧**」——
> 参数由 `0.32/0.45/0.18/0.12` 放宽到 `0.45/0.65/0.32/0.25`。
>
> 🔴🔴🔴 **2026-10-06 二次放宽（⚠️ 实拍线已作废 · 仅即梦生成段沿用）**：晓君总再反馈「**气口还是
> 剪得太多了，可以适当多留一些**」→ 参数放宽到 **`0.55 / 0.60 / 0.42 / 0.30`**。
> **实测锚点（同一条 109.15s 底片）**：v1 紧口径 `68.38s` → 10-05 口径 `74.15s` → 10-06 口径 `84.33s`。
>
> 🔴🔴🔴🔴 **2026-10-14 三次放宽 = 气口语义（✅ 实拍线当前唯一有效口径）**
> 原话：「**气口剪得太多，语句之前太紧了，可以尝试在每句话前留 0.3-0.5 秒，语速放到 1.1 倍。**」
> → 改用 `trim_silence.py --gap-min 0.30 --gap-max 0.50`：**每个静音保留 `clamp(时长, 0.30, 0.50)` 秒，
> 不再整段删除**（锚在静音尾部 = 贴着下一句起点），`--min-dur` 同步降到 `0.30`。
> ⛔ **「放宽参数」这条路已经到头** —— 10-05 / 10-06 两次放宽的都是**窗口**，而真正的病根是
> **拼接阶段硬切把段间静音剃光了**（2026-10-14 实测 v1 `joined.mp4` 95.95s 里段间静音 = **0**）：
> 不给出物理空间，trim 参数再宽松也补不回来 → **气口必须在拼接那一步垫回来**（见 §2B.6「拼接留气口」）。
> **v1 → v2 实测（同一条 xjz11）**：v1 紧口径 = **66.14s**（1.2x，拼接段间 0 气口）；
> v2 = 拼接垫 **8.35s** 气口 + 气口语义保留段内静音 + 1.1x。
> 判断标准照旧：「**念起来像不像正常说话**」——一段里连续三个以上停顿都被压到 0.3s 以下 = 剪过头。
>
> ⚠️ **两套语义别记反**（全文见 `scripts/trim_silence.py` 文件头）：
> · **气口语义**（传了 `--gap-min/--gap-max`）= 字面意思：`clamp(静音时长, 下限, 上限)`，**不删除**；
> · **legacy 双窗口**（不传 gap 参数）：`--min-dur` 是主控（**调大 = 少删 = 更宽松**），
>   `dur > max-pause` 保留 `keep-pause`、其余**整段删除** → 所以 **max-pause 调大反而更紧**。
>
> 🔴🔴🔴 **2026-10-19 晓君总指令：即梦数字人线「不用剪气口」—— 两套语义都不再用于生成段。**
> 原话：「**明天开始，即梦数字人视频，不用剪气口**。」
> → 即梦生成段改用 `trim_silence.py --head-tail-only --edge 0.10`：**只裁片首片尾大段空白，
> 段内停顿/气口/换气一个字不剪**（跑出来的日志会明确打印「段内停顿 0 处改动」）。
> **实测锚点**：同一条 part1（8.096s）→ 旧 legacy 口径剪成 **7.32s**（吃掉 0.78s 呼吸），
> head-tail-only 口径 **8.096s**（首尾本无空白 → 直接 copy，零改动）。
> 连带两条：① 段长变长 → 动效 `--segDurs` 必须传裁剪后 ffprobe 实测值；
> ② 字幕 `--probe` 读的仍是裁剪后段长，顺序还是「先裁 → 再字幕」，别因为「反正不剪」就省掉这步。

| 动作 | 做不做 | 依据 |
|---|---|---|
| **口误重复**（同句说了两遍 / 改口） | **剪，删前保后** | 逐字时间戳定位。2026-09-29 实证两处：「用我的形象啊 \| 用我的数字形象」、「从一些小的点 \| 从自己日常生活当中的一些小点」——各删前一遍后语义完整通顺 |
| **气口 / 换气停顿** | **每句话前留 0.30-0.50s**（🔴 **2026-10-14 三次放宽 · 气口语义 · ⚠️ 仅实拍线**；**即梦生成段 2026-10-19 起完全不剪**，见上） | `--gap-min 0.30 --gap-max 0.50`：**每个静音保留 `clamp(时长,0.30,0.50)` 秒、锚尾贴着下一句，不再整段删除**；`--min-dur 0.30`。⛔ **已作废**：09-29 `0.32/0.18`、10-05 `0.45/0.32`、10-06 `0.55/0.60/0.42`（三次都只放宽「窗口」，没解决拼接硬切把气口剃光） |
| **空白**（段首尾静音、超长停顿） | **留 0.30-0.50s，不剃光** | `--edge 0.30`；气口语义下 `--gap-max 0.50` 即「再长也只留 0.50s」（替代旧的 `--max-pause`） |
| **啰嗦 / 无意义的话** | **剪整句**（09-29 新增口径） | ⚠️ **尺度**：只剪**明确的整句废话**（同义反复绕圈、跑题插叙）。**有信息量的句子不得当「啰嗦」剪掉** —— 拿不准就默认保留并记进简报，等晓君总回话 |
| **语气词（呃 / 啊 / 嗯）** | 🔴 **逐字扫、删「孤立口水词」（2026-10-15 v3 定稿）** | 旧口径「不剪字」**已放宽**：对**孤立成字的**「呃 / 嗯 / 额 / 唔 / 诶」（ASR 单字成 token、前后不粘连）**删整字** —— xjz11 v3 删「呃」×2，实测**不口型跳切**、听感更干净（晓君总 10-15 反馈「废话没剪干净」即指此）。⚠️ **边界**：只删**独立口水词**；**词内 / 句尾语气字**（「好的呀」「对吧」的「呀 / 吧」）⛔ 不删。**不撞铁律 1**：删的是他嘴里蹦的「呃」，不是文案的字 |
| **半句中断的废弃段**（说了半句就停、随后重起话头） | **剪整段** | 见坑 33。典型信号 =「半句 + >3s 间隔 + 画面同时转走」 |
| **手机转向展示的空镜段**（镜头离开人脸，去拍白板 / 大屏 / 天花板） | **剪** | 见坑 31/32/**35**。这段在 ASR 里长得像正常段落（他还在说），`verify_cuts.py` 能自动报出来 |
| 句间自然停顿（**< 0.30s**） | **不剪** | 太短的停顿剪了会顿；真人视频要有人味。≥0.30s 按「气口」处理，保留 0.30-0.50s（🔴 10-14） |
| 孤立单字屏（如尾句前的「嗯」，<0.4s） | 🔴 **若为口水词 → 删；有语义 → 留（v3 起）** | 与上一条一致：孤立口水词（呃/嗯/额/唔/诶）删整字，删完若出现超短屏由字幕脚本合并；**仅当它承载语义**（如应答的「对」「行」）才保留 |
| 改口播文字 | **绝对不**（铁律 1） | 只剪重复 / 废弃段 / 啰嗦 / 停顿，**不改内容；一字不许改** |

🔴 **定剪点前后各跑一次 `verify_cuts.py`（见 Step 9.1）——不要再靠「记得抽帧」**：
定剪点前拿**原片**跑，它直接报出「哪些秒段人不在画」；出片后拿**成片**跑，它验剪接点。
2026-09-24 那次「92s 转向」就是漏在「靠人记得看」这一步上的，已改为脚本闸门（坑 35/36）。

⚠️🔴 **2026-09-29 实测：闸门对「手持自拍 + 顶光」素材会误报** ——
`verify_cuts.py` 的人脸检测是 Haar 级联（default / alt2 / profileface）。这类素材人脸**全程在画**
（已抽 6 帧 + contact sheet 242 帧逐帧核对），但检测率被顶光低对比 + 头部姿态变化打到 6%，
于是整片报 FAIL。`--scale-w 240 → 480` 复跑**仍是 FAIL** → 说明瓶颈是**姿态**，不是帧尺寸。
**处置口径**：① 先抽帧 / 看 contact sheet **人工核对**；② 确认人脸全程在画 → 判**误报**并放行，
但**必须在简报里写明「闸门误报 + 人工核对依据」**；③ **待办**：把检测器换成人脸姿态更鲁棒的
`cv2.FaceDetectorYN`（YuNet）或 DNN res10，**根治**误报（⛔ 不要靠放宽 `--min-ratio` 掩盖）。

### 2B.7 插入 B-roll 素材规格（2026-09-29 晓君总指令）

> 原话：「有合适的素材可以插入素材，**素材需要去掉原声**，需要缩放的话**必须同比例缩放，不得变形**。」

| 约束 | 做法 |
|---|---|
| **去原声** | `overlay` **只叠视频轨**，音频 `-map 0:a` 一律取口播原声 → 天然无 B-roll 原声。⛔ 不要把 B-roll 音频混进来 |
| **等比缩放** | `[1:v]scale=720:-2,setsar=1` —— 用 `-2`（自动算高）**不要写死宽高**，写死就会变形 |
| **时长** | `segment_materials` 视频**秒数 ≤ 4**（🔴 2026-10-04 起，`validate_plan.js` 硬闸；条目带 `speed:1.5` 时 4s ≈ 2.67s 时间线）、图片 ≤ 1s |
| **归属** | 素材按**产品线归属**，跨线不得顶替（台账 `营销素材/_素材归属清单.md`）。讲内容生产线 → 用 `内容生产线素材/`；同线有多条时**优先取更新时间最新的一条**（见 §2B.10-B） |
| **插入点** | 🔴🔴 **不要用 `enable='between(t,A,B)'`** —— ffmpeg `overlay` 的 `enable` 表达式里 **`t` 是「叠加层自己的时间轴」**，不是主输入。叠加层只有 2.7s 时 `between(t,5.7,8.5)` **永远不成立 → 插片静默消失、不报错**（2026-09-29 实测）。✅ 正确做法：`[1:v]setpts=PTS-STARTPTS+<A>/TB` 把叠加层**推到目标时刻**，再 `overlay=0:0:eof_action=pass:repeatlast=0`。A 用**成片时间轴**（= 剪后 ÷ 1.1，别用原片时间） |
| **⚠️ 时长陷阱（两种，都已踩）** | ① **尾部冻结帧**：`color=` 等无限源当背景、或叠加层比窗口短，overlay 会取**较长输入** + `repeatlast=1` 重复末帧 → 成片尾部多冻结帧。**必须**给输出加 `-t <成片时长>`。② **整段冻结帧**：叠加层（如 2.3s 素材）**在窗口之前就 EOF** 了，而窗口在 6.0–8.3s → 重复贴的是**最后一帧** → 插片整段静止（09-29 事故根因）。✅ 用 A 的 `setpts` 延迟法，叠加层起止时间与窗口**天然对齐**，两个陷阱同时消掉 |
| **⚠️ 底片必须先缩放** | 口播底片常是 1080×1920：**必须** `[0:v]scale=720:1280,setsar=1[base]` 再做 overlay，否则成片分辨率跟着底片走、B-roll 只盖住左上角 |
| **🔴 窄素材处理** | 素材比成片更窄（如 582×1280 = 9:19.8 vs 成片 9:16）时：`fg` 用 `force_original_aspect_ratio=decrease` **contain 居中**（⛔ 不裁切——会切掉账号头部关键信息）、`bg` 用 `force_original_aspect_ratio=increase,crop,gblur,eq=brightness=-0.12` **补满左右**，避免黑边。两者都等比，**不变形** |
| **🔴 素材动态性检测（2026-10-05 修订）** | ⚠️ **晓君总本人经微云上传的素材 = 可信来源 → 一律免检动态性、直接使用**（2026-10-05 原话：「只要是我上传的素材，不要检测动态性闸门，直接使用」）。**仅对第三方 / 网上下载 / 来源不明**的素材才「抽 3 帧比 md5」（相同=静止，不可用）。微云线调 `compose_broll.js` 时传 **`--trust-source`** 跳过闸门⓿；合成后仍验「插片窗口有运动」（见下 ④） |

参考实现（2026-09-29 三次修复后 · 微云直剪首条，B-roll 插在成片 5.72–8.46s）：

🔴 **命令必须落盘成脚本**（`compose_v2.js` 之类），⛔ 不许手敲一次性命令 —— 09-29 两种插片事故都因上一轮命令没落盘，事后无从复现、无从 diff。

```bash
ffmpeg -y -v error \
 -i body_1.1x.mp4 \
 -ss 0.15 -t 2.74 -i "营销素材/内容生产线素材/晓君总视频号和数字形象.mp4" \
 -filter_complex "[0:v]scale=720:1280,setsar=1[base];\
[1:v]fps=30,setpts=PTS-STARTPTS+5.72/TB,split=2[bg][fg];\
[bg]scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,gblur=sigma=30,eq=brightness=-0.12[bgb];\
[fg]scale=720:1280:force_original_aspect_ratio=decrease,fps=30[fgs];\
[bgb][fgs]overlay=(W-w)/2:(H-h)/2[broll];\
[base][broll]overlay=0:0:eof_action=pass:repeatlast=0[vout];\
[vout]ass=subtitles.ass[vsub]" \
 -map "[vsub]" -map 0:a \
 -t 39.633 -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -r 30 -c:a aac -b:a 128k final_v2.mp4
```

**合成后 5 道闸门（脚本内自检，任一 FAIL 不许发布）**：

| 闸门 | 判据 |
|---|---|
| ① 时长 | 成片 ≈ 口播 body（±0.2s） |
| ② 分辨率 | = 720×1280 |
| ③ 音轨 | 有音轨（只取口播原声） |
| ④ 运动 | `freezedetect=n=-60dB:d=0.30` → 插片窗冻结占比 ≤30% |
| ⑤ **插片可见性** | 插片窗 PSNR(vs 底片) 必须**比对照区低 ≥5dB 且 <30dB** —— ⚠️ ④ 单独验不出「插片静默消失」（人在那儿本来就动，09-29 实测漏过一版）|

⚠️ **B-roll 素材常带 rotation 元数据**（本机 `多平台发布记录查看页面.mp4` 标称 1920×1080，实际显示 1080×1920）——
`ffprobe` 的 `width/height` 是**编码尺寸**，判断「横屏还是竖屏」必须看 **rotation 或 `display_aspect_ratio`**，否则会算错缩放。

### 2B.8 成片与封面都必须用「日期唯一名」上传（2026-09-29 封面事故 + 2026-10-14 成片事故 · MUST）

> 起因①（封面）：09-29 微云直剪线封面用通用名 `cover.jpg` 上传 → 视频号 + 抖音抓到的都是 **09-28 小红书那张封面**。
> 起因②（成片）：10-14 数字人线成片沿用原名 `AI时代最大的杠杆_完整版字幕.mp4`，与 **10-07 同题成片完全同名**
> → 两次 `yxer upload` 都得到同一个 key `AI_6170f7bb.mp4`；**上传虽覆盖成功（源站已是新片），
> 但该 URL 被 CDN 缓存约 30 天不回源** → 三平台发布时抓到的仍是 10-07 的旧片（26448424B / 56.73s）。
> 封面当天是对的、成片是错的 —— 差别只在「封面按本节带了日期、成片没带」。

两条叠加的机制（详版见 `references/publishing.md` §6）：

| 机制 | 事实 |
|---|---|
| key 按文件名生成、**不带 hash** | `yfb/t-<租户>/cover.jpg` 是全产线**共用 key**，小红书线（09-22~09-28）与短视频线（09-16）都往这里写，**后传覆盖先传** |
| **成片 key 也由文件名派生**（10-14 补） | 形如 `<ASCII前缀>_<hash>.mp4`（`AI_6170f7bb.mp4`）；**hash 由文件名算出，同名必同 key** —— 别以为「带 hash 就唯一」 |
| 该 URL 被 CDN 缓存 **30 天** | 实测 `X-Swift-CacheTime: 2592000`；覆盖上传后 `GET` 仍回 `X-Cache: HIT TCP_MEM_HIT` + 旧 `Last-Modified` → 平台抓到旧图 |

**做法**：

1. 上传前先改名：封面 `cover_<MMDD>_<账号>.jpg`（如 `cover_0929_xjz.jpg`）、**成片 `<title>_完整版字幕_<MMDD>.mp4`** → 新 URL、无缓存；
2. `yxer upload` 后**回验**：`curl -sD- "<新 coverUrl>"` 的 `Content-Length` / `Last-Modified` 必须与本地一致（首次应 `X-Cache: MISS`）；
3. **旧 key 一律不复用**；`preflight_check.js` 的 **B3（封面）/ B4（成片）** 会拦（basename 不含日期标记 → FAIL 阻断发布）；
4. 已发错封面：蚁小二**没有改封面接口**，只能 `yxer publish delete <task_id>` 删帖 + 重发 —— **先发新的、验 success、再删旧的**。

### 2B.9 封面字体/斜体必须走 profile 的 `coverFont`（2026-09-29 事故 · MUST）

> 起因：09-29 微云直剪封面只传 `--style s1`，而当时 `STYLES["s1"]["font"] = "douyin"` →
> 出的是**优设标题黑直立字**；规范却是 **`song-bold` 思源粗宋 + `--italic` 斜体切变**
> （`xiaojunzong.json` → `defaults.coverFont`，2026-09-16 晓君总定；09-22~09-28 各期 manifest
> 记的都是 `s1 + song-bold + italic`）→ 被晓君总退回重做。

- **必须**读 `profiles/<账号>.json` 的 `defaults.coverStyle` **和** `defaults.coverFont`，
  把 `coverFont` 显式传给 `--font`；要斜体再加 `--italic`。xiaojunzong 现行：
  `make_cover.py --style s1 --font song-bold --italic …`
- 出图后**肉眼看字体形态**（宋体有衬线笔锋、斜体是切变倾斜）—— 别只确认「有字」就算过。
- `STYLES["s1"]` 已于 2026-09-29 对齐规范（`font="song-bold"`、`italic=True`，并新增 `--no-italic`），
  所以 `--style s1` 单参数现在就是对的；但**其它风格仍以 profile 为准，不要依赖默认值**。
- 封面文案规范：**≠ 视频标题、更短更冲**，两行各 5-8 字、缩到 200px 宽仍可读。
  ⛔ 禁用自造复合词（只用老板日常说法）、禁用自贬词（如「随便」）。
  两行关系二选一：「L1 断言/反差 → L2 动作/结果」或「L1 事实 → L2 反问戳痛」
  （09-28《客户分给几个销售／你到底管得住吗》即后者）。

### 2B.10 超长素材：**整条出片**（语义节选只去冗余，不拆条）+ 最新配套素材插入（2026-10-12 晓君总指令，覆盖 10-05 拆条口径）

> 原话：「如果下载的视频内容太长，可以根据语义进行节选，节选的内容要有明确主题，根据主题生成标题、封面，
> 然后发布。下载视频内容的时候，如果有最新的配套素材，则可以在视频中插入使用。」

**适用**：微云 `MUZIAI/晓君总视频` 下载的**长素材**（去重复/去啰嗦/去气口 + 1.1x 之后仍明显超长）。

#### A. 语义节选（一条长素材 → **仍是一条成片**；⛔ 不得拆条）

> 🔴🔴 **2026-10-12 晓君总指令（覆盖 10-05「拆成 N 条」旧口径）**：
> 原话「**011和012是一条短视频，不要分成2条了。013和014也是一条**」。
> 一条长素材 = **一条短视频**。「语义节选」= **在一条片子里**去掉口误/啰嗦/重复/气口，
> **不是**把一条素材切成几篇独立视频分别发。此前「>90s 自动拆条」的做法**已作废**。

| 项 | 口径 |
|---|---|
| **默认动作** | 一条长素材 → **出一条完整成片**（默认，不问）。剪辑只做整段取舍 + 去气口（每句前留 0.3-0.5s）+ 1.1x |
| **⛔ 禁止** | **不许**为了凑时长/凑条数把一条素材拆成 2 条以上分别发布（含「上下集」式拆法） |
| **唯一例外** | 素材里**明显是多个互不相干的话题**（A 讲完再讲 B，各自能独立成篇）→ **先报晓君总确认**，确认后才可拆；**不得默认拆** |
| **时长** | 整条 **45–150s** 均可发；>150s 优先**在片内继续压冗余**（去重复/去气口/精简停顿），**不是拆条** |
| **标题** | 从整条主题出，用老板日常说法，口语化，**不造复合词** |
| **封面** | 从整条主题出，**比标题更短更冲**（两行各 5–8 字）→ §2B.9；**key 必须日期唯一名**（§2B.8） |
| **目录** | 一条一个目录 `output/short_video/<日期>_weiyun_<slug>/`（纯 ASCII，cv2 不认中文路径） |
| **发布** | 一份 payload、跑一次 yxer 三步（validate → dry-run → publish） |
| **台账** | 一条成片记一条 entry（`date` + `account` + `seq` + `_source.file_id`）；`weiyun_watch.js mark --id <file_id> --status published --note "<标题>（整条）"` |
| **⛔ 红线** | 节选只做**整段取舍**，边界必须落在**语义完整处** —— **仍不得改一个字**（铁律 1）。不许为了凑时长掐头去尾剪半个词 |

#### B. 最新配套素材插入（下载同轮扫库 → 有则插）

- 下载素材的**同一轮**，扫一遍配套素材库；**若有「更新时间最新 + 与本节选主题同产品线」的素材** → 在成片对应位置插 B-roll（**可选**，1–2 段/条）。
- 「配套」判定 = **同产品线 + 语义对应**（讲什么就配什么证据画面）；归属台账 `营销素材/_素材归属清单.md`，**跨线不得顶替**（同 §2B.7 / `MEMORY-video.md §5`）。
- 规格**全部沿用 §2B.7**：🔴 **动态性免检**（微云素材全是晓君总本人上传 = 可信来源，⛔ 不再抽帧比 md5 —— 2026-10-05 指令）、🔴 去原声、🔴 等比不变形、单段 ≤4s、🔴 **走 `compose_broll.js --trust-source`**（⛔ 不许手敲 overlay 命令）。
- 插入点用**成片时间轴**（= 剪后 ÷1.1，别用原片时间）；合成后仍须过 `compose_broll.js` 的闸门（微云线传 `--trust-source` → 闸门⓿ 跳过，**余 ①–⑤ 照验**），任一 FAIL → 该条不发布。
- 🔴🔴 **素材合规处理 = 打码后直接用（2026-10-05 晓君总第二次指令 · 覆盖同日「判不插」的旧口径）**：
  原话「**打码后直接插入和发布，无论我是否拍板和审核**」。
  录屏/截图里出现**真实客户身份信息**（微信头像/昵称、客户名称或公司、聊天正文、带 token 的后台链接、内部话术）→
  ⛔ **不再判「不插」、不再停下来等拍板**，而是三步照走：**① 打码 → ② 照常插入 → ③ 照常发布**。
  打码手法：`split` + `crop` 定位敏感区 + `scale=w/24:h/24:flags=neighbor,scale=w:h:flags=neighbor` **像素化**
  （比 `boxblur` 彻底、肉眼一看即知已处理）→ overlay 回原位。
  ⛔ **打码后必须逐帧回验**（至少抽 首/中/尾 3 帧）：只要有一帧露出客户名称/URL/昵称 → 重定坐标重做，**不许「大概盖住」就上**。
  ⚠️ **两条实战判据（2026-10-05 四条国庆录屏实测）**：
  ① **画面在滚动的素材，固定坐标打码必漏** —— 坐标按某一帧定，滚走后内容整体位移，「打过的地方」其实滑走了。
  ② **微信顶栏（返回/昵称/菜单）固定不随内容滚动** → 敏感只在昵称条时可以稳定打码。
  → `转真人对接录屏`（全程滚动 + 整屏敏感：客户名称/两个 token URL/内部接管话术/「晓君哥」错误称呼）**打码不可行 → 弃用**；
  → `Ai对话录屏`（仅顶栏昵称 `sherry-` 敏感，内容区滚的是产品对话）**打码通过 → 采用**。
  ✅ 打码产物**落盘成独立 B-roll**（`broll_<slug>_masked.mp4`），原素材原样归档；`_素材归属清单.md` 登记「已打码版本路径」。
- 🔴 **上面这套同样管「主线素材本身」（2026-10-09 r73 实战补充）**：微云下载的整条素材可能就是**录屏/拍屏**（例：`lv_0_*.mp4` = **手机拍显示器**的看板录屏）。
  判定链：**逐帧复核画面（`ffmpeg -vf fps=1/5,scale=270:-1,tile=5x3` 出缩略图集 + 抽帧放大看左侧栏/表头）→ 是否含真实客户身份信息/内部话术/第三人出镜**。
  - 若敏感内容是**分散在多个视图 + 画面滚动/切页**（图表柱标签昵称 → 明细表客户名 → 关键发现文本块）→ **局部打码必漏**（判据①），
    **整屏像素化虽稳但会让成片失去演示价值（等同弃用）→ 该条不出片、不入队、不发布**；产物留档（`joined.mp4` / `body_1.1x.mp4` 已剪好可直接复用）
    + 落 `_HOLD_合规待拍板.md` + 简报里给**三选一**：**A 整屏打码后照常发 ／ B 给脱敏录屏重出 ／ C 授权原样发（不建议）**，默认继续 HOLD。
  - 若敏感只在**固定区域**（顶栏昵称条 / 单个表头）→ 按上面的 `split+crop+像素化` 打码 → **照常出片发布**（不打码不发、也不停下来等拍板）。
  - ⚠️ **别把它误读成「回到等拍板」**：10-05「打码后直接插入和发布，无论我是否拍板和审核」管的是**能打码**的情形；**打码不可行**才走弃用/HOLD 分支。

### 2B.11 多条成片「分批发」：每个巡检点只发 1 条（2026-10-05 晓君总指令 · MUST）

> 原话：「如果当天有多段视频或剪辑了多条视频，剪辑完成后不一要一次性发出去，**每次只发一条**，
> 其他的**在巡检的时间点分开发**。」

**适用**：任何一天产出 **≥2 条**待发成片 —— 包括①同轮下载多段长素材**各 1 条整片**（§2B.10，⛔ 不再有「一条拆 N 条」）②跨线（微云线 / 内容线）同日各出多条。

| 项 | 口径 |
|---|---|
| **队列文件** | `output/.publish_queue.json`（工具 `scripts/publish_queue.js`，跨轮持久，勿手改） |
| **入队（硬步骤）** | 剪完（含节选/合成/预检就绪）**全部入队**，状态 `ready`；**不入队就发 = 违规**。`node scripts/publish_queue.js enqueue --in <items.json>`（items 支持数组，按 `id` 去重） |
| **入队条目字段** | 最小集 `id` / `line` / `account` / `dir` / `finalVideo`；建议带 `seq` / `slug` / `title` / `coverText` / `sourceFileId`，发布窗口直接从队列取，免二次猜测 |
| 🔴 **执行顺序（硬 · 2026-10-09 补）** | 巡检轮固定时序：**增量检查 → 下载 → 剪辑成片 → 全部入队 → 才跑发布窗口 `next`**。⛔ **不得把 `next` 提前到剪辑/入队之前**。2026-10-09 r76 实测踩到：先跑 `next`（当时队列空）→ 误判「本轮无发布」→ 剪完全部入队后**没再取一次队首** → **漏发 1 条**，且简报误报「本轮无发布」（r77 已补发）。记住：**队列本空时，新剪的一入队就是队首，当轮必须发它**（见下行 2026-10-06 口径）。 |
| **发布窗口（每轮巡检）** | 🔴 **与「有无新增」解耦**：每轮巡检 `node scripts/publish_queue.js next` → 非空就取**队首 1 条**发布（`preflight_check.js` 全 PASS → yxer 三步 → `query details` 验 **`data.tasks[].stageStatus=success`**）→ `mark --id <id> --status published` → **本轮到此为止** |
| 🔴 **剪完当轮即发一条（2026-10-06 晓君总指令）** | 原话：「**剪完就可以立即发一条**」。→ **编辑轮 = 发布轮**：本轮剪完（先全部入队）后，**当轮立即** `next` 取队首 1 条发布，**不留到下一个巡检点**（含「队列原本为空、队首就是本轮新剪的」这种情形 —— 旧口径「只入队、等下一轮」**作废**）。剩余 N-1 条按巡检点 FIFO 依次发。⛔ **上限照旧 1 条/轮**：「剪完发一条」= 一条，**不是**一次发完（同时多条仍违规）。 |
| **每轮上限** | **每线 1 条**（同一条产线不分平台 —— 该条仍要串行发齐它的全部平台）。09:00 / 12:00 / 18:00 三个巡检点 → **每线一天天然上限 3 条** |
| **顺序** | **FIFO**（先入队先发）；`failed` 条目**跳过**、不占窗口（`next` 自动取下一个 `ready`） |
| **多产线隔离** | 队列按 `line` 取号：**微云真人线** 用 `next`；**小红书补发线** 用 `next --line xhs_backfill` —— 两条线各有各的「每轮 1 条」窗口，互不阻塞（同一轮各发 1 条属预期） |
| 🔴 **小红书补发（2026-10-09 起）** | 历史条目补发小红书 → 入队 `line:"xhs_backfill"`（另带 `payloadXhs` / `coverLocal` / `sourceDate`）；该窗口**只发小红书**，preflight 须加 `--allow-republish`（小红书同日多帖是预期；**真防重靠队列 `mark` + 条目级判重**，不靠 G）。细则见 `references/publishing.md §4.1 / §4.2` |
| **队首 FAIL** | 标 `failed`（`--note` 附 `errorMessage`）→ **本轮不再发第二条**（守住「每次一条」）；**不连坐**其他条，下轮继续取下一个 `ready` |
| **新增同轮** | 本轮既有积压又有新剪 → 新剪的**全部入队**，发布窗口仍**只消费 1 条**（队首）；队首即本轮新剪的 → **当轮就发它** |
| **台账** | 发一条记一条（`date` + `account` + `seq`，见 §2B.10）；**不许等 N 条凑齐再一起登** |
| **推送** | 「队列非空 → 本轮发了 1 条」即算**有动作**，按 §C 推简报（写明「已发 1/N，余 N-1 条排后续巡检点」）；队列空且无新增 → 无动作、不推送 |

**命令速查**：

```bash
Q="node scripts/publish_queue.js"
$Q enqueue --in ".staging/pending_items.json"   # 剪完全部入队
$Q next                                          # 取队首（本轮要发的那条；编辑轮也照发）
$Q mark --id "<id>" --status published --note "视频号+抖音 success，taskSetId=…"
$Q mark --id "<id>" --status failed   --note "抖音风控：<errorMessage>"
$Q list / $Q counts                              # 排障与盘点
```

🔴 **`query details` 返回结构坑（2026-10-06 实测踩到）**：结果在 **`data.tasks[]`** 每一项里
（`stageStatus` / `stages` / `publishId` / `id`(task_id) / `platformAccountName` / `openUrl`），
**不是** `data.stageStatus`。按后者取会**全程拿到空串** → 轮询 22 轮全空、把已 success 的帖子误判成「提交后无结果」。
轮询取字段一律走 `data.tasks[0].stageStatus`。另：删除用的 `task_id` = `data.tasks[].id`，与 `taskSetId` 不同（见 §2B.12）。

**⛔ 红线**：
- **不许一轮连发多条** —— 含「今天素材好、一次发完」「一次调度更省事」这类自由发挥；也**不许**绕过队列直接 `publish` 新剪的片子。
- 队列**不许跨天丢弃**：积压要按巡检点依次发完，直到 `next` 为空。
- 队列条目**只增状态、不删文件**；成片与封面目录保持原位（`output/short_video/<日期>_<线>_<slug>-<n>/`）。

### 2B.12 已发布内容的「版本替换」重发（2026-10-05 实战固化 · MUST）

> 触发：晓君总对**已发布成片**给出规格反馈（如 10-05「气口剪太多，听起来紧」）→ 要改规格并**换掉已发的那条**。

| 步骤 | 做法 |
|---|---|
| ① 改规格 | 先改 SKILL + 脚本参数（如 `trim_silence.py` 的 `min-dur/keep-pause`），**规格先落盘再动手重剪** |
| ② 重剪 | **先判反馈类型**：<br>· **只改规格**（气口 / 倍速）→ **从已定剪的语义剪点重跑** `trim_silence.py --speed <新倍速> <新气口参数> --dump-keeps keeps.json`，**不必重做语义剪点**（那步与气口无关）。<br>· **涉及内容**（「废话 / 口误没剪干净」= 要删字）→ 必须重做**逐字定界**：`node scripts/plan_cut_by_words.js --in raw_asr.json --remove remove.json --out-semantic semantic.json --out-segments segments.json --report cut_report.md`，再走 trim（2026-10-15 xjz11 v2→v3 即此类）。<br>⚠️ **改「气口」必须在拼接那一步垫回来**（§2B.6「拼接留气口」= **段尾**垫 `clamp` 气口）—— 硬切的 joined 里段间静音为 0，trim 参数再宽松也没得留。<br>🔴 重剪后字幕必须重映射（时间轴变了，旧字幕作废）：首选 `remap_asr_by_keeps.js`（用 `--dump-keeps` 的 keeps + 拼接 segments + 语义 KEEPS，把原片 ASR **确定性重排**，零成本零等待，2026-10-14 实测与重跑云 ASR 等价）；实在要重跑云 ASR 也行（2 积分/分钟） |
| ③ 重出片+封面 | 字幕重烧。⚠️ **OSS key 一律换新**（`final_..._v2.mp4` / `cover_..._v2.jpg`）——⛔ **绝不复用旧 key**（CDN 缓存 30 天，覆盖上传仍回旧图/旧视频） |
| ④ preflight | G 项判重会报「已发布过」→ 加 **`--allow-republish`**（FAIL 降为 WARN，不阻断）。**理由必须写进汇报与台账**，这是唯一的放行凭据 |
| ⑤ 先发新 | 走标准三步（validate → dry-run 核 accountId → publish）→ `query details` 验 **`stageStatus=success` 且 `errorMessage` 空** —— **只有确认新片成功，才动旧的** |
| ⑥ 再删旧 | `yxer publish delete <task_id> [--dry-run]`。⚠️ **`task_id` = `query details` 返回的 `data.tasks[].id`，不是 `taskSetId`**（用 taskSetId 会删不掉/误伤）；先 `--dry-run` 看 `DELETE /tasks/<id>/publish` 的目标对不对 |
| ⑦ 台账 | 原记录标 **`superseded`**（note 写明「已被 v2 替换：<原因>」）+ **新增 `_v2` 记录**（同一天多条用 `seq` 区分）；微云素材 `weiyun_watch.js mark --status published`（整条素材的节选都发齐才算） |

**⛔ 红线**：① **不许先删后发**（中间空窗、且新片若失败就彻底没了）；② **不许复用旧 OSS key**；③ **删除别用错 id**（taskSetId ≠ task item id）；④ 重剪**只改规格参数，不改一个字**（铁律 1 照旧）。

### 2B.5 真人素材专有坑（编号接 §5）

| # | 坑 | 事实 / 解法 |
|---|---|---|
| 24 | **ASR 的 `words` 拼接 ≠ `utterance.text`** | 实测同一句：`text` 是「节省70以上」、`words` 是「节省70%以上」。**以 `words` 为准**（带时间戳且更准）；`asr_to_ass.js` 会打印差异供人工确认 |
| 25 | **ASR 的 `words` 是单字粒度** | 「发展」「已经」都拆成单字（只有 `AI` / `70%` 是整词）→ **没有词边界可用**，切屏靠「语义等级 → 字间停顿 gap → 常用词保护表」三层兜 |
| 26 | **切屏切进词中间** | 实测「发/展」「百/分之」被拦腰切开。解法：`WORD_GUARD` 常用词表 + 数字/英文内部不拆 + **`gap` 优先**（词内 gap≈0，词间才有停顿） |
| 27 | **切出 2 字碎屏** | `MIN_TAIL=4`：切开后剩余不足 4 字就不切那一点 |
| 28 | **`--fix` 漏应用** | 分屏 push 时若忘了 `applyFix`，成片字幕里品牌名仍是错的（**实测踩过**）。改分屏逻辑后**必须回看字幕文本**，不能只看时间轴 |
| 29 | **阿拉伯数字不算「数字」** | `isNumCh` 若只认中文数字，`70%` 会被从中间切开。判数字要同时认 `0-9` |
| 30 | **剪接处要抽帧验** | 剪掉一段后画面可能跳变（姿势/镜头变化）；抽剪点前后各一帧目视确认 |
| 31 | 🔴 **「手机转向展示」段是隐形雷** —— ASR 与 `silencedetect` **都看不出来** | 他一边转镜头一边还在说话，所以语音是连续的、停顿也不长，看着像正常段落，**画面却已经跑到天花板 / 白板 / 大屏上了**。2026-09-24 实测：语音一路连续到 99.5s，但镜头 **92s 就开始转走** → 只按语音切，会留下 7s 天花板在成片里。**定剪点前必须先抽帧确认「人脸还在不在画面里」**：按秒抽 3-5 张，看人物是否仍在画面中心 |
| 32 | **判"人还在不在"别看抽帧够不够清楚，看构图** | 90-96s 这段帧很清晰、也还是本人（侧脸/近景），但**已经不是"对镜头讲话"的构图**了 —— 这类帧单看"没坏"，剪进去会让成片忽然变成手持乱晃。**标准是构图（是否单人正面中近景），不是清晰度** |
| 33 | **废弃段 = "半句中断 + 长间隔 + 画面转走"三合一** | 判定"该整段剪掉"而非"只剪重复"的信号：① 句子没说完就停（如「可以每天凌晨他有分析的这些数据啊」）② 紧跟 >3s 停顿时长（含高于 -35dB 的环境噪声，`silencedetect` 可能测不到）③ 镜头同时转走。三者同时出现 → 这是**一次废弃的录制**，整段剪；只有 ① 单发时才按"语气词/自然停顿"保留 |
| 34 | **剪完从"转走段"接回"脸"是硬跳切** | 无法避免（空镜段必须剪）。选**剪出点贴着"人脸还没完全出画"的最后一帧**（甩动/近景/侧脸），比直接从"天花板帧"跳回脸自然得多 —— 读起来像一次甩镜剪辑，而不是穿帮 |
| 35 | 🔴 **缓慢转头 = "断续离画"，不是"长空档"** | **只查「连续 N 秒没人脸」抓不到它。** 2026-09-24 实测原片 92.75–96.25s：15 帧里 8 帧无脸（在画率 **47%**），却**没有任何一段连续空档超过 1.5s** —— 因为他转头时脸还会间歇露出来。所以判据必须是**滑动窗口在画率**（4s 窗口 < 60%），不是连续空档长度。`verify_cuts.py` 已内置（本片实测窗口在画率最低 **31%**） |
| 36 | 🔴 **「记得抽帧」不是机制 —— 要验的是整块布，不是只验缝** | 2026-09-24 那条：剪点按逐字时间戳精修、4 个剪接点也**逐个抽帧验过**，全 OK —— 但漏了保留段**内部**的离画：成片 76.5–85.8s 那 4 秒镜头已甩到办公区（人脸被挤到画面最左缘），**发布后才被发现**。教训有两条：① 抽帧只验剪接点 = 只验了「缝」，**没验「布」**；② 靠人记得看 = 迟早漏。已固化为 `verify_cuts.py` 强制闸门（**Step 9.1，FAIL 一律不得发布**） |

### 2B.6 实拍素材「气口 + 倍速」（🔴 2026-10-14 当前口径 = 气口 0.30-0.50s + 1.1x）

> 原话（2026-10-14 23:24）：「**现在感觉气口剪得太多，语句之前太紧了，可以尝试在每句话前留 0.3-0.5 秒，
> 让语句更松弛一点，语速放到 1.1 倍。**」
> 🔴 **本条是当前唯一口径**：倍速 **1.1x**（覆盖 09-29 的 1.2x、09-26 的 1.3x）；
> 气口 = **每句话前留 0.30-0.50s**（覆盖 10-06 的 keep-pause 0.42 窗口口径）。
> 文档下方凡出现 1.2x / 1.3x 的历史实测数据，只作参考，**⛔ 不得据此出片**。
>
> ⭐ **拼接留气口（🔴 2026-10-15 v3 定稿 = 逐字定界 + 段尾气口 · 必做）**
> 硬切拼接 = 段间静音被剃光（2026-10-14 实测 v1 `joined.mp4` 95.95s 里段间静音 = **0**），
> 之后 trim 参数再宽松也**补不回不存在的静音** → 拼接时必须**主动把真实静音留在段尾**。
>
> 🔴 **两条硬规矩（v2 踩坑后定稿，缺一必复发）**：
> ① **逐字定界**：保留区间一律由 **「第 i 字起点 → 第 j 字终点」** 生成（边界落在**字缝**上），**⛔ 不手敲秒数**。
>   2026-10-15 实测 ASR 字级时间戳与真实音频差 **0.05–0.38s**（silencedetect：ASR 说 33.67 收声 / 实测 33.72；ASR 说 61.08 开口 / 实测 61.46）—— 手敲秒数必偏，偏在哪头就剃掉哪头的字（=「正常语气被剪」）。
> ② **气口加在段尾**：`seg.e = 本段末字 end + gap`，**⛔ 不加段首**。
>   v2 把气口垫在**段首**、段尾零余量 → **下一段起点的字尾收音被剃掉**；v3 改锚尾即修好。
>   气口 = `clamp(上一段尾到本段头之间的可用静音 × 0.6, 0.30, 0.50, 可用静音 - 0.10)` 秒。
> 🔴 **SPLIT_GAP = 0.60s**：段内两个保留字之间若出现 ≥0.60s 静音 → **断成两段**（否则长停顿被吞进一段、成片时长异常）。
> ⚠️ 可用静音不够时**别硬垫**（垫出来就是别人的字），有多少留多少，并在简报里说明。
> 只动**段间静音**，段内语音一字不改（铁律 1）。实测 xjz11 v3：**22 段**、气口 **50 个（0.25–0.48s，均值 0.38s）**。
> 🔧 **用 `scripts/plan_cut_by_words.js` 一把生成**（`--in raw_asr.json --remove remove.json --out-semantic / --out-segments / --report`）：
> · `semantic.json` = 语义剪点 `[[起,终],…]`（**不加气口**，= 逐字保留区间）；
> · `segments.json` = `[{"s":起点,"e":含段尾气口的终点},…]`（与实际 concat 顺序一致）。
> 之后换气口 / 倍速重剪，`node scripts/remap_asr_by_keeps.js --in raw_asr.json --keeps keeps.json --segments segments.json --semantic semantic.json --out asr_v2.json` 一步出字幕时间轴。

- **适用范围**：只限**晓君总本人实拍**素材（手机原片、微云下载件、`营销素材/晓君总视频/`）。
  **即梦生成段一律 1.0 不变速** —— 生成段是按定稿文案卡过时长的，提速会顶穿字幕节奏。
- **顺序**：**先**把停顿 / 空白 / 气口 / 重复剪干净，**再**整体提速。两个动作叠着做会让静音判定漂移。
- 🔴 **基准参数（🔴 2026-10-14 三次放宽 · 当前唯一有效口径）**：
  `--speed 1.1 --min-dur 0.30 --gap-min 0.30 --gap-max 0.50 --edge 0.30`。
  ⚠️ **已作废**：09-29 `0.32/0.45/0.18/0.12`；10-05 `0.45/0.65/0.32/0.25`；10-06 `0.55/0.60/0.42/0.30`
  —— 晓君总三次反馈：10-05「气口剪太多，听起来紧」→ 10-06「还是剪得太多了」→
  **10-14「气口剪得太多，语句之前太紧了，每句话前留 0.3-0.5 秒，语速 1.1 倍」**。
  **实测锚点（同一条 xjz11）**：v1 紧口径 **66.14s**（1.2x，段间 0 气口）→ v2 本轮（垫 8.35s 气口 + 1.1x）。
- 命令：

```bash
# 前置：先用 build_join 垫好段间气口（每段起点前留 0.30-0.45s 真实静音）→ joined_v2.mp4
python scripts/trim_silence.py joined_v2.mp4 body_1.1x_v2.mp4 --speed 1.1 \
    --min-dur 0.30 --gap-min 0.30 --gap-max 0.50 --edge 0.30 --dump-keeps keeps_v2.json
```

- **实现**：concat 之后 `[v]setpts=PTS/1.1[vout]` + `[a]atempo=1.1[aout]`。
  `atempo` 是**保音调**变速（真人原声红线）——⛔ 别用 `asetrate` / 改采样率那种写法，声音会变尖。
- 🔴 **`--dump-keeps` 是本轮新增的硬要求**：重剪后字幕必须重映射（§2B.12 ②），
  把实际保留区间写出来，字幕时间轴才能由「原片时间戳 ASR」确定性重映射，不用重跑云 ASR。
- **帧率**：提速后等效帧率变高，脚本按 `源fps × speed` 输出、**不硬压 60**（压帧会顿）。
  **实测（2026-09-26，真实实拍原片）**：20.03s 片段 → 去停顿 2.84s = 17.19s → 1.3x =
  **13.28s / 1080×1920 / 38.94fps / 48kHz 立体声保留**；基频中位数 117.6 → 107.4 Hz
  （差异 8.7%，PASS 音调保持）。校验脚本 `scripts/f0_pitch_check.py`（用法见文件头）可复跑。
- **`--speed ≠ 1.0` 时不走 copy 分支**，一律重编码（copy 改不了时间戳与采样率）。
- 🔴 **时间点全部要 ÷1.1 换算**：字幕时间轴、`segment_materials` 的 overlay 插入点、
  `verify_cuts.py` 的「源时间 ↔ 成片时间」映射 —— 都缩短约 9%。
  **推荐链路：先剪（保留段拼接）→ `--speed 1.2` 出提速片 → 再对提速片做 ASR → 再字幕 / overlay**，
  这样时间戳天然对齐。
  ⚠️ **2026-09-29 实测踩到**：`asr_to_ass.js` **不支持 `--speed`**。ASR 打的是**原片**时间戳，
  而 `--slice` 只解决「拼接映射」、**不解决倍速** → 先 ASR 后提速的话字幕会整体提前约 17%。
  所以顺序必须是「**先提速出片，再对成片 ASR**」（多花约 2 积分，可忽略）。
- **逃生舱**：① 他本身语速快、或某条特别赶 → 仍用 `--speed 1.1`（⛔ 别再往上加，1.2 已被否）；
  ② 技术演示段需要放慢 → 该条 `--speed 0.95`；③ 气口还想更松 → 调大 `--gap-max`（如 0.6），
  但**别再回到「整段删除」的老口径**。
- ⚠️ 本条只适用于**晓君总这条实拍线**；牧子琪等其他账号没有这个默认，别顺手带上。

---

## 3. 交付汇报

只报有用信息：成片路径、封面路径、模型版本、即梦会话、平台账号名、发布 taskSetId。
**不得暴露任何密钥/token**。

## 3.1 内容生产线同步（ima 知识库）

**口径（2026-09-20 晓君总定）**：每周选题计划生成后、每天发布情况，都要**实时同步**到
ima「牧子数智」知识库（`7496968309837278`）的「**内容生产线**」文件夹
（folder_id `folder_7507404040183119`；该文件夹为牧子琪 / 晓君总两条内容线共用，故文件名要带账号）。

⚠️ **只在连接器可用时同步**。该同步依赖 `mcp__ima-mcp__*` 工具，**定时任务会话可能取不到** ——
取不到时：① 产物落盘到 `output/ima同步队列/`；② 简报里写「ima 同步本轮未跑通（连接器工具不可用）」；
③ **严禁写成「ima 无新增」，也不许谎报已同步**。

🔴 **「未跑通」是可以补的，不要就此搁置**（2026-09-23 实测）：定时任务会话取不到工具，但
**同一台机器上的交互会话通常取得到**（连接器是会话级快照）。晓君总白天说一句「授权了 / 补一下」，
即可在原会话里**把落盘的 md 重新生成一遍（字段会带上后续状态变化，如 failed→published）**
再走三步传上去，`duplicate_name_strategy` 用 **`DUPLICATE_NAME_STRATEGY_REPLACE`** 覆盖旧版。
⚠️ **补传前先重跑 `ima_sync_doc.js`**，不要拿凌晨那份直接传 —— 那是发布中途的快照（缺终态）。
✅ 补传成功后**回头把 manifest 的 `imaSync` 由 `not_run` 改为 `success`** 并记下 media_id 与验证结果。

### 三步走（缺一步都不算成功）

```bash
SK=~/.workbuddy/skills/video-pipeline
NODE=C:/Users/admin/.workbuddy/binaries/node/versions/22.22.2-3/node.exe
```

**① 生成文档**（本地确定性转换 —— 别让模型手写这段，字段多必漏）

🔴 **周维度只传一个文件**（2026-09-20 晓君总定）：**周复盘 + 周计划合并成一份「周报」**，
候选池作为附录。一个周次在 ima 里只占一条记录 —— 翻一个文件就能看完整周
（复盘看上周做得怎么样、计划看这周要做什么，本来就是一前一后同一件事）。
别再拆成「周复盘」「周计划」两个文件分别传。

```bash
# 周报（每周日 09:00 产完后）—— 复盘 + 计划 + 候选池附录，合并为一份
"$NODE" "$SK/scripts/ima_sync_doc.js" weekly \
  --review "D:/牧子数智/内容计划/短视频周复盘-<今天>.md" \
  --plan   "D:/牧子数智/内容计划/短视频周计划-<周一>.json" \
  --pool   "D:/牧子数智/内容计划/短视频选题候选池-<周一>.md" \
  -o "D:/牧子数智/output/ima同步队列/晓君总_短视频周报-<今天>.md"
# 合并规则：复盘正文原样保留、标题降一级；计划由 JSON 渲染；候选池进「附录」。
# 复盘/计划缺失 → 该部分留空提示、不报错；候选池缺失 → 跳过并打提示。

# 发布日报（每日 05:00 发布完；--note 可重复，追加到备注区）—— 日维度仍单篇
"$NODE" "$SK/scripts/ima_sync_doc.js" daily --date <YYYY-MM-DD> --root "D:/牧子数智" \
  --note "视频号授权失效已跳过" -o "D:/牧子数智/output/ima同步队列/晓君总_发布日报_<日期>.md"
```

**② create_media → 上传 COS**

```
MCP mcp__ima-mcp__create_media
  { knowledge_base_id:"7496968309837278", file_name:"晓君总_短视频周报-<今天>.md",
    file_ext:"md",                       ← 不带点！带点报 code:51
    file_size:<实际字节数，必须一致>, content_type:"text/markdown" }
```

⚠️ **ima MCP 没有删除接口** —— 名字传错只能人工到 ima 客户端里删。上传前先核对文件名与字节数。

把返回整包存成临时 json（`output/ima同步队列/_cos_cred.json`，用完即删、绝不回显密钥），然后：

```bash
"$NODE" "$SK/scripts/ima_upload_cos.js" "<① 产出的 md>" "output/ima同步队列/_cos_cred.json"
# 成功打印 OK <etag> <bytes>
```

**③ add_knowledge 入库 + 验证**

```
MCP mcp__ima-mcp__add_knowledge
  { knowledge_base_id:"7496968309837278", folder_id:"folder_7507404040183119",
    media_id:"<create_media 返回的 media_id>",
    duplicate_name_strategy:"DUPLICATE_NAME_STRATEGY_REPLACE" }
```

验证：`get_knowledge_list { knowledge_base_id, folder_id:"folder_7507404040183119", limit:20,
sort_type:"UPDATE_TS_DESC_SORT_TYPE" }` 能看到该标题且 `parse_progress=100` 才算成功。

### 本环节的坑

| 坑 | 表现 | 解法 |
|---|---|---|
| `file_ext` 带了点 | `code:51 invalid CreateMediaReq.FileExt: value does not match regex` | 传 `md`，不是 `.md` |
| `file_size` 与文件不符 | 服务端据 size 校验，超限/不符直接拒 | 用实际字节数（`ima_sync_doc.js -o` 会打印 byte 数） |
| 文件名不带账号 | 与牧子琪同目录文档混淆，分不清归属 | 统一 `晓君总_<类型>_<日期>.md` |
| 连接器工具取不到 | 定时任务会话里 `mcp__ima-mcp__*` 不存在 | 见上文口径：落盘 + 如实上报，不倒推、不谎报 |

## 4. 新增账号

1. 复制 `profiles/_template.md` → `profiles/<新账号>.md`：填人物外观、路径、样式、发布账号
2. 复制 `profiles/_template.json` → `profiles/<新账号>.json`：填路径与生成参数
3. 在本文件 `## 0` 的 profile 列表加一行
4. **跑 `setup_check.js --profile <新账号>`，必须 0 FAIL 再动手**
5. 用一段真实文案跑一遍 Step 2-9 验证

**填 paths 的三条硬规矩**（2026-09-16 建 xiaojunzong profile 时踩出来的）：

- **不要留空**。模板注释说「留空则跳过存在性检查」—— 那是给「素材在别的机器」的临时状态用的。
  留空 = 每天跑起来才发现身份图不存在，前面白干。
- **`identityImage` 必须是文件、`sceneDir` 必须是含 ≥1 张图的目录**（自检会判 kind）。
  手上只有视频时，先抽帧：`scripts/setup_xiaojunzong_assets.py` 就是现成范例（幂等，可复跑）。
- **写完必须与本项目 `video-copywriter/profiles/<同名>.json` 对齐**（session / defaults / publishAccounts）。
  两个 skill 各存一份 profile，**只改一边就会「两份真相」**。

> 参考实现：`profiles/xiaojunzong.{md,json}`（本机生产机版，22 项 PASS）。

## 5. 本机已知坑（2026-09-03 生产实踩，写脚本前先读）

| # | 坑 | 表现 | 解法 |
|---|---|---|---|
| 1 | **dreamina 是 Windows 程序，不认 git-bash 路径** | `--image "/g/牧子琪/..."` → 任务 `fail`，`fail_reason: read file /g/...: The system cannot find the path specified` | 传给 dreamina 的路径一律用 **`<盘符>:/...`** 形式（盘符大写 + 正斜杠），如 `G:/牧子琪/...`、`D:/牧子数智/营销素材/...`；**不要用 `$(pwd)` 的 `/g/...`、`/d/...`** |
| 2 | **dreamina 终态枚举值** | 成功 `success`；失败是 **`fail`** 不是 `failed` | 轮询脚本两个都要判，只写 `failed` 会永远转不出来 |
| 3 | **失败原因字段** | 不在 `result_json` 里 | 读 `fail_reason`（字符串，含具体路径/原因） |
| 4 | **`query_result` 不加 `--download_dir` 不落盘** | 状态 success 但目录里没有 mp4 | 下载必须显式带 `--download_dir`，落盘文件名是 `<submit_id>_video_1.mp4`，需自己重命名为 `partN.mp4` |
| 5 | **node.exe 版本目录会被轮换** | 硬写 `versions/22.22.2/node.exe` → `No such file or directory`，轮询脚本静默空转几十分钟 | 脚本里动态探测：`command -v node` 或 glob `versions/*/node.exe` 取第一个存在且可执行的 |
| 6 | **node 解析不了 git-bash 绝对路径** | `require('/g/牧子琪/...json')` 抛 MODULE_NOT_FOUND | 脚本内先 `cd` 到目标目录，再用 `./xxx.json` 相对路径 |
| 7 | **后台轮询被 TaskStop 后子进程不死** | 新旧两个 poller 同时写同一个 `tmp_*.json` / `poll_*.log`，状态互相覆盖、读到截断 JSON | 用 PowerShell `Get-CimInstance Win32_Process -Filter "Name='bash.exe'"` 找到命令行含脚本名的进程，`Stop-Process -Id <pid> -Force` |
| 8 | **Pillow 不在托管 python 里** | `make_cover.py` 报 `No module named 'PIL'` | 装进隔离 venv：`<家目录>/.workbuddy/binaries/python/envs/default/Scripts/pip.exe install Pillow`，之后用该 venv 的 python 跑封面脚本（`VP_PYTHON` 可指定）|
| 9 | **`mosaic_face.py` 依赖 cv2，本机 cv2 不可用** | `ModuleNotFoundError: No module named 'cv2'` | 直接用 ffmpeg 固定区域法打码（见 Step 4 的 `mosaic.sh`），不要试图装 cv2 |
| 10 | **桌面俯拍机位脸位偏下** | 默认码区（高 4%~38%）可能盖不住五官 | 俯拍/俯身机位把码区下沿扩到高 45%（720×1280 → `crop=346:524:188:52`） |
| 11 | **ASS `Fontname` 与字体注册名不一致 → 静默回退**（2026-09-16 实测重写） | 字幕照样出、**不报错**，只是字体不对（回退到 Arial / 微软雅黑）。实测 `Smiley Sans` → `Arial-BoldMT`；`Alibaba PuHuiTi` → `Arial-BoldMT`；**连 `Alibaba PuHuiTi 3.0`（去掉 105 Heavy）也照样回退** | ① **`Fontname` 必须写完整注册名**：得意黑 = `Smiley Sans Oblique`、普惠体 = `Alibaba PuHuiTi 3.0 105 Heavy`。② 烧字幕命令必须带 `:fontsdir='<VP_FONTS_DIR 转义形式>'`。③ 完整对照表见 `setup-checklist.md` 第 3.1 节 |
| 12 | **ffmpeg 不在 PATH（或构建不含 libass）** | 到 Step 4 抽帧 / Step 8 烧字幕才炸，前面生成全白跑；不含 libass 时报 `No such filter: 'ass'` | 用 BtbN `gpl`/`gpl-shared` 构建（**LGPL 版不带 libass**）；`VP_FFMPEG` 可指定绝对路径。自检脚本已覆盖 ffmpeg/ffprobe/libass 三项 |
| 13 | **Windows 上 `fonts.conf` / `FONTCONFIG_FILE` 对 libass 完全无效** | 配了 `<dir>`、加了 `<edit name="family">` 别名，5 款字体**仍全部回退微软雅黑**（相似度一模一样，肉眼看不出来） | 根因：Windows ffmpeg 的 libass 走 **DirectWrite** 提供者（启动日志 `Using font provider directwrite (with GDI)`）。**别再往 fonts.conf 里加东西**，改用 `:fontsdir=` + 精确 `Fontname`（见坑 11） |
| 14 | **即梦登录设备码 ~10 分钟过期，且 `checklogin` 不是长轮询** | `dreamina login checklogin --poll=5` 约 **40 秒**就返回「等待登录超时，请重试」；后台常驻 `dreamina login` 的 stdout 被缓冲，**读不到授权码** | 用 `scripts/dreamina_login.js` 走两段式：`code`（取码+暂存）→ 给人 → 等授权完 → `done`。手工等价：`login --headless` → 给人 → 再 `checklogin --device_code=<码>`。`~/.dreamina_cli/logs/` 不含授权码 |
| 15 | **即梦生成视频自带音轨，但那不是本人的声音**（2026-09-16 实测，推翻旧结论「无音轨纯视觉通道」） | 实测与参考音轨归一化互相关仅 **0.050~0.123**，且非静音（RMS 0.081~0.095）→ 模型另合成了一段语音 | ⚠️ **2026-09-16 晓君总改口径，仅对 `xiaojunzong` 生效**：**直接使用生成音轨 —— 不替换、不验证音轨来源、送审不标注**；原「一律丢弃生成音轨、用本人录音替换」的规则【作废】（见 profile `audio._policy20260916`）。**其它账号改前先问。** 仍禁止音色克隆与预置音色。复现工具：`scripts/probe_generated_audio.py` |
| 16 | **OpenCV 不认中文路径**（`cv2.imread` 与 **ONNX 模型加载**都中招） | ① `cv2.imread` 读含中文的文件 → `can't open/read file`（静默返回 None）；② `FaceDetectorYN.create("D:\牧子数智\models\*.onnx")` → `Can't read ONNX file` / `Failed to parse ONNX model`。**两种报错长得很像，容易误判成模型损坏** | ① 抽帧临时文件名用**纯 ASCII**（`ref_1.0.png`，别用视频原名）；② 人脸模型放到纯 ASCII 目录（默认 `C:\\Users\\admin\\.workbuddy\\models`，可用 `VP_FACE_MODELS` 覆盖）。③ 模型下载**必须核对字节数**（SFace 官方 38,696,353；被截断成 18MB 时也报 `Failed to parse`） |
| 17 | **cv2 5.x 移除了 `CascadeClassifier`** | `module 'cv2' has no attribute 'CascadeClassifier'` | 锁 **opencv-python-headless<5**（实测 4.14.0 同时有 Haar + `FaceDetectorYN` + `FaceRecognizerSF`）。`mosaic_face.py` 只用 resize/imread，不受影响 |
| 18 | **`concat` 滤镜漏写音频输出标签** | `Output with label 'a' does not exist in any defined filter graph`，**直接不出文件**（不是静默丢音，是报错中断） | 必须 `concat=n=3:v=1:a=1[v][a]` —— **两个标签都要写**；只写 `[v]` 就会踩到。完整命令见 Step 8 |
| 19 | **`face_similarity.py --gen` 必须 `标签=路径`** | 只给裸路径 → 每一项被 `continue` 静默跳过 → 打完全程只输出天花板一行，**`exit 1` 且无任何提示**，极易误判成模型/视频坏了 | 已修（2026-09-16）：裸路径自动取文件名当标签，且无有效输入时打印 `ERR 没有任何可评测的 --gen 视频`。**看到「只有天花板一行 + 无分段结果」就是这个坑** |
| 20 | **企微 `aibot send` 返回 exit 0 ≠ 发送成功** | 服务端偶发 `-202 server inner http request failed, hint: [<traceid>]`，进程仍返回 0；`notify_review.sh` 旧版只看 exit code → **成片没发出去但报「已发」** | **一律看返回 JSON 的 `success` 字段**。已修：`send_media()` 校验 `success===true`，失败自动重试 1 次（实测重试即成功）。手工重发可用 `media_id` 复用，不必重传 |
| 21 | **别用「哪个 mp4 文件新」判断哪轮生成** | part2/part3 会反复重生成，文件名不变、只有 mtime 变；凭 mtime 会把「上一轮」当成「这一轮」，白等或白跑 | 提交时间从 **`~/.dreamina_cli/logs/dreamina.log.<日期>_<小时>`** 反查：`grep "MultiModal2Video\] request summary"` 能看到每次提交的 `submit_id` + `image_count/video_count`。`tasks.db` 主库只有 40KB，真实数据在 `tasks.db-wal`，别只看 `.db` |
| 22 | **`yxer publish` 返回 `ok:true` ≠ 内容已发出**（2026-09-16 实测） | 云发布是**异步**的：`publish` 只返回 `taskSetId`（「任务已提交」）。若拿 `ok:true` 就当发布成功去汇报，可能出现「说发了其实没发」——和坑 20 的企微 `exit 0` 是同一类陷阱 | 发布后**必须**用 `yxer query details <taskSetId> --json` 复核，逐 task 确认 `stageStatus=success` **且 `errorMessage` 为空**，才算发布成功。`stageStatus` 其它值/有 errorMessage → 按失败处理并汇报 |
| 23 | **台账 `--record` 的 `platformAccountId` 漏填** | 判重粒度是「平台 + platformAccountId」；漏填会退化成平台级通配，**误锁同平台其他号**（矩阵号发不出去） | 每条 platform 记录**必须**同时带 `platform` + `platformAccountId` + `taskSetId` + `status`。发布成功后立刻登记，别等下一跑 |
| 24 | **`dreamina multimodal2video --poll N` 提交成功后仍 exit 1**（2026-09-21 实测） | 输出只有一行 `get_history_by_ids failed: ret=1015, msg=`，**exit=1、stdout 为空**，看起来像提交失败；实际任务**已提交并在跑**（`~/.dreamina_cli/logs/dreamina.log.<日期>_<小时>` 里能看到 `[SubmitTask] submit generation task finished … task_status=querying`）→ 自动化会误判失败并**重复提交** | **`--poll` 一律写 0**：命令立刻返回干净 JSON（`submit_id`/`gen_status`/`credit_count`），自己写轮询脚本查 `query_result`。**判成败看 `gen_status`，不要看 exit code** |
| 25 | **`preflight_check.js` 的判重台账路径跟 cwd 走**（2026-09-21 实测） | `LEDGER` 默认 = `path.join(process.cwd(),'output','published_log.json')`。生产脚本在 `output/short_video/<日期_场景>/` 里跑 → 指向一个**不存在**的 ledger → G 项「重复发布」永远报「未发布过」，**判重形同虚设** | 从生产目录跑时**必须显式** `--ledger "D:/牧子数智/output/published_log.json"`（跑质检和 `--record` 两处都要带）。⚠️ 报「未发布过」不等于真没发过，先确认 ledger 路径对不对 |
| 26 | **换号只改 payload = 留一地雷**（2026-09-21 视频号换号实测） | 账号名/id 散落在 profile、SKILL.md、prose 引用、**打包源 `.staging/`**、**周复盘拉数脚本**里。只改 payload 的话：下周复盘照旧拉老号（数据全空）、下次打包上 ima 又推老号回去 | 换号必须按**固定清单**扫一遍（`references/publishing.md` →「换号清单」），收尾用 `grep -rn "<老号名>\|<老号id>"` 复核，只剩历史日志/快照才算干净 |
| 27 | **抖音描述硬上限 30 字**（2026-09-23 首次被 preflight D 项拦下） | 惯用写法「封面两行标题拼起来 + '，' + 完整钩子话术」很容易顶到 32 字（例：`员工在微信里到底怎么谈客户，评论区打111，我把解决方案发给你。`=32）→ `preflight_check.js` 直接 FAIL，阻断发布 | 🔴 **压的是标题、不是钩子**（钩子要和视频里说的一致，不能砍）。`build_payload.js` 里写成三级口径：① 全标题+钩子 ≤30 就直接用；② 超了退到 **`cover_title[0]` + 钩子**（首行一般 ≤11 字，必然合规）；③ 还超就 `process.exit(4)` 报错中止，**不静默截断**。实测今天 32 → 25 字通过 |
| 28 | **企微 `aibot send` 的 `msg_type` 没有 `text`**（2026-09-23 实测） | 想当然传 `--json '{"chat_id":"…","msg_type":"text","text":{"content":"…"}}'` → CLI 只回一大段 usage（`--help`/`--dry-run`/`-o`），**exit=0 但没发出去**，`success` 字段根本没有 | 正确 shape：`--chat-id <id> --msg-type markdown --markdown '{"content":"<markdown 正文>"}'`（或 `--json` 传 `{chat_id, msg_type:"markdown", markdown:{content}}`）。**合法枚举只有 `markdown` / `image` / `file` / `voice` / `video`**；用 `--schema` 查准再发。⚠️ 拿不准就用 `notify_review.sh`，它已封装好 |
| 29 | **本机 ffmpeg 不支持 `-filter_complex_script`**（2026-09-23 实测，N-126574-g912208af28） | `Unrecognized option 'filter_complex_script'` + `Error splitting the argument list: Option not found` → 整个合成不出文件 | 滤镜串**直接内联**给 `-filter_complex`。含中文路径/冒号的参数（如 `ass=…:fontsdir='C\:/…'`）在 bash 里用**单引号拼接**（`FC='…'\''…'\''…'`）保留字面反斜杠，别走外部文件 |
| 30 | 🔴 **`fontsdir` 的转义按「谁传参」分两种写法，写错就 `No option name near '/Users/…'`**（2026-09-24 踩） | **spawnSync/execFile（无 shell，参数直传）时**：JS 里写 `const FONTS = "C\:/Users/…"` —— **双引号会把 `\:` 吃成 `:`**，滤镜串变成 `fontsdir='C:/Users/…'` → ffmpeg 把冒号当选项分隔符 → `No option name near '/Users/admin/…'` + `Error parsing a filter description around: [vs]`，**exit≠0 且不成片**。⚠️ 反过来写成 `'C\\:/…'`（字面双反斜杠）也报错（`No option name near '\:/Users/…'`） | **JS 源码里必须写单引号 + 双反斜杠**：`const FONTS = 'C\\:/Users/admin/.workbuddy/fonts';`（→ 字面 `C\:/…`），再拼 `:fontsdir='…'`（单引号包裹）。已实测：`-filter_complex "[0:v]ass=x.ass:fontsdir='C\:/Users/…/fonts'[vs]"` 解析通过。**改完必须抽一帧肉眼看字体**（解析通过 ≠ 字体加载成功）。⚠️ bash 直跑 ffmpeg 时相反：`fontsdir='C\:/…'` 交给 shell 时用**单引号包住整串**即可，别再加一层转义 |
| 31 | 🔴 **dialogue（双人）两处工程细节**（2026-09-24 首次实战固化） | ① **part2+ 只挂 `--image part1_mosaic_ref.jpg` 会丢搭档身份** —— 打码帧上两张脸都被码住，模型只能凭空编，搭档脸逐段漂移；② ④段档文案单段写到 110~113 字时，**15s 装不下**（实测约 7.3 字/秒；🔴 **2026-10-23 起安全区已下调为 101 字**），末尾会被挤/吃 | ① part2+ 的 `--image` **挂两张、顺序固定**：`--image <搭档形象图>`（第 1 张）+ `--image <part1_mosaic_ref.jpg>`（第 2 张），prompt 里写明「第 1 张是搭档人物形象，第 2 张是场景/服装/机位的唯一依据」；② `_setup.js` 里加单段字数闸门（>101 字 WARN / >105 字 ERROR，2026-10-23 由 109/115 下调），`dialogue_lines` 的搭档台词**只在并入后仍 ≤101 字时才并进正文**（本条并入后 113 字 → 放弃并入，她的戏留在 seg2） |
| 38 | 🔴 **段间一致 ≠ 全周一套：`productionDefaults` 被当成「全周共用场景」→ 连着几天同一书房同一件衣服**（2026-09-25 晓君总提问） | 为了段间一致性，周计划把 `scene`/`outfit_action` 提到 `productionDefaults` 顶层，7 条全回落同一套 —— 09-21 那周连着 5 天「办公室书房 + 深色 Polo」。但规范里明文要求轮换（`晓君总短视频文案与视频生产规范.md` **§23「场景同周 7 天尽量轮换不重复」** + `brand-rules.md` 季节匹配），只是没落校验所以没人执行 | ① 口径：**一条之内 4 段必须一致，一条之间必须轮换** —— 一致性靠 part2+ 传 `part1_mosaic_ref.jpg`，与换条换景不冲突；② 出周计划时按 `video-copywriter/references/scene-rotation-xiaojunzong.md` 给**条目级** `scene`/`outfit_action`（6 套场景池 + 季节档 + 相邻不重 + 场景要和内容对得上），`productionDefaults` **只当最后回落**；③ 已落校验 `validate_plan.js` **R 场景轮换**（同周去重场景 `< min(4,条数)` / 相邻同景同装 / 条目级覆盖 `> 50%` → WARN） |
| 37 | 🔴 **视频号 `description` 放全文 → 口播稿里任何禁词都会顶掉 E 项，且报错不指位置**（2026-09-25 首次被拦） | 视频号 payload 的 `description` 惯例是 `segments` 全文，而 preflight **E 项扫的是 `title + description`**（`BANNED_WORDS`：价格 / 百分比 / 效果数字 / `全国第一\|行业第一\|最好\|最强\|唯一指定\|100%`）。于是同一份稿子：**抖音**（描述仅 24 字）E 过、**视频号**（描述 426 字全文）FAIL —— 报错只写「命中禁词：绝对化用语」，**不给位置**。2026-09-25 seq5 就是 seg2「做得最好的那个人」+ seg3「做得最好的那套跟进方式」两处「最好」被拦，整条视频做完却发不出去 | ① **定位**：别猜，拿 `BANNED_WORDS` 的正则逐段 `match` 打印命中位置；② **处置口径**：`FAIL 即中止、不发布、不降级` —— **不做半量发布**（不发单独一个平台）；③ 修法按代价排序：**(a) 改词 + 重生成受影响段**（合规最稳，132 积分/段、mini 实测 ≈4 分钟/段）；**(b) 改描述口径**（描述不再放全文、改「标题+钩子」，0 积分，但要晓君总点头）→ 🔴 **2026-09-25 晓君总已点头采纳 (b)**：**视频号 `description` 现行口径 = 「标题 + 钩子 + tagline」，不再放 `segments` 全文**（首落 = 2026-09-25 seq5 补发，E 项由 FAIL 转 PASS、preflight 23/0/0 后发出）。**新条目一律按此口径出 payload**；`build_payload.js` 里的视频号 DESC 改成标题+钩子+tagline 拼接（抖音维持 ≤30 字三级口径，见坑位 27）；**(c) 收窄禁词表**（仅当该词确非产品绝对化用语时，必须本人拍板）。④ **写文案阶段就先扫禁词**，别等做完 4 段才被质检拦；⑤ 中止轮次台账写 `status: "failed"`（`isPublished` 只排除 skipped/failed/error，写 `held` 会把当天判重锁死，之后无法补发） |
| 40 | 🔴 **CTA 前向修正脚本：当今日条目是「当周最后一条」时，用「首个匹配 / 整段缩进锚点」定位 `cta` 会失败或改错条**（2026-09-27 踩到） | 修 CTA 的惯用做法是「拿旧 `cta` 字符串替换」，但同周**已发布条目里存在同款字符串**（seq2/seq3/seq7 都曾是 `"cta": "评论区打111，我把解决方案发给你。"`）。当今日条目是**最后一条**时，所有旧串**全排在它前面** → 「首个匹配」会改到已发布的 seq2；而用「带缩进的整段锚点」又常因该文件是 `\n` 而脚本按 `\r\n` 拼、或缩进层数不一致 → **锚点匹配数 = 0，静默不写**（实测 2 次失败）。⚠️ 同日第二次受阻（连续轮次）也要一起记 | ① **改用定位式改写，不做整段字符串替换**：先用**不含空白**的末段正文片段作**唯一锚点**（`split(...).length-1 === 1` 断言）拿到位置 → 再从该位置**之后** `indexOf` 找 `cta` 行 → 插入 `ctaKeyword`/`_ctaUpgrade`（缩进取该行实际前缀）；② **加前后置断言**：`seg4 之前同款 cta 数 == 已发布条目数`、`之后 == 0`，不满足即 `exit 2` 不写盘；③ 写盘前先 `JSON.parse` 复验 + 断言「最长段 ≤115」且「总字数仍在档位区间」，任一不满足**不写盘**；④ 备份源必须用**当日最新**的周计划（`cp 周计划 周计划.bak-<YYYYMMDD>` 后再读，别拿上一轮的 `.bak` 当源，会丢中间修正）。可复用实现见 `output/short_video/2026-09-27_加了几千个客户到底谁在跟/_fix_plan_cta.js`；⑤ **连续多轮受阻（积分/通道）时**：`manifest.json` 要记 `backlog[]`（每条：date/seq/title/need/dir）+ `totalNeedAfterRecharge`，简报里**写明「连续 N 天」和「累计待跑积分」**，别只报今天这一条 |
| 39 | 🔴 **即梦积分是「全产线共用池」，用完只回 `ret=1006 CreditPreDeductNotEnough` —— 等到提交才发现，白等一轮**（2026-09-26 首次撞到 → 当天停更） | 09-25 当天消耗 **792** 积分（常规轮次 4 段 528 + **临时新增 2 段 264**），余额 387 → **123**；09-26 早间刚提交 part1 就 `gen_status=fail / api error: ret=1006, message=CreditPreDeductNotEnough` —— **连一段都生成不了**（单段 132），4 段需 528。⚠️ CLI 里两个 session（晓君总 10559080744972 / 牧子琪 10593619372812）**共用同一账号积分**，不是各自独立额度；`dreamina user_credit` 看的是账号级余额 | **① Step 3 前置 0 加「积分预检」**：`dreamina user_credit` → 对比 `段数 × 132`，**不足就立即停止并报告**（依据 `references/prompt-templates.md:220`「余额不足 → 停止并报告」），**不要先提交再看报错**。**② 不要擅自换通道（2026-09-29 起 LibTV 备用通道属例外，口径见「前置 0」；apiz 仍不换）**：apiz 的 `doubao-seedance-2-0-fast-260128`（Seedance 2.0 Fast）虽声明支持视频参考，但**本机没有端到端 runbook**，其 `apiz generate` 只暴露单张 `--image-url`（参考视频要走未文档化的 `content[]` 多模态）；换用等于把「本人**参考视频**」改成「单图兜底」口径 —— **须晓君总点头**，无人值守轮次一律不换。**③ 当天第二条（临时新增）= 积分翻倍的主因**，一天两发前先算总账。**④ 中止轮次**：写 `manifest.json`（`status: "blocked"` + 缺口数值 + 续跑说明）+ 台账 `status:"failed"`（照坑 37 第⑤条），**已就绪的 prompt/脚本原样留着**，充值后从「提交 part1」直接续跑 |
| 41 | 🔴 **素材 overlay 插入点的关键词「写死在脚本里」→ 换条目后静默失效**（2026-09-28 修）：`_trim_and_burn.js` 曾写成 `const kw = m.segment===2 ? '卡在哪一步' : (m.segment===3 ? '后台自动汇总' : null)` —— 这是某一天的台词原文，**下一次换条目就匹配不到、素材静默不插**（不报错，只在日志里一行 SKIP，极易漏看）。⚠️ 复发面很广：任何「按日期复制上一轮脚本」的做法都会把这个写死值一路带下去 | **改成通用做法**：从条目 `note` 里的「…」**引号短语**出发，在**该段自己的字幕行**（用 probe 段时长切分段区间）里做**最长公共子串（LCS）模糊匹配** → `score ≥ 4` 采用该行起点，`< 4` **回落该段首行**（仍取自 `subtitles.ass` 的 Dialogue 行，**不是按字数估算**），并把 `matchedBy` 写进 `_overlay.json` 便于复核。实测 2026-09-28 两条素材 score 均 = 5、命中语义位置 → **换条目零改动**。🔴 推论：**凡是「按日期复制上一轮脚本」的脚本，都要先扫一遍有没有上一条的台词/标题/文件名残留**（同轮还发现成片名残留了上上轮的 `不写稿不出镜…`） |
| 42 | 🔴 **`yxer query details <taskSetId> --json` 的 JSON 里冒号后有空格**（`"stageStatus": "success"`）→ 用 `/"stageStatus":"[^"]*"/` 解析**全部返回空**，脚本据此误判「还没到终态」**空转满 15 轮 / 近 4 分钟才退出**，看起来像「发布一直没完成」 | 解析正则一律写 **`'"' + k + '"\\s*:\\s*"[^"]*"'`**（允许空白）。⚠️ 与 09-25 那次「字段被转义在字符串里」是**两个不同的坑**，两个都要防：先 `JSON.stringify` 去转义、再用带 `\s*` 的正则。已修进 `_qdetails.js` |
| 43 | 🔴 **`accounts list <平台>` 里的 `status` 可直接判死**：本轮（2026-09-28）视频号读到 **`status=2`（授权已失效）**，而之前 4 天都是 `status=1` 假正常、**必须真发一次才知道坏** —— 两者处置完全不同 | **读到 `status=2` 就别提交**：直接按「跳过该平台 + 登记 `待重扫授权清单.md`」走，**不发 validate / 不发 publish**，省一次无效任务（本轮因此比历史少烧一次提交）。⚠️ 与坑 26/§publishing「status=1 不等于能发」并不矛盾：`status=2` 是**可判死**，`status=1` 是**仍需实测**。🔴 另注：本轮视频号 **4 个号全部 status=2** → 指向**分组级登录态整体过期**，简报要写「疑似分组级失效、需整组重扫」，别只报单号 |
| 44 | 🔴 **企微 `aibot send` 返回 `errcode 850003`（机器人「消息」权限过期）时，接口硬性要求把 `help_message` 逐字展示给用户 —— 而脚本里常见的「打印前 N 字符」截断会正好把它切掉**（2026-09-29 踩到：`_brief_0928sph.js` 的 `.slice(0,800)` 把授权链接截没了，只能重查一次） | ① **判死只看 `message aibot sessions list` 的 `errcode`**：`850003` = 真发不了（`send` 会返回同码 + `success` 缺失；`exit 0` 仍不代表成功）；② 命中 850003 后**用只读的 `sessions list` 重取完整 JSON**（别拿 `send` 重试，会白发一次），解析后**把 `help_message` 原文一字不改地贴给用户**——含其中的 markdown 链接与完整 URL，`\n` 还原成换行。这是返回体 `help_instruction` 的硬要求，**不许改写/省略/翻译**；③ 🔴 **写简报脚本时禁止对 CLI 返回做小 `slice`**：要么原样落盘再用 JSON 解析取字段，要么至少 `slice(0, 20000)`；④ 推送失败时**简报正文必须落盘**到 `<生产目录>/简报_<日期>.md`，并在回复里写明「企微未推送 + 原文已落盘」，别把 850003 当成「简报送出去了」 |
| 45 | 🔴 **`dreamina user_credit` 会瞬时 `authsdk refresh failed: protocol transport: do request`、stdout 无任何 JSON**（2026-09-30 首次调用即中，耗时近 3 分钟才退出 1）→ 按「前置 0 积分预检」的字面逻辑会被误判成「**生成通道不可用 → 中止停更**」，白停一天 | **判据：只要没拿到明确 JSON（`total_credit` 字段），就原样重试一次**；重试即通（本轮 169 正常返回）。同坑 26 的「即梦 `ret=10002 resource store failed: login fail` 原样重提即成功」是同一类**鉴权抖动**——**先重试再判死**，不要改 prompt、不要换模型、不要写「待重扫」。⚠️ 反过来说：**重试后仍是余额数字但不足**，那才是真中止（照坑 39 走 blocked 收口） |
| 46 | 🔴 **`validate_plan.js` 不在 `video-pipeline/scripts/`，而在 `video-copywriter/scripts/`** —— 自动化 prompt / 简报里常只写脚本名不带路径，按 video-pipeline 目录下找会 `MODULE_NOT_FOUND`（2026-09-30 踩到） | 正确调用：`<NODE> C:/Users/admin/.workbuddy/skills/video-copywriter/scripts/validate_plan.js <周计划绝对路径> --profile xiaojunzong`。⚠️ 归属关系别记反：**校验计划 → video-copywriter**，**生产/发布/质检 → video-pipeline**（`preflight_check.js` 等在 pipeline 侧） |
| 47 | 🔴 **蚁小二 CLI（v3.2.17）读不了「中文文件名」的 payload** —— `yxer validate 抖音 video payload_抖音.json` 直接报 **`publish requires a payload.json file`**（+ `hint: 发布命令已移除内容 flags 模式`），**提示完全误导**，看着像命令语法错/文件不存在，其实文件就在 cwd、内容也合法（2026-10-05 首次踩到，卡住发布链路） | **换 ASCII 文件名即刻通过**：同一份内容 `cp` 成 `payload_douyin.json` → `validate` 立刻 `valid: true`。✅ **做法**：`build_payload.js` 落盘时**同时**写一份 ASCII 名（如 `payload_douyin.json` / `payload_sph.json`），**发布三步一律用 ASCII 那份**；中文名的只留作人读。⚠️ 只在 `payload.json` 位置参数上踩到，`--json` 等其他路径未发现问题 |
| 48 | 🔴 **`weiyun.list` 只看顶级 `file_list` 会漏掉「新增子目录」里的素材** —— 顶级 `file_list` 逐字段没变、`weiyun_watch.js diff` 报 0 新增，但 `total_dir_count` 已由 0→1（2026-10-05 踩到：漏掉整个「国庆视频及素材」目录的 5 条素材，靠计数器才发现） | **判微云增量必须同时看 `dir_list` / `total_dir_count`**：有新目录就**再调一次 `weiyun.list` 进去拉**（`dir_key` 用返回的 `dir_key`），把**两处目录的 `file_list` 合并**成 `.staging/weiyun_items.json`（子目录条目的 `dir_path` 写真实子路径）再跑 `diff`。⚠️ `weiyun.download` 取子目录文件的链接时 `pdir_key` 要用**子目录 key**，不是顶级 key |
| 49 | 🔴 **多段 B-roll 分批插时，后插的 B-roll 会把「已烧字幕」整段盖掉** —— `compose_broll.js` 的字幕是**每次调用末尾统一烧**（`[vout]ass=SUBS[vsub]`）。若第 1 次传真字幕、第 2 次传 `empty.ass`（想避免重影），第 2 次的 B-roll 全屏覆盖会把第 1 次烧的字幕**一起盖住**、又没有新字幕补上 → 成片里 B-roll 那几秒**完全没字幕**（2026-10-05 实测踩到） | ✅ **正解：字幕只在最后一次统一烧** —— 前 N-1 次调用传 `empty.ass`（保证像素里没字幕），最后一次传真字幕。⛔ 别用「第 1 次真字幕 + 后面空 ass」。✅ **更省事的做法：多段 B-roll 先在外部 `concat` 拼成一段**（同尺寸直接拼），**一次调用**插入（`--b-dur` = 总长）—— 字幕天然只烧一遍，省一半编码时间 |
| 50 | 🔴🔴 **dialogue 条目 `segments` 正文里若含舞台提示（如「（牧子琪点头）」），会被原样烧进字幕 → 出片即穿帮**（2026-10-07 首次遇到：seg2 首屏字幕出现「（牧子琪点头）对，」）。⚠️ 这类提示是**计划侧直接写进 `segments`** 的（不在 `dialogue_lines` 里），走常规分段路径必然带进字幕 | **在字幕渲染输入层清洗**：`mk_sub_segments.js` 生成 `segments_sub.json` 时剔除 `[（(][^）)]*[）)]`（该文件 2026-10-07 版已实现，可直接复用）。🔴 **口播原文（内容包 / segments.json / 周计划）一字不动** —— 这属修正渲染，不算改文案（铁律 1 不破）。⚠️ **出片后必须抽帧看字幕首屏**：只验「有没有溢出」抓不到这个 |
| 51 | 🔴 **`_trim_and_burn.js` 依赖 `mk_sub_segments.js` 先跑** —— 漏跑即 `ENOENT ... segments_sub.json`，整个合成在生成字幕那步中断（2026-10-07 踩到，白等 2 分钟才发现）。⚠️ 它是「从上一轮目录复制脚本」时最容易漏带的一件（看着不像主流程） | 固定顺序：`_setup → build_prompts → gen/poll → **mk_sub_segments** → _trim_and_burn`。复制脚本到新日期目录时**逐件核对**，别只 copy「看着像主流程」的那几个 |
| 52 | 🔴 **手敲微云清单两大坑**：① `mcp__tencent-weiyun` **常常不在自动化会话的 deferred 工具索引里**（配置层全绿也没用）→ 必须走 mcporter 旁路；② 旁路时把脚本路径写成 git-bash 形式 **`/c/Users/...`** 会被 Node 解析成 **`D:\c\Users\...`** → `Cannot find module`（2026-10-08 踩到）；③ 手工拼清单容易忘刷新 → `weiyun_watch.js` 报 **`[WARN] 清单已超过 300 分钟未更新`**（判增量前必须确认清单是**本轮**拉的，否则等于拿旧快照倒推） | ✅ **统一用 `scripts/pull_weiyun.js`**（2026-10-08 固化）：一条命令拉「根目录 + 递归一层子目录」→ 合并写 `.staging/weiyun_items.json`（子目录条目 `dir_path` 写真实子路径），内部 `execFileSync` 直调 mcporter 并剥掉 TLS warning 前缀再 `JSON.parse`。用法：`<NODE> scripts/pull_weiyun.js [--root <dir_key>] [--out .staging/weiyun_items.json]`，默认 root = `f9719500e77f6774368eef27806c9831`（MUZIAI/晓君总视频）。⚠️ **mcporter 脚本路径必须写 Windows 盘符形式** `C:/Users/admin/.workbuddy/binaries/node/versions/22.22.2-3/node_modules/mcporter/dist/cli.js`，配置文件 `C:/Users/admin/.mcporter/mcporter.json`（内含自带认证的 weiyun server）。跑完接着 `scripts/weiyun_watch.js diff --in .staging/weiyun_items.json`，此时清单应为「0 分钟前」 |
| 53 | 🔴 **CTA 收口「口播意愿优先」（2026-10-09 晓君总指令）** | 生成/补全 payload 的 `description`、或剪微云真人素材时，习惯性套用 profile 的 CTA 词池（三选一钩子 / 旧六词）—— 但**本人原声里可能已经说了自己的收口**（如「有需要找我」「欢迎找我报名」）。套词池 = 用模板覆盖本人意愿 | 🔴 **口播意愿 > 词池**：① 口播/素材里本人已有明确收口 → **按原意原样收口**，`description` 照写（可润色语境，不改收口含义），**不得**换成员池词；② 口播未给明确意愿 → 才用词池兜底（三选一优先，旧六词兼容）；③ 周计划线把 `ctaType` 标为「**口播意愿**」（含「原声」「本人意愿」）即免词池校验（`validate_plan.js` 已开豁免，仅保留「落在末段正文」校验）；④ 两份 profile `extra.ctaMix` 已同步此优先级。⚠️ 违例例证：2026-10-09 xjz8 口播原声「有需要找我」被误套成「评论区打「行业」」 |
| 54 | 🔴 **`segment_materials` 的 `segment` 与 `note` 锚点不一致 → 素材语义错位、叙事顺序乱**（2026-10-10 首次遇到：《一台电脑就是一个新媒体部门》第 3 条声明 `segment:2`，但其 note 锚点「数据自己回收、每周出报表」实际在 **seg3**）。原逻辑只在**声明段内**做 LCS 匹配 → 命中不了就**回落该段首行** → 数据回收录屏被放到 seg2 开头「这条线能干什么」处，语义不符，三条素材顺序变成「数据→写稿→发布」 | ✅ **`_trim_and_burn.js` 已加「跨段兜底」**（2026-10-10）：段内 `score<4` 时把**全片字幕行再搜一遍**，命中（`score≥4`）即落到锚点真实所在段，`matchedBy` 标「🔧跨段匹配」；仍无命中才回落声明段首行。依据硬规则「素材**语义**必须与该段内容对得上（note 里写了对应关系）；对不上就跳过，不许硬塞」。⚠️ 换条目复用脚本后**必看 `_overlay.json` 的 `matchedBy`**：出现「回落该段首行」即说明该条素材语义没对上，需人工确认。另附同轮加固：同段多素材按起点排序后**去重叠**（后者起点落到前者区间内 → 顺延到前者结束），避免后插的覆盖先插的、静默不显示 |
| 55 | 🔴 **`yxer accounts list <平台> --json` 偶发返回 **0 字节空响应** → 脚本按 `data=[]` 误判「目标号不在列表中」**（2026-10-10 遇到：视频号重扫授权后**首次**调用即空返，`_acc_视频号.json` size=0，`_yxlist.js` 打印「🔴 视频号 目标号 6a9bae4e… 不在列表中！(list=)」——**看着像账号被移除，实际重跑即正常**）。成因：客户端重扫后账号列表尚未刷完的瞬时态 | ✅ **判据：`data` 为空数组 **且重跑仍为空** 才算异常** —— 单次空返回一律视为瞬时态，**原样重跑 1~2 次再判定**。脚本层建议给 `accounts list` 加**空响应重试**（空串 / 非 JSON 时 sleep 2s 重跑，最多 3 次），别让「空」直接落进「不在列表」分支。⚠️ 与「status=2 授权失效」是两种现象、别混判：**status=2 = 读到了号但离线**（硬拦截跳过、登记待重扫）；**空返回 = 根本没读到**（重试，不是账号问题） |
| 56 | 🔴 **单段口播字数超 115 硬线时，15s 装不下 —— 但 duration 上限就是 15s，改不了**（2026-10-11 首次遇到：周计划 seq7《花小钱换一个不眠不休的团队》seg2 = **118 字**，build_prompts.js 打「🔴 ERROR >115」，而 validate_plan.js 只校验总字数档位、**不校验单段**，所以计划侧能一路放行）。依据 prompt-templates.md:112「每段 ≤115 字（对应 ≤15s）」、SKILL.md:149「单段安全区 ≈109 字（7.3 字/秒 × 15s）」〔⚠️ 口径已于 2026-10-23 下调为 101 字，本条仅为历史记录〕；dreamina multimodal2video --help 明确 **seedance2.0 全系 duration 4-15s**（只有 seedance2.5 能到 30s）→ **没有「把这段拉长」这个选项** | ✅ **处置：不中止、不改文案（铁律「一个字也不许改」），生成后做尾字复核** —— ① 生成 part1~N 后，用 `_asr_check.js`（2026-10-11 新建，从本目录复制到新日期生产目录即可用）把该段音轨抽 16k 单声道 wav → 跑 `muzi-local-asr-edit/scripts/vosk_transcribe.py`（模型须放**纯 ASCII 路径** `C:/Users/admin/.workbuddy/tmp/vosk-cn`，中文路径会报 Failed to create a model）→ 看**末句关键词是否完整在位**；② 本轮实测：118 字在 15s 内**末句「客户一个不漏，你想嘛」完整解码出来，无尾字丢失**（Vosk 小模型错词多，但**末尾关键词可辨**，够做「有没有被吃」的存在性判据）；③ 若真被吃 → 只报晓君总、由他决定是否改文案，**不得自行改口播、不得降级发布**。⚠️ 这类「计划侧超线」条目要在**简报里显式写明**「已做尾字复核、结论 XX」，别沉默放行 |
| 57 | 🔴🔴 **`node -e "…"` 里出现反引号 → bash 真去执行它（命令替换），并且「结果照样成功」——静默吞掉正文**（2026-10-12 第 2 次踩，首次踩在写文件、本次踩在**企微 payload**：JS 单引号串里写了 `` `内容计划/短视频周计划-…json` ``，bash 报 `No such file or directory` / `command not found`，**payload 仍写成、`success:true` 仍返回**，但两条文件路径被替换成空串 → 首条企微消息缺了最关键的中止依据）。⚠️ 本质与「`node -e` 反引号」同源，但危害升级：**外部命令成功 ≠ 内容正确**，只看 `success` 会以为发对了 | ✅ **正文含反引号 / 路径 / 任何 shell 元字符时，一律不用 `node -e` 内联拼接** —— ① 用 **Write 工具**把正文落成 `.json`（payload）或 `.md`（简报）文件；② 再 `wecom.js message aibot send --json "$(cat file)"`（**命令替换的输出不二次展开，反引号安全**）。③ 写文件同理：Write 工具落 `.staging/_append_*.md` → `node -e "fs.appendFileSync(dst, fs.readFileSync(src,'utf8'))"`（该命令本身零反引号）。④ 自检：发送后**回读落盘文件**确认路径段在位，别只看 `success` |

| 58 | 🔴 **`preflight_check.js` 全量跑时必须「只带本轮真正要发的平台」** —— 若把 `status=2` 的账号 payload 一起传，**C2 会 FAIL 把整轮判死**，与硬规则「status=2 → 跳过该平台、**继续其余平台**」直接冲突（2026-10-15 踩到：视频号 status=2，把 `payload_sph.json` 混进全量跑就会挡掉抖音+小红书）。⚠️ 一个平台的账号故障不该拖垮其它平台 | ✅ **做法**：① 全量 preflight 只传**本轮实际要发布**的 payload（如 `--payload payload_douyin.json --payload payload_xhs.json`）→ PASS 26 / WARN 0 / FAIL 0；② 被跳过的平台**单独跑一次** preflight 留证（会看到 `PASS 16 / FAIL 1`，唯一 FAIL = C2 在线 status=2），把这条作为「skip 有据」的证据写进台账/清单。⛔ 不要为了「全绿」而给故障平台改 payload 或换号顶替 |
| 59 | 🔴 **抽帧类脚本的时刻表（TS）不能固定 —— 必须按「最短段的时长 / overlay 窗口」逐轮改**（2026-10-15 踩到：`_segcheck.py` 仍用 `TS=[1,6,11]`，而本轮 part4 只有 **10s** → `ffmpeg -ss 11` 抽不到帧、PIL 打开失败，脚本崩） | ✅ `_segcheck.py` 的 TS 上界 = **min(各段时长) - 1**（生成后先 `ffprobe` 逐段量一遍再定；本轮 15/14/13/10 → 改 `TS=[1,5,9]`）。`_final_chk.py` 的 TS 同理：**按当条 overlay 窗口 + 成片总长**改（无素材时全取纯字幕帧）。⚠️ 这是「时长优先制」引入的连带影响：**段时长不再统一 15s，任何写死时刻表的脚本都要重新校** |
| 60 | ✅ **`gen.js` 已内建「按本段字数算 `--duration`」**（2026-10-11 时长优先制落地版，2026-10-15 solo 首次跑通）：`duration = clamp(ceil([...segments[i]].length / 7.3) + 1, 4, 15)`。🔴 **口径 = `[...s].length`（含空格字符数）**，与 10-14 dialogue 实测反推一致（10-14 记录 13/14/13/12 ⇄ 含空格 83/91/87/77）；**`videoGeneration.segmentDuration`（15）已作废，脚本里不得再读**。本轮 4 段 → 15/14/13/10，积分 480（比固定 15s 省）。⚠️ 附带结论：**段时长不等长后，`_trim_and_burn.js` 拼接与字幕时间轴无需改动**（它按实际 probe 时长算），但所有抽帧/质检脚本的时刻表要重新校（见坑 59） |
| 61 | ⚠️ **从上一轮目录 `cp` 脚本到新日期目录后，首次 `Edit` 偶发 `EBUSY: resource busy or locked`**（Windows 索引/杀软瞬占；2026-10-15 `_setup.js` / `_ledger.js` 各中一次，其它 14 件一次过） | **原样重发同一条 Edit 即成功** —— 不是文件损坏、不是内容问题、不是权限问题。若连续 2 次仍 EBUSY，再考虑 `sleep 2s` 后重试；**不要**改用「删文件重写」的方式绕过 |
| 62 | 🔴 **dialogue 条目的 `scene` / `outfit_action` 可能自带「移动镜头」描述，与 §1.6 硬口径②「固定机位」直接冲突**（2026-10-16 踩到：周计划 seq5《你不做，你的同行已经在做了》scene = 「夜晚步行街：两人并肩**缓行**…镜头**跟随**半身」、outfit 【拍摄】「**随行机位**，…不剧烈推拉摇移」；而 §1.6 ② 要求「固定机位、不推拉不摇移、不切景别」，§1.6 part1 模板也写「两位人物并排**坐**在…」）。⚠️ 若照条目写，part1 会是移动镜头，而 part2+ 必须锚定 part1 的静帧（打码帧）→ **同一条片子里镜头语言跳变**，人物还可能走出固定画面 | ✅ **处置：机位以 §1.6 硬口径为准，条目级的场地 / 光线 / 着装 / 道具全部保留** —— 在 `build_prompts.js` 里对 `scene`、`outfit_action` 加一层 `fixCam()` 措辞清洗：`两人并肩缓行→两人并肩站定`、`两人并肩边走边聊→两人并肩站定交谈`、`镜头跟随半身→固定机位双人半身`、`随行机位→固定机位`、`不剧烈推拉摇移→不推拉不摇移`。判据：条目级覆盖的是**场景内容**，不是**镜头语法**；镜头语法由 §1.6 统一。⚠️ 该清洗只在 dialogue 需要（solo 走自己的 part1 模板，不受影响）；本轮 4 段机位一致 → 段间一致性 PASS |
| 63 | 🔴 **`_trim_and_burn.js` 的素材插入点靠「note 引号短语 ↔ 字幕行」最长公共子串（LCS）模糊匹配；阈值 4 会在「note 比实际台词多一个字」时误判不匹配、回落段首**（2026-10-16 踩到：条目 note 写「出片、发布、**回**收数据」，实际台词是「出片、发布、收数据」，且该句被字幕折行切成「你交资料，它出片、」/「发布、收数据，你只做判断」→ 逐行 LCS 最高只有 **3**（「收数据」），按 `>=4` 不达标 → 回落该段首行，素材**早出场 3s**、错开「发布 / 收数据」那句） | ✅ **阈值 4 → 3**：降到 3 后命中正是「发布、收数据，你只做判断」行，语义严格对上、且仍在**同一段内**（不越段）。判据：LCS ≥3 属「同段内实质重合」，≥4 过严会把「note 比台词多一个字」这种正常情况判成不匹配。⚠️ 回落（找不到匹配行）时素材落在**段首**、语义可能偏 → **插片后必须抽帧确认素材压在对应句上**（本轮 T=18.43s 抽帧确认压在「它出片、发布、收数据」） |

### 可复用的生产脚本

`output/short_video/<日期_场景>/` 下每次会留一套（**2026-09-21/22/23 实际在用的就是这五件**，
改日期/场景/段数即可复用，坑 24/25/27/29 都已在里面处理过）：

| 脚本 | 作用 | 关键点 |
|---|---|---|
| `_setup.js` | 周计划条目 → `内容包.json` / `segments.json` / `script.txt` | 字段一律取自条目，缺失回落 `productionDefaults`；`hold:true` 直接 `exit 3` |
| `build_prompts.js` | 由内容包生成 `partN.prompt.txt` | part1 写场景 + outfit_action；part2+ **只写「以参考图为唯一依据」**（坑见 §Step 5） |
| `gen.js <N>` | 提交第 N 段（`--poll 0`） | 段数动态（读 `pkg.segments.length`），part2+ 自动挂 `--image part1_mosaic_ref.jpg` |
| `poll.js <submit_id> <name>` | 轮询到落盘并改名 `partN.mp4` | 判成败看 `gen_status`，**不看 exit code**（坑 24）；可并行跑多个 |
| `build_payload.js` | `_meta.json` → 各平台 `payload_*.json` | 🔴 **2026-10-09 起三平台 = 视频号 + 抖音 + 小红书**（小红书并入通发；此处原写「只发视频号+抖音」已作废，2026-10-16 修正）。**抖音描述自带 30 字压字口径**（坑 27）；小红书 `title` ≤20 字（取条目 `xiaohongshu.title_options[0]`，**须按小红书重写、不得照抄抖音标题**）+ `description` 末尾 3–5 个话题标签 + `visibleType: 0`；封面必须以 `_xhs` 后缀重传（新 key） |

另有 `_send_brief.js`（企微简报，正确 `msg_type=markdown` shape，见坑 28）与 `manifest.json`（本轮全量留痕：
生成 submitId / 素材插入区间 / 发布回执 / 质检结论）。

**2026-09-28 补齐的几件（建议一并复制，省掉当天现写）：**

| 脚本 | 作用 | 关键点 |
|---|---|---|
| `_adapt.js` | 复制上一轮八件套后**一键换常量** | 替换表要含四类：①目录名（最长优先）②**成片文件名**（常残留上上轮的名字！）③周计划文件名（跨周会变）④日期字面量；写完必须**回读校验无残留** |
| `_upload.js` | 成片 + 封面 → `yxer upload --auto-meta --json` | 把返回原样存 `_meta_raw_{video,cover}.json`，再合成 `_meta.json` 供 `build_payload.js` 读 |
| `_qdetails.js` | `query details` 轮询终态 | 正则带 `\s*`（坑 42）；**只认 `stageStatus=success` 且 `errorMessage` 空**；云发布是异步，`ok:true` 只代表已提交 |
| `_ledger.js` | 写 `output/published_log.json` | **一天只许一条 `date`**；已有则追加进该条 `platforms`，按 **平台 + platformAccountId** 判重覆盖；轮次状态=「有任一 published 即 published」；账号离线跳过写 **`skipped`**（不算已发、允许补发），**只有轮次中止才写 `failed`** |
| `_manifest.js` | 生成 `manifest.json` | 含 `overlayManifest` / `publish` / `preflight` / `imaSync` / `status` |
| `_grid.py` | 段间一致性网格（段×3帧，PIL） | 验白板/字迹/便签/灰墙/筒灯/桌椅/眼镜/着装/机位 |
| `_final_chk.py` | 成片抽帧网格（PIL） | 一次看全：**字幕有无溢出** + 素材 overlay 是否对上语义 |

🔴 **拼图一律用 PIL，别用 ffmpeg `xstack`** —— 本机 ffmpeg（N-126574）跑 `xstack` 多输入**只输出一格**（静默，不报错），
2026-09-28 踩到；`_grid.py` / `_final_chk.py` 用 PIL 拼图稳定可靠。

**skill 自带脚本（`<skill>/scripts/`，跨项目通用，别复制到项目里改）**：

| 脚本 | 作用 | 用在哪 |
|---|---|---|
| `preflight_check.js` | 发布前全量预检（A–G 项；**C0** = 账号暂停闸门 `_suspendFrom`） | Step 9 / Step 10 |
| `verify_cuts.py` | **剪接自检**：段内持续/断续离画 + 剪接点跳变 | **Step 9.1（FAIL 不得发布）** |
| `asr_to_ass.js` | ASR 逐字时间戳 → 分屏字幕(ass) + 纯文本稿 | §2B.2 |
| `remap_asr_by_keeps.js` | 🔴 **重剪后免重跑云 ASR**：把「原片 ASR」按 `--dump-keeps` 的保留区间**确定性重映射**到新成片时间轴 | §2B.12 ② |
| `plan_cut_by_words.js` | 🔴 **逐字定界出剪点**：从逐字 ASR 生成 `semantic.json`（逐字保留区间）+ `segments.json`（**含段尾气口**）+ 报告；`--suggest` 先列口水词 / 口误候选供人工确认 | §2B.6 |
| `fw_transcribe.py`（在 `muzi-local-asr-edit`） | 本地 faster-whisper 转写 → 词级时间戳（云 ASR 断线兜底） | §2B.1 |
| 🔁 `probe.js` | **素材体检**：时长/分辨率/帧率/**有无音轨**（无音轨 exit 3） | §2B 前置 0 |
| 🔁 `extract_audio.js` | 抽音轨 → 16k 单声道 wav（ASR 标准输入） | §2B.1 ① |
| 🔁 `build_join.js` | **按 segments 剪段 + 拼接 + 缩放**（默认等比不变形）；**自带段尾气口自检** | §2B.3 ① |
| 🔁 `burn_subs.js` | **烧字幕出成片**（cwd + 相对文件名绕开中文路径；显式 fontsdir） | §2B.3 ② |
| 🔁 `_ff.js` | ffmpeg / ffprobe 定位库（`VP_FFMPEG` / `VP_FFPROBE` → PATH）；被上面四件 require | — |
| `make_cover.py` | s1/s2/s3 封面渲染（PIL） | Step 7 |
| `notify_review.sh` | 发布简报卡片 + 企微推送（含 `--receipt`） | Step 10.5 |

🔁 **带此标记的五件（`_ff` / `probe` / `extract_audio` / `build_join` / `burn_subs`）与 skill `muzi-edit/scripts/` 逐字节一致** ——
**唯一上游是 `muzi-edit`**（对外的脱敏通用版）。改剪辑逻辑先改上游，再按 §2B 开头的 `cp` 命令同步本节副本，
并核对两边 md5（2026-10-16 23:45 已完成同步 + 4 项实测通过）。

> `verify_cuts.py` 耗时参考：100s 成片 @4fps/scale240 ≈ **5 分钟**（Haar 逐帧）。
> 属发布闸门，**建议后台跑**；赶时间可 `--fps-scan 2 --scale-w 160` 约快 4 倍，
> 但灵敏度会降 —— 降参数跑出来的 PASS **不足以**替代默认档的结论。


跨环节脚本（内容生产线同步用）：`ima_sync_doc.js`（`weekly` 周报合并 / `plan` 周计划单篇 / `daily` 发布日报 → ima 文档）、
`ima_upload_cos.js`（本地文件 → ima COS 暂存位），用法见 §3.1。
