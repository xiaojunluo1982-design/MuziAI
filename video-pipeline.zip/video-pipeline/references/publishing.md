# 发布细节（yxer 3.2.4 · 蚁小二，通用）

> 账号 ID / 账号名从 `profiles/<账号>.json` 的 `publishAccounts` 取。
> **发布前必须复核**：`yxer accounts list <平台> --status 1 --json`，
> 确认账号在线且与 profile 一致；找不到 → 停止并问用户，**不得发到别的号**。
> （多账号 IP 的最大风险就是串号：牧子琪发成晓君总的号，反之亦然。）
>
> ⚠️ 两个实操坑（2026-09-02 验证）：
> 1. `--status 1` **只返回在线账号**，所以「这个号是不是离线了」用它是查不出来的 ——
>    必须**不带 `--status` 全列一遍**，再按 profile 里的 id 比对 `status` 字段（1=在线，2=离线/授权过期）。
> 2. 账号名字段叫 **`platformAccountName`**，不是 `nickname` / `name` / `accountName`，
>    按后三者取会拿到 `undefined`，肉眼核对账号时会误判。
>
> 离线 → 跳过该平台并在汇报里写明「未发布—账号离线，需重授权」，**禁止换号顶替**。

## 1. 前置

```bash
yxer doctor --json
yxer accounts list 抖音   --status 1 --json
yxer accounts list 视频号 --status 1 --json
yxer accounts list 小红书 --status 1 --json
```

## 2. 流程（一步都不能跳）

> **2026-09-02 起免人工审核**：成片不再等晓君总点头，生产完成 + 质检通过即发。
> 人工那道关由 `scripts/preflight_check.js` 顶替，位置在 upload 前后各跑一次。

```bash
# ① 上传前：先验素材，有硬伤早发现、不浪费上传时间
node scripts/preflight_check.js --profile muziqi --video "<成片.mp4>" --cover "<封面.jpg>"

yxer upload "<成片.mp4>" --auto-meta --json     # 记下返回的 key / size / duration / width / height
yxer upload "<封面.jpg>" --auto-meta --json     # 记下 key / size / width / height / format

# ② 构造好 payload 后：验账号（防串号）+ 文案长度/合规 + 素材对象完整性
#    🔴 从 output/short_video/<日期_场景>/ 里跑必须带 --ledger（坑 25：默认路径跟 cwd 走，
#       不带就指向不存在的台账，G 项判重永远报「未发布过」）
node scripts/preflight_check.js --profile muziqi --video "<成片.mp4>" --cover "<封面.jpg>" \
  --ledger "D:/牧子数智/output/published_log.json" \
  --payload "<payload_抖音.json>" --payload "<payload_小红书.json>"

yxer validate <平台> video "<payload.json>" --json
yxer publish video <平台> "<payload.json>" --dry-run --json
yxer publish video <平台> "<payload.json>" --json    # 返回 taskSetId 即成功
```

**preflight 任一 FAIL 就停下修，禁止绕过。** 它拦的是三类公开事故：
串号（payload id 与线上账号名双重比对 profile）、成片硬伤（非 720×1280／无音轨／时长越界／封面 ≥512KB）、
文案违规（价格、百分比、效果数字、绝对化用语）与平台字数超限。

`--auto-meta` 自动探测宽高/时长/体积，直接把返回值填进 payload，比手填可靠。

## 3. Payload 骨架

```json
{
  "action": "publish",
  "platforms": ["<平台>"],
  "publishType": "video",
  "publishArgs": {
    "accountForms": [
      {
        "platformAccountId": "<profile.publishAccounts.<平台>.platformAccountId>",
        "contentPublishForm": {
          "formType": "task",
          "title": "...",
          "description": "..."
        },
        "cover": {
          "format": "jpg", "width": 720, "height": 1280,
          "key": "<upload 返回的 cover key>",
          "size": "<upload 返回的 size>"
        },
        "coverKey": "<与 cover.key 相同>",
        "video": {
          "format": "mp4", "width": 720, "height": 1280,
          "duration": "<upload 返回的 duration>",
          "key": "<upload 返回的 video key>",
          "size": "<upload 返回的 size>"
        }
      }
    ]
  }
}
```

## 4. 平台差异

| 平台 | 特殊字段 | 文案约束 |
|---|---|---|
| 抖音 | 无 | `description` ≤ 30 个中文字符 |
| 视频号 | `createType: 2`、`pubType: 1` | 封面必须 < 512KB |
| 小红书 | `visibleType: 0` | `title` ≤ **20 字**（**须按小红书重写，勿直抄抖音标题**，超长 preflight D 项 FAIL）；`description` 末尾带话题标签（蚁小二自动转 `<topic>`） |

### 4.1 小红书并入短视频通发（🔴 2026-10-09 晓君总指令）

原话：「今天起短视频也同步发小红书（晓君总和他的AI助理）」。真人短视频由「视频号 + 抖音」扩为
**视频号 + 抖音 + 小红书** 三平台串行通发；小红书出口 = `publishAccounts.小红书`（「晓君总和他的AI助理」`6a4a855e02413400bb6cfb98`）。
（旧口径「小红书是独立线、不接收真人片」作废；图文线日更 `dcbc8aac` 已 PAUSED。）

**小红书规格**（preflight D 项会拦）：

- `title` ≤ **20 字** —— 与抖音的 30 字不同，**必须按小红书重写**，直接抄抖音标题会 FAIL
- `description` 末尾带话题标签（3–5 个），蚁小二自动把 `#x` 转 `<topic text="x">`
- `contentPublishForm.visibleType: 0`

**🔴 同日多帖是预期行为**：小红书与该号上的其它帖（短视频内容线每日 1 条 + 补发队列每巡检点 1 条）同日共存。
因此 preflight 的 **G 判重（平台+账号+日期）必然 FAIL** → 小红书发布须显式加 `--allow-republish`，
并在汇报里写明理由「同日多条不同内容帖」。

真正的防重靠两层（**别依赖 G**）：

1. **分批发队列的 `mark`** —— 条目出队即不再发（`line=xhs_backfill`，见 §4.2）
2. **条目级判重** —— 按当天台账里**本条自身**（`seq`/`title`）的小红书记录判断，
   **不是**「当天该平台有没有帖」；当天已有别的帖子**不构成**跳过理由

🔴 **台账写入必须按 `date + seq` 定位记录，不能只按 `date`**（2026-10-09 实测踩点）：
小红书同日多帖 ⇒ 同一天会存在**多条 date 相同的记录**（如「小红书补发-01」+ 当日内容线条目）。
若写入脚本按 `find(r => r.date === DATE)` 找到第一条就 merge platforms，会**覆盖掉别条的审计痕迹**。
正确写法：`find(r => r.date === DATE && Number(r.seq) === SEQ)`，不存在才新建 ——
「一天只许一条 date」的本意是**防同一条目重复写**，不是禁止同日多条不同条目。

**封面**：沿用该条成片的同款封面，但**必须以 `_xhs` 后缀重命名后重新上传**（旧 key 不复用，
命名如 `cover_1006_xjz_xhs.jpg`，仍须含 4 位日期以过 B3 闸门）；视频 key 可复用（带 hash、无覆盖问题）。

### 4.2 小红书补发队列（`line=xhs_backfill`）

历史条目补发小红书时，复用分批发队列：`scripts/publish_queue.js enqueue --in <items.json>`，
条目字段 `line:"xhs_backfill"` / `payloadXhs` / `coverLocal` / `finalVideo` / `sourceDate`。
巡检点取 `next --line xhs_backfill`（**与微云线的 `next` 互不干扰**），发布窗口**每轮只消费 1 条**（沿用 §2B.11 分批发）。
`mark --status published` 出队；失败 `mark --status failed`。


账号离线期间 skipped 的内容，恢复在线后**逐条补发**（`skipped`/`failed` 不算已发，不触发重复发布拦截）：

```bash
# 定时发布：在 contentPublishForm 里加毫秒时间戳
"contentPublishForm": { "formType": "task", "createType": 2, "pubType": 1,
                        "scheduledTime": 1788346800000, ... }
# 时间戳用系统命令取，禁止手算：date -d "2026-09-02 19:00:00" +%s  → 末位补 000
# 复核：yxer query details <taskSetId> --json → isTimed=<ts> 且 stageStatus=doing 才算挂上
```

一条已发成功的任务 `stageStatus=success` 且带 `publishId`；定时任务是 `stageStatus=doing` + `stages=upload`。
补发完成后：周计划 `published.<平台>` 改状态 + `preflight_check.js --record` 登记台账，两处都要写。

### 5.1 「客户端重扫授权 → 原 payload 补发」标准动作（2026-09-21 / 22 / 23 连续三天实战）

晓君总回一句「授权了」即可开跑，**五步，不重传 OSS、不改 payload**：

```bash
YX="…/@yixiaoermail/cli/bin-native/yxer.exe"
OUT="D:/牧子数智/output/short_video/<当日生产目录>"

# ⓪ 🔴 先查该内容是否**已经发过**（2026-10-15 踩到：自动化已补发成功、人工又补一次 → 视频号两条同样片子）
"$YX" query records --platform 视频号 --limit 10 --json   # 已有同 title 的 success 记录 → **已发过，立即停止**，别再 publish
# ① 核账号：id 未变才可直接复用（重扫**不改 platformAccountId**）
"$YX" accounts list 视频号 --json          # 不带 --status；取出当前 id 与 profile 比对
# ② 核 payload 与素材仍在（video.key / cover.key 是 OSS key，重扫后依然有效）
#    同目录 payload_<平台>.json + 成片 + 封面都在 → 不重传
# ③ validate → dry-run（核对 meta.accountIds）→ publish（**payload 一字不改**）
"$YX" validate 视频号 video payload_视频号.json --json
"$YX" publish video 视频号 payload_视频号.json --dry-run --json
"$YX" publish video 视频号 payload_视频号.json --json       # → taskSetId
# ④ query details <taskSetId> 直到 stageStatus=success 且 errorMessage 为空
#    🔴 视频号：**实测约 3 分钟**（2026-09-29 补发：14 轮 × ~13s 才转 success；前 13 轮一直 `doing`，
#       第 11 轮才出现 publishId）→ **轮询次数至少给 15 次、间隔 10-20s**，设 5 轮就会把成功误判成失败。
#       **`doing` + `publishId` 已出现 ≈ 已进入上传后段，别在这个时候放弃**。
# ⑤ 三处收尾：台账 status failed→published（补 publishId、retryHistory 追加 success）
#    + output/待重扫授权清单.md 追加「已重扫·补发成功」行 + 推企微简报
```

🔴 **补发不会重复（仅限「自己失败的那次」）**：原任务挂在 `push`/`upload` 阶段失败、`publishId=null`，什么都没推出去；
且判重粒度是「平台 + platformAccountId + 日期」，`failed` 不占位。
🔴🔴 **但「别处已补发成功」时再补 = 平台上的重复帖** —— 2026-10-15 实测：08:40 一条同内容补发成功、08:46 人工又补一次
→ 视频号出现 **两条一模一样的 v3**，只能 `publish delete <task_id>` 去重。**故补发前必须走上面的 ⓪ 查 `query records`**。
⚠️ 判重粒度含「日期」，所以**跨天**（如台账记 10-14、今天 10-15）**拦不住**这种重复 —— 只能靠 ⓪ 查记录。
🔴 **别顺手换 payload 或重传素材** —— 改动反而可能撞上封面串号（见 §7）。
🔴 **「重扫授权」≠「立刻能发」——补发第 1 次仍可能报 `登录失效`（2026-10-15 实测）**：
客户端重扫生效后，第 1 次 publish 仍返回 `stageStatus=fail` / `获取用户信息失败登录失效`，
**间隔约 1~2 分钟后第 2 次同 payload 一次通过**（`stageStatus=success` / `stages=success` / `publishId` 非空）。
→ 所以**必须给足那 1 次重试**，别一次失败就重新挂回待重扫清单（会把「授权已恢复」误判成「没扫成功」）。
（`publishId=null` 的失败不占位，重试不产生重复。）
🔧 **`query details` 轮询：别用 `execFileSync('yxer', …)`**（2026-10-15 踩到）：本机 `yxer` 是**无扩展名的 shell shim**，
node 直接 `execFileSync` 拿不到输出、**静默返回空**（`tasks: []` 每轮都是空 → 看着像「任务不存在」，实际是调用没成功）。
✅ 用 **bash 手动计数**循环（`i=$((i+1))`，避开缺失的 `seq`）直接调 `yxer`；
或走真 exe 绝对路径 `…/node_modules/@yixiaoermail/cli/bin-native/yxer.exe`。
⚠️ 见到 `tasks: []` **先怀疑调用方式**，别当成任务不存在。
⚠️ **同一账号连续多天「登录失效」= 授权寿命问题**，不是内容问题：登记清单时写明连续天数与症状，
提示排查绑定侧，不要每天只做「重扫 → 补发」的循环。

## 6. 常见失败

| 现象 | 处理 |
|---|---|
| validate 报描述过长 | 抖音压到 30 字内 |
| validate 报缺视频/封面对象 | upload 后未把 key/size 写进 payload |
| 视频号封面 >512KB | 封面脚本 `--out-jpg` 已自动降质量；仍超限换更简单的底帧 |
| 本地客户端离线 | 让用户打开并登录蚁小二桌面端，**不静默切云发布** |
| **云发布 `stages=push` / `errorMessage=request failed`**（2026-10-01 实测，视频号） | 🔴 **这是平台侧瞬时抖动，不是授权问题、也不是客户端离线**。处置：**原样重试，2~4 次、每次间隔几分钟**。2026-10-01 视频号连挂 3 次，第 4 次同样的 payload、同样云端通道**一次通过**（`stageStatus=success`/`errorMessage` 空）。⚠️ 别因为 `status=1` 却连挂 3 次就下「客户端离线 / 账号授权坏」的结论 —— 那是两条不同的路：`--publish-channel local` 的 403「检测客户端设备未连接」才是客户端不在线，与云通道的 `push` 失败无关。重试不产生重复（挂在 push、`publishId=null`）。 |
| **云发布 `stageStatus=fail` + `errorMessage=登录失效 / 获取用户信息失败登录失效`**（2026-09-21 实测，视频号） | ⚠️ **`accounts list` 里 status=1 也不代表能发** —— `status` 是列出状态，实际发布时视频号仍会报登录态失效。处置顺序：① **重试 1 次**（重试不会产生重复，因为挂在 `stages=upload`、什么都没推出去）；② 仍失败 → **优先怀疑「这个号本身坏了」，直接试换号**：2026-09-21 原号（晓君总-销售智能体）反复报登录失效，换成「晓君总和他的AI助理」后**同一 payload 一次发通**（`stageStatus=success`）→ **账号级授权坏 ≠ 内容问题**，别在 publishType / 文案 / 素材上瞎改；③ 换不了号才走「待重扫授权清单」，等客户端重扫后复用同一 payload 补发（`failed` 不触发 G 项判重锁）。🔴 **换号是跨文件改动，别只改 payload** → 见下方「换号清单」 |
| validate 失败 | 看 `details.errors`；常见：描述过长、缺视频/封面、缺账号 ID |
| `Cannot find module ...\.22.22.2.deleting.xxx\...yxer.js` | node 版本目录被运行时轮换删掉了，PATH 里的 shim 指向死路径。修法见下 |
| `publish arguments appear to be in the wrong order` | 3.2.14 起 **validate 是 `<平台> <type>`、publish 是 `<type> <平台>`**，两者相反，写反就报这个 |

### 换号清单（2026-09-21 视频号换号实测 · 8 处；2026-10-08 补第 9 处 = 9 处，缺一处就留地雷）

换发布账号**不是改个 id 的事**。按这张表扫一遍，最后用 grep 复核：

| # | 位置 | 为什么 |
|---|---|---|
| 1 | `profiles/<账号>.json` 的 `publishAccounts` | 发布时的白名单来源（preflight C1/C3 直接从这读） |
| 2 | 同一 profile 的 `.md`（表格 + 正文引用） | 人手查账号时会看这份，不一致就误导 |
| 3 | `video-copywriter/profiles/<账号>.json` + `.md` | **两个 skill 的 profile 必须同改**（内容侧也带账号表） |
| 4 | 各 `SKILL.md` / 其他 profile 里的 prose 引用 | 例：`muziqi.json` 的 `approval._scope`、`ima-knowledge-export/SKILL.md` 红线条 |
| 5 | **`.staging/` 里的打包副本** | 打包上 ima 的源，不改等于下次把老号推回去 |
| 6 | **周复盘拉数脚本**（`内容计划/_raw/{summarize.py, pull_yxer.sh}`） | 这两个脚本写死了账号 name + id，不改下周复盘拉的是老号（返回空 = 假「数据不全」） |
| 7 | 当日 `payload_<平台>.json` 的 `platformAccountId` | 实际发布的那个字段 |
| 8 | 发布台账 + 「待重扫授权清单」 | 老号那条改 `status: superseded`（作废·换号），并说明**不再需要重扫** |
| 9 | 🔴 **自动化 prompt**：`8b146b6a`（每日 05:00 即梦线）＋ `eb6c20ff`/`3c190460`/`a30519fe`（09/12/18 微云巡检线） | **2026-10-08 实测踩到**：prompt 里写死了「视频号 X / 抖音 Y」和「原『晓君总-销售智能体』已停用，不得再发」 —— 换号/改分流后不去改，明早 5 点就跟新规则顶牛（那句「以 profile 为准」只是兜底，不顶用）。**这些 prompt 必须同时写：① 账号一律「以 profile 为准」② 本任务的**本线**出口是谁、另一个号归哪条线**。用 `automation_update mode=update` 改（⚠️ 要回传整段 prompt，别只传片段） |

复核命令（应只剩历史 memory / 旧日志 / 快照）：

```bash
grep -rn "<老号名>\|<老号platformAccountId>" "D:/牧子数智" "C:/Users/admin/.workbuddy/skills" | grep -v "\.zip"
```

⚠️ **`.staging/` 的 profile 副本没有自动同步机制** —— 改完 skill 里的 profile 一定要顺手同步过去。

### yxer 入口自愈（2026-09-02 踩坑；2026-09-16 更新：优先用原生二进制）

`yxer` 命令只是个 shim，指向 node 版本目录下的 `node_modules/@yixiaoermail/cli/bin/yxer.js`。
运行时管理器轮换 node 版本时会把旧目录改名成 `.22.22.2.deleting.<ts>` 待删，shim 随即失效，
**表现为每天第一次调用直接 MODULE_NOT_FOUND，整条自动化静默挂掉**。

**✅ 首选解法（2026-09-16 实测，3.2.17 起有效）：绕开 shim，直调包内原生二进制。**

```
<node 版本目录>/node_modules/@yixiaoermail/cli/bin-native/yxer.exe
```

- 这是 **15.6 MB 的 Go 原生可执行文件**，不经 node、不经 shell shim，**不受 node 版本轮换影响**。
- 参数用数组传（`spawnSync(EXE, ['accounts','list'])`），返回就是 JSON，好解析。
- 🔴 **别写成 `node <…>/yxer.exe`** —— 它是原生二进制、不是 JS 入口；用 node 起会立刻报
  `SyntaxError: Invalid or unexpected token` + `Node.js v22.22.2` 堆栈（**2026-10-02 实测踩到**）。
  自动化 prompt 里若同时给了 `NODE` 与 yxer 路径，**只有非 exe 的 .js 工具才需要 NODE 前缀**。
- **自检**：`yxer.exe --version` → `{"ok":true,...,"version":"3.2.17"}`；返回 node 堆栈就是入口坏了。
- 包装器仍可用（`yxer` / `yxer.cmd` / `yxer.ps1` 在同目录），但它依赖 shell 环境；
  在 PATH 不完整的 shell 里容易踩坑（本机 `/usr/bin` 就不在 PATH），**自动化脚本一律走 exe**。

**备选**：若确实要用 shim，需有一个不随版本目录轮换的稳定入口（装在 `<家目录>/bin/`，内部动态探测
`versions/*/node.exe`）。若 `which -a yxer` 里出现 `.deleting.` 路径且排在前，把该目录下的
`yxer / yxer.cmd / yxer.ps1` 改名成 `*.disabled` 即可（运行时缓存，非用户文件）。

> 历史上这里写死过 `C:\Users\user\bin\yxer`（用户名占位符没替换），**不要照抄**，
> 统一用 `$HOME` / 家目录动态拼接。

### 🔴 成片与封面文件名都必须带日期唯一名（MUST · 2026-09-02/09-29 封面 + 2026-10-14 成片）

`yxer upload` 的 key **一律按文件名派生**：封面是 `cover_<MMDD>_<账号>.jpg`（原名不带 hash），
**成片是 `<ASCII前缀>_<hash>.mp4` —— 看着带 hash 很唯一，但那个 hash 是【从文件名算出来的】**，
所以**同名必同 key**（10-14 实测：10-07 与 10-14 两条同题成片都得到 `AI_6170f7bb.mp4`）。
⚠️ 旧版本这里写的是「视频 key 带 hash 所以可复用」—— **那句话是错的**，正是 2026-10-14 成片事故的来源。
带来三个叠加的坑：

1. **互相覆盖**：不同天的封面都叫 `cover.jpg` / `cover_512k.jpg` 时，OSS 上只有一个文件，**后传的覆盖先传的**。
2. **成片同名同 key（10-14 新增）**：同题跨周复用（如 `AI时代最大的杠杆` 10-07 solo 版、10-14 dialogue 版）
   两条成片文件名相同时 → 同一个 key → 同一个 URL。
3. **CDN 缓存 30 天**（2026-09-29 实测）：这个 URL 被蚁小二 CDN 缓存，
   `X-Swift-CacheTime: 2592000`（= 30 天）。**覆盖上传后 CDN 仍回旧图** ——
   实测 `GET .../cover.jpg` 连打 3 次都是 `X-Cache: HIT TCP_MEM_HIT` / `Age: 72469` / `Last-Modified: 09-28`，
   返回的是 **09-28 小红书那张封面**（82825 B），不是刚上传的那张（132635 B）。

**2026-09-29 事故**：微云直剪线用通用名 `cover.jpg` 上传，视频号 + 抖音抓到的都是 CDN 缓存里
**09-28 小红书那条的封面** → 两张帖子封面全错，只能 `publish delete` 删帖重发。

**铁律**：

- 封面**必须**先命名成日期唯一名再上传：`cover_0929_xjz.jpg` / `cover_0929_dy.jpg` / `cover_sph_0902.jpg`…
- **成片**同样必须先带日期再上传：`<title>_完整版字幕_1014.mp4`（→ key `AI_1014_49c6fa60.mp4`）。
  （`preflight_check.js` 已加 **B3（封面）/ B4（成片）FAIL 闸门**：basename 不含日期标记 → 直接阻断发布）
- **旧 payload 里的封面与成片 key 一律不复用**，重新上传拿新 key（成片改文件名即可得到新 key）。
- 上传后**必须回验**：`curl -sD- <新 coverUrl>` 看 `Content-Length` / `Last-Modified` 是否与本地一致
  （新 URL 首次应是 `X-Cache: MISS`）。对不上就是撞了缓存，换名重传。
- 已发错的帖（封面错 / 成片错同理）：蚁小二没有「改素材」接口，只有 `yxer publish delete <task_id> --dry-run` →
  `yxer publish delete <task_id>`（删平台作品）+ 重新 `publish`。**先发新的、验成功、再删旧的**，避免删完发不出去。

### 🔴 封面字体/样式必须走 profile 的 coverFont（MUST · 2026-09-29 踩坑）

`make_cover.py` 的 `STYLES[style]["font"]` 是**风格推荐字体**，不传 `--font` 就用它。
**代价是「静默」**：脚本不报错、画面照样有字，只是字体/斜体不对 —— 肉眼当天不一定看得出，
但不符合规范，等于没按 profile 出封面。

**2026-09-29 事故（第二次退回）**：微云直剪封面只传 `--style s1`，当时 `STYLES["s1"].font = "douyin"`，
出的是**优设标题黑 + 直立字**；而规范是 **`song-bold` 思源粗宋 + `--italic` 斜体切变**
（`xiaojunzong.json` → `defaults.coverFont = "song-bold"`，2026-09-16 晓君总定；
09-22~09-28 各期 manifest 记的都是 `s1 + song-bold + italic`）→ 被晓君总退回重做。

**铁律**：

- 出封面前**必须**读 `profiles/<账号>.json` 的 `defaults.coverStyle` **和** `defaults.coverFont`，
  把 `coverFont` 显式传给 `--font`，斜体显式加 `--italic`。晓君总现行命令：
  `make_cover.py --style s1 --font song-bold --italic …`
- 出图后**必须肉眼看字体形态**（宋体有衬线笔锋、斜体是切变倾斜），别只确认「有字」。
- `STYLES["s1"]` 已于 2026-09-29 把默认对齐规范（`font="song-bold"`、`italic=True`，
  并新增 `--no-italic` 供强制关闭）——`--style s1` 单参数就是对的；但**其它风格仍以 profile 为准**。

## 7. 运营数据回采（周复盘用 · 2026-09-20 实测）

发布后做数据复盘，不要爬平台，直接用蚁小二自己的两个接口：

```bash
# 账号级：粉丝/播放/点赞/点击率/净增取关
"$YXER" query account-overviews --platform <平台> --name <账号名> --json

# 作品级：逐条播放/点赞/评论/分享/收藏/发布时间
"$YXER" query content-overviews --platform <平台> --account-id <platformAccountId> --size 20 --json
```

🔴 **`overviewData` 是「字符串形式的 JSON」**，必须二次 `json.loads`：

```python
d = json.loads(resp["data"]["data"][0]["overviewData"])
metrics = {i["name"]: i["value"] for i in d["value"]["video"]}
# 总粉丝数/播放量/主页访问/点赞/分享/评论/封面点击率/净增粉丝/取关粉丝
```

`content-overviews` 的字段挂在 `contentData` 下：`desc / play / great(点赞) / comment / share / collect / date`。

**数据完整性判定（红线）**：先跑 `accounts list <平台> --json` 看目标账号 `status`
（1=可发，2=授权失效）。**status=2 时 `content-overviews` 会返回空数组，不是"没数据"而是"取不到"** ——
必须标「数据不全（授权失效）」并列出待重扫账号，**严禁用 0、空值或历史数据顶替**。
抖音存在回传延迟，`play>0` 但 `great=0` 属正常，报告里要注明。
