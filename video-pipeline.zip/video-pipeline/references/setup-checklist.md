# 使用前的配置清单（Setup Checklist）

> 拿到这套 skill 的人，请**先做完本清单再跑第一条视频**。
> 打包版里所有账号凭证、路径都已替换成占位符——**不是给你用的，是让你填自己的**。
> 填完后跑一遍自检脚本：
> ```bash
> node video-pipeline/scripts/setup_check.js --profile <你的账号>
> ```
> 全 PASS 才能开工；有 FAIL 就照提示补，别硬跑。

---

## 0. 这套东西依赖什么（先确认环境）

| 工具 | 用途 | 怎么确认装好了 |
|---|---|---|
| `node` | 分段 / 字幕 / 校验 / 质检 | `node -v` |
| `python` + Pillow | 封面生成、马赛克 | `python -c "import PIL; print(PIL.__version__)"` |
| `ffmpeg` / `ffprobe` | 抽帧、拼接、烧字幕、音量检测 | `ffmpeg -version` |
| `dreamina` | 视频生成（即梦） | `dreamina session list` |
| `yxer` | 多平台发布（蚁小二） | `yxer doctor --json` |

⚠️ 最容易漏的是 **Pillow**：系统 `python` 常不带它，封面会直接 `ModuleNotFoundError`。
没有就用带 Pillow 的那个解释器路径，或者 `pip install Pillow`。

⚠️ 第二容易漏的是 **ffmpeg**（2026-09-16 补）：它不在 PATH 里时，
要到 Step 4 抽帧或 Step 8 烧字幕才炸，前面的视频生成全白跑。

- Windows 装法：下 BtbN 的 `ffmpeg-master-latest-win64-gpl-shared.zip`
  （`github.com/BtbN/FFmpeg-Builds/releases`，★ 必须 gpl/shared 或 gpl，**别用 LGPL 版——不带 libass**），
  解压后把里面的 `bin/` 加进 PATH，或设 `VP_FFMPEG=<绝对路径>/ffmpeg.exe`。
- gyan.dev 的 `ffmpeg-release-essentials.zip` 也带 libass，但国内下载慢不少。
- **验证 libass**：`ffmpeg -hide_banner -filters | findstr ass` —— 有 `ass` / `subtitles` 才行。
  没有 libass 的构建烧不出字幕，且同样不报错。
- 上面这些都已被第 5 节的自检脚本覆盖（ffmpeg / ffprobe / libass 三项）。

---

## 1. 必须自己配的凭证（包里是占位符，别直接用）

| # | 项 | 填在哪 | 怎么拿到 |
|---|---|---|---|
| 1 | **即梦会话 ID** | `profiles/<账号>.json` → `videoGeneration.fallback.session` | 即梦里给这个 IP **单独建会话**，然后 `dreamina session list` 看 ID |
| 2 | **蚁小二发布账号 ID** ×N | `profiles/<账号>.json` → `publishAccounts.<平台>.platformAccountId` | `yxer accounts list 抖音 --json`，取对应账号的 `id` |
| 3 | **ima 知识库 ID**（可选） | `profiles/<账号>.json` → `imaKnowledgeBaseId` | ima 里打开知识库看 ID；不用 ima 就删掉这行 |
| 4 | **视频生成工具路径**（可选） | `videoGeneration.primary.exe` / `.secondary.exe` | 本机安装位置；只用即梦兜底通道就留空 |

⚠️ **关键**：即梦会话必须**每个 IP 单独建**。两个 IP 共用一个会话 = 素材串号，是事故级错误。

---

## 2. 素材与目录（照这个结构备）

```
<项目根>/
├─ <角色>.jpeg        # 身份/脸部基准图，每段必传，否则脸会飘
├─ 拍摄场景/          # 真实照片，禁止 AI 想象场景
├─ 视频素材/          # B-roll：聊天截图 / 客户好评 / 自动跟进 / 操作录屏
├─ voice/             # 声音参考 2-15s（要求真人原声时才需要）
└─ output/{周计划,内容包,short_video}/
```

然后把这些路径填进 `profiles/<账号>.json` 的 `paths` 块。

**身份图的质量决定一切**：正面、清晰、光线正常、不戴墨镜/口罩。
生成时它是脸部基准，糊了后面每段都会飘。

---

## 3. 字体（不做这步，中文字幕会静默掉回默认字体）

### 3.1 五款字体 —— **文件名是脚本写死的，必须一字不差**

`scripts/make_cover.py` 的 `FONT_ALIASES` 按**文件名**拼路径，改名就读不到；
`scripts/gen_subtitles.js` 的 ASS `Fontname` 用的是**该字体注册到系统的名字**，不是文件名。

| # | 字体 | **必须叫这个文件名** | ASS `Fontname`（已修正） | 用到它的款式 |
|---|---|---|---|---|
| 1 | 优设标题黑 | `YouSheBiaoTiHei.ttf` | `YouSheBiaoTiHei` | s1 s7 · t1 t6（**默认款**）|
| 2 | 得意黑 | `SmileySans-Oblique.ttf` | **`Smiley Sans Oblique`** ⚠️原写 `Smiley Sans` | s2 s8 · t2 t7 |
| 3 | 胡晓波男神体 | `HuXiaoBoNanShenTi.otf` | `HuXiaoBo-NanShen` | s3 s9 · t5 t8 |
| 4 | 锐字真言体 | `RuiziZhenYan.ttf` | `ZhenyanGB` | s5 s6 s11 · t3 t10 |
| 5 | 阿里普惠体 Heavy | `AlibabaPuHuiTi-Heavy.ttf` | **`Alibaba PuHuiTi 3.0 105 Heavy`** ⚠️原写 `Alibaba PuHuiTi` | s4 s10 · t4 t9 |

### 3.2 🔴 最重要的坑：Windows 上 fonts.conf 对 libass 无效（2026-09-16 实测）

**先说结论**：Windows 版 ffmpeg 的 libass 多数组建用 **DirectWrite 字体提供者**
（启动日志会打印 `Using font provider directwrite (with GDI)`）。这种情况下：

- `FONTCONFIG_FILE` / `fonts.conf` / `<dir>` **全部无效**，写不写一样；
- libass 只认「已注册到 Windows 的字体名」，字体文件丢在目录里它看不见；
- **找不到就静默回退**（实测退到微软雅黑）—— 画面照样有字幕、不报错，肉眼几乎发现不了。

**实测数据**（同机、同一 ffmpeg，只改 Fontname 写法）：

| ASS `Fontname` | 结果 |
|---|---|
| `YouSheBiaoTiHei` / `HuXiaoBo-NanShen` / `ZhenyanGB` | ✔ 命中 |
| `Smiley Sans` | ✗ → Arial |
| `Smiley Sans Oblique` | ✔ 命中 |
| `Alibaba PuHuiTi` | ✗ → Arial |
| `Alibaba PuHuiTi 3.0` | ✗ → Arial |
| `Alibaba PuHuiTi 3.0 105 Heavy` | ✔ 命中 |

**必须同时做这两条**：

1. **烧字幕命令带 `:fontsdir='<字体目录>'`**（libass 原生参数，跨字体提供者都有效）：
   ```bash
   -vf "ass=subtitles.ass:fontsdir='C\:/path/to/fonts'"     # 盘符冒号转义成 \:，整体加单引号
   ```
2. **把 5 款字体装进 Windows 用户字体库**兜底（HKCU，不需要管理员）：
   复制到 `%LOCALAPPDATA%\Microsoft\Windows\Fonts`，再在
   `HKCU\Software\Microsoft\Windows NT\CurrentVersion\Fonts` 里注册
   `"Smiley Sans Oblique (TrueType)" = <完整路径>` 这样的项。

> ⚠️ 「装进系统」**不能**解决名字问题 —— 实测装完后 `Smiley Sans`、`Alibaba PuHuiTi` 依然回退。
> **Fontname 必须写成上表「已修正」那一列的值。** 换字体版本（尤其普惠体 2.0/3.0）后要重新
> 确认这个名字，用第 5 节自检脚本的「字幕字体端到端实测」项验。

### 3.3 配置步骤

1. 备齐上面 5 个文件（免费商用，官方出处见文末），放进同一目录
2. 设环境变量（`make_cover.py` 靠它找字体）：
   ```bash
   export VP_FONTS_DIR="<你的字体目录>"        # Windows 持久化：setx VP_FONTS_DIR "<目录>"
   ```
3. 把同一目录写进 `~/fonts.conf`（**仅对 fontconfig 型 libass 有效**——Windows 上实测完全无效，见 3.2；非 Windows 必需）：
   ```xml
   <!-- C:\Users\<你>\fonts.conf
        仅非 Windows 生效；Windows 上 setup_check.js 不再用它判 FAIL，只输出一条说明性 OK -->
   <dir><你的字体目录></dir>
   <dir>C:/Windows/Fonts</dir>                      <!-- 微软雅黑等系统字体兜底 -->
   <cachedir>C:/Users/<你>/.workbuddy/cache/fontconfig</cachedir>
   ```
4. **再加上 3.2 的那两条**（fontsdir + 装进系统），然后跑第 5 节自检。

#### 3.3.1 自检怎么找字体目录（别被「字体目录不可访问」误导）

`setup_check.js` 按**候选链**找，命中即用，并在 PASS 里标出来源：

```
VP_FONTS_DIR  →  profile.paths.fontsDir  →  ~/.workbuddy/fonts  →  G:\牧子琪\fonts（内置默认）
```

- `VP_FONTS_DIR` 由 `setx` 落盘，**只对新进程生效**：已在运行的终端里读不到，
  这时脚本会自动落到后面的候选目录并给一条 WARN，**不是故障**，重开终端即可。
- 若 5 个候选全不存在才判 FAIL（报错信息会把所有候选路径列出来）。
- **`--offline` 下也必须出现「字幕字体端到端实测」**。若该行消失，说明被跳过了——
  脚本现在会对任何跳过显式 WARN（ffmpeg 缺失 / 目录没解析到）。**看不到这一行就别开工。**

### 3.4 免费商用出处（均为官方免费商用授权）

| 字体 | 官方/可信来源 |
|---|---|
| 优设标题黑 | 优设网发布，免费商用无需许可 |
| 得意黑 | `github.com/atelier-anchor/smiley-sans`（OFL 1.1，最干净）|
| 胡晓波男神体 | 胡晓波工作室 2019 发布，已登记国家版权局，个人与企业免费商用 |
| 锐字真言体 | 锐字潮牌字库（REEJI）；官方字体名即「锐字真言体**免费商用**」|
| 阿里普惠体 | `fonts.alibabagroup.com`，阿里官方免费商用 |

> 一次性拿齐这 5 款（含授权说明页）：`github.com/jaywcjlove/free-font`（精选合集，⭐4k+）。

⚠️ 字体版权自己确认。**别拿未授权字体做商业内容。** 第三方字体站常给自动生成的
"需授权"免责声明，与官方口径冲突时以**字体厂商官方发布页**为准。

---

## 4. profile 本身

```bash
cp video-copywriter/profiles/_template.json video-copywriter/profiles/<账号>.json
cp video-copywriter/profiles/_template.md   video-copywriter/profiles/<账号>.md
cp video-pipeline/profiles/_template.json   video-pipeline/profiles/<账号>.json
cp video-pipeline/profiles/_template.md     video-pipeline/profiles/<账号>.md
```

`.md` 里必填：人物外观（会直接注入生成 prompt）、视角与人称、栏目与内容比例、开头库、CTA 节奏。
`.json` 里必填：第 1 节的凭证、第 2 节的路径、`identity.*`（开场钩子校验用）。

详细见 `new-account-guide.md`。

---

## 5. 自检

```bash
node video-pipeline/scripts/setup_check.js --profile <你的账号>
```

它会检查：profile 是否存在、占位符是否替换完、身份图/场景/素材目录在不在、
即梦会话 ID 格式、发布账号 ID 格式、字体目录与 fontconfig、Pillow 是否可用，
以及（默认）即梦是否已登录、目标发布账号是否在线。

**全 PASS 才开工。** 有 FAIL 就照提示补——这些项漏一个，跑到一半才会炸，代价大得多。
