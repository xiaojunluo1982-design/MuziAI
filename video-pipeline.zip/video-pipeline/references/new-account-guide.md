# 新增一个角色 / 账号（通用化手册）

> 2026-09-04 梳理。适用于 `video-copywriter`（文案）+ `video-pipeline`（生产发布）这一套。
> 目的：**换角色只加 profile，不改脚本、不复制分叉。**

---

## 1. 三层架构

| 层 | 内容 | 换角色时要动吗 |
|---|---|---|
| **L0 引擎**（账号无关） | 两个 skill 的 `SKILL.md`、`scripts/*`、`references/{style-guide, prompt-templates, publishing, copy-structures, weekly-plan}.md` | ❌ 不动 |
| **L1 账号配置**（每个 IP 一套） | `profiles/<账号>.md` + `profiles/<账号>.json`（两个 skill 下各放一份，**同名**） | ✅ 新增这两个文件 |
| **L2 账号专属知识**（可选挂件） | 功能×素材映射表、场景清单、背书资产等，命名 `<账号>-*.md` | ✅ 可选 |

L0 里已经参数化、从 profile 读的东西（**换角色自动生效**）：
路径、必填字段、口播时长规范（时长优先制 30-45s/220-330字，2026-10-11 起取代字数三档）、发布账号 ID、即梦会话、生成模型、默认封面/字幕样式、
功能主线是否必填、身份词（2026-09-04 解耦）、字体目录（2026-09-04 解耦）。

---

## 2. 新增角色 · 6 步

### 步骤 1 — 备素材（目录结构要对齐）

```
<项目根>/
├─ <角色>.jpeg          # 身份/脸部基准图，必传
├─ 拍摄场景/            # 真实场景照片（禁止 AI 想象场景）
├─ 视频素材/            # B-roll：聊天截图 / 客户好评 / 自动跟进 / 操作录屏
├─ voice/               # 声音参考 2-15s（真人原声要求时才需要）
└─ output/{周计划,内容包,short_video}/
```

### 步骤 2 — 建 profile（核心动作）

从 `_template` 复制，两份 skill 都要有，文件名一致：

```bash
cd ~/.workbuddy/skills
cp video-copywriter/profiles/_template.json video-copywriter/profiles/<账号>.json
cp video-copywriter/profiles/_template.md   video-copywriter/profiles/<账号>.md
cp video-pipeline/profiles/_template.json   video-pipeline/profiles/<账号>.json
cp video-pipeline/profiles/_template.md     video-pipeline/profiles/<账号>.md
```

`.json` 必填项：

| 字段 | 说明 |
|---|---|
| `paths.*` | 项目根 / 身份图 / 场景目录 / 素材目录 / 三个输出目录。**留空 = 校验跳过文件存在性检查** |
| `identity.name` / `type` | 账号名、`ai_digital_human` 或 `real_person` |
| `identity.selfIntroPatterns` | **禁止出现在第 1 句**的自报家门句式（正则字符串数组） |
| `identity.mentionPattern` | 全篇至少要出现一次的身份词（正则字符串） |
| `identity.requireMention` | 真人号可设 `false`，不做身份交代检查 |
| `publishAccounts.<平台>` | `platformAccountId`，从 `yxer accounts list <平台> --json` 取 |

`.md` 必填项：人物外观（prompt 直接注入）、视角与人称铁律、栏目与内容比例、开头库、CTA 节奏。

### 步骤 3 — 配字体

下载字体要**确认免费可商用**。新角色用自己的字体目录时：

```bash
export VP_FONTS_DIR="<你的字体目录>"      # make_cover.py 读这个环境变量
```

⚠️ 烧字幕走 fontconfig，**必须**把同一目录写进 `C:\Users\user\fonts.conf`：
```xml
<dir><你的字体目录></dir>
```
不然字幕会静默掉回微软雅黑。

### 步骤 4 — 建即梦会话

在即梦里为该角色**单独建会话**，把 session id 填进 profile。
**绝不能混用**——牧子琪的素材跑进晓君总会话是事故级错误。

### 步骤 5 — 查发布账号

```bash
yxer accounts list 抖音   --status 1 --json
yxer accounts list 视频号 --status 1 --json
yxer accounts list 小红书 --status 1 --json
```
确认 `platformAccountName` 与 profile 一致后再填 ID。**发错号比不发严重得多。**

### 步骤 6 — 跑验证（三条，全绿才算通）

```bash
# ① profile 被识别
node ~/.workbuddy/skills/video-copywriter/scripts/validate_package.js --list-profiles

# ② 内容包校验通过（有 ERROR 退出码 1，必须修完）
node ~/.workbuddy/skills/video-copywriter/scripts/validate_package.js "<内容包.json>" --profile <账号>

# ③ 封面脚本能找到字体（字号不是 40/40 就说明字体加载成功）
"C:/Users/<用户名>/.workbuddy/binaries/python/envs/default/Scripts/python.exe" \
  ~/.workbuddy/skills/video-pipeline/scripts/make_cover.py \
  --base <底图.jpg> --line1 "测试" --line2 "字体" --style s1 --out-png _t.png
```

---

## 3. 换电脑 / 换人接手的硬约束

| 项 | 坑 | 解法 |
|---|---|---|
| Python | **系统 `python` 没有 PIL**，`make_cover.py` 直接 `ModuleNotFoundError` | 用 `C:/Users/<用户名>/.workbuddy/binaries/python/envs/default/Scripts/python.exe` |
| 中文路径 | bash 传中文参数给 node 会乱码 | 先 `cd` 进目标目录，用相对文件名 |
| 路径格式 | dreamina 是 Windows 程序，不认 `/g/...` | 一律 `G:/...`（盘符大写 + 正斜杠） |
| preflight | `preflight_check.js` 依赖 `process.cwd()` | 必须从**项目根**跑，否则找不到台账 |
| 发布留痕 | 成功后要同时写台账 + 周计划 | 两处都写，否则重复发布拦截会失效 |

---

## 4. 已清理的耦合（2026-09-04 做完，留档备查）

| 原问题 | 怎么解决的 |
|---|---|
| `muziqi_pipeline.sh` 读 `space-video/profiles/muziqi.json`（跨 skill + 名字写死） | 改为读**本 skill** 的 `profiles/<账号>.json`，新增 `--profile <账号>` 参数（默认 muziqi，也可用环境变量 `PROFILE` 预设）；读取兼容两种结构：优先 `videoGeneration.fallback.*`，回落 `videoGeneration.*` |
| A/B 两套 profile 的 `videoGeneration`、`defaults` 值不一致 | 以 B 套（实测画质更好）+ 9/3 拍板的 s7+t6 为准，**合并进 A 套** `video-pipeline/profiles/muziqi.json`，消除两份真相 |
| `muziqi-function-materials.md` 是牧子琪专属却放通用 `references/` | 移到 `video-copywriter/profiles/`，归位为 L2 专属知识；同步改了 `profiles/muziqi.md`、`muziqi-video-copywriter/SKILL.md`、`pack_skills.py` 三处引用 |
| 脚本里硬编码的身份词、字体目录 | 身份词进 `profile.identity`；字体目录走 `VP_FONTS_DIR` 环境变量 |

**剩余（都是注释级，不影响执行）**：`gen_subtitles.js` / `make_cover.py` / `mosaic_face.py` /
`notify_review.sh` 的文件头注释里仍有「牧子琪」字样；`muziqi_pipeline.sh` 文件名本身带账号名
（改名会断掉 `space-video/profiles/muziqi.md` 和 `G:\牧子琪\scripts\check_week_plan.py` 里的调用，暂不动）。

⚠️ **换角色时记得**：`muziqi_pipeline.sh` 的默认 profile 是 muziqi，跑别的账号必须显式 `--profile <账号>`。

---

## 5. 一句话原则

> 遇到「这个规则只有某个账号才适用」，就把它挪进 profile；
> 只有确认「所有口播短视频都该这样」，才写进 L0 脚本或 references。
> 写进 L0 之前先问一句：换个角色，这条还成立吗？
