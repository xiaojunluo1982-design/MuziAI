# LibTV 备用通道（video-pipeline 上游 · 2026-09-29 建 · 同日首次跑通并回填 · 同日二轮回填 Kling）

> **定位**：即梦（dreamina）额度不足或不可达时的**备用生成通道**。
> 触发口径见 `SKILL.md`「Step 3 · 前置 0：积分预检」。

---

## 0. 一句话结论（先看这个）

| 能力 | LibTV 可用性 | 产线影响 |
|---|---|---|
| **单图参考**（`singleImage2video`）+ Seedance 2.0 Mini | ✅ 可用 | 时长/比例/分辨率**可控**（15s / 9:16 / 720p）→ **可直接替即梦出片** |
| **单图参考** + **Kling O3** | ✅ 可用（10s / 9:16） | 能出片，但**画面近乎静帧、不按 prompt 重绘场景** → 不适合口播（§6） |
| **视频参考**（`mixed2video` / `videoEdit2video`） | ❌ **全模型不可用** | 4 模型 × 2 模式 × 2 素材格式（mov / H.264 mp4）全失败，见 §4 |

🔴 **即：LibTV 通道能出片，但「视频参考」在本通道整体不可用；产线要走单图参考。** 见 §4。

---

## 1. 连接器事实（已实测，可直接引用）

| 项 | 值 |
|---|---|
| 名称 | `LibTV`（自定义连接器，用户级） |
| 端点 | `https://mcp.liblib.tv/mcp` |
| 配置位置 | `~/.workbuddy/mcp.json` → `mcpServers.LibTV` |
| 传输 | `type: "streamable-http"`（Remote MCP） |
| 认证 | **OAuth**（配置里不填任何 key） |
| 授权状态 | ✅ 2026-09-29 09:37 完成 |
| 账号 | `account_user` → `微信用户e62918`（accountId `4050502`），**旗舰版 VIP 12 个月**（`effective: true`） |
| 工具前缀 | `mcp__LibTV__*`（`doctor` 报 48 个工具，`connectionStateReady: true`） |
| 算力池 | **liblib.tv 账号自己的算力** —— 🔴 与即梦**不是同一个池** |
| 项目存放 | 新项目落在当前账号的默认空间；`create_project` 返回 `projectId`(uuid) + `projectContext` |

🔴 **工具可见性是「会话级」的**：授权之后**必须新开会话**才拿得到 `mcp__LibTV__*`。

---

## 2. 上传本地素材 → 资源 URL（三步，已实测）

MCP 没有「直接传文件」的工具，要走**签名分片上传**：

```bash
# ① 取票据
MCP mcp__LibTV__upload_ticket { file_name:"xiaojunzong_identity.mov", file_size:<字节数> }
#   → 返回 { uploadId, path, parts:[{partNumber,url,method:"PUT"}], upload_ref }
#      part_size 默认 5MB（<5MB 只有 1 个 part）；url 带 Expires 签名，别拖延

# ② 逐片 PUT 到 OSS（node fetch 即可，无需额外签名头）
#    参考实现：output/short_video/<日期_场景>/_libtv/upload.js
node upload.js "<本地文件>" "<票据.json>" "<etag输出.json>"
#   → 收集每个 part 的 ETag，打印 UPLOAD_DONE

# ③ 完成上传
MCP mcp__LibTV__upload_complete { path:"<① 的 path>", upload_id:"<① 的 uploadId>" }
#   → 返回 { file_ref, url, path }
#      url = https://libtv-res.liblib.art/upload-images/<userUuid>/<sha1>.<ext>
```

- **ETag 不用回传**（`upload_complete` schema 只要 `path` + `upload_id`，服务端自己 ListParts）。
- 🔴 **`file_ref` 是一次性/短期的**：随后拿它调 `resource_info` 会报 `invalid opaque token`。**能长期用的是返回里的 `url` + OSS 文件名里的 40 位 `sha1`**（`resourceMeta.hashSha1` 就用它）。
- 上传目录名是 `upload-images/`（**图片和视频都走这一个目录**，不要被名字误导）。

---

## 3. 建节点 + 触发生成（🔴 本节是踩坑最重的地方）

### 3.1 素材节点的 `nodeType` 决定它是「素材」还是「生成节点」

| nodeType | 系统自动给的 `data.action` | 能否被引用为素材 |
|---|---|---|
| `image` | `image_resource` | ✅ |
| **`video-clip`** | **`video_clip_resource`** | ✅ **视频素材必须用这个** |
| `video` | `video_generate` | ❌ 被当成"待生成"节点 → 引用时派生出的 `url` 是**空串** |

实测事故：用 `nodeType:"video"` 建素材节点，`read_node` 里 `data.url` 明明有值、`inspect_media` 也报
`persistedUrlCount: 1`，但生成节点派生出的 `videoList[0].url = ""` → 预检报
`视频引用 <nodeId> 没有可用的 url 或 assetId`。换成 `video-clip` 后同样位置立刻带上 url。

🔴 **`data.action` / `data.type` 都不能手改**（`NODE_PATCH_INVALID: 节点 data.action 不可通过 CLI 变更`）——
**只能在创建时靠 `nodeType` 定**。传 `data.type` 与 `nodeType` 不一致也会被拒。

素材节点可带上（与官方既有项目同构）：

```json
{
  "nodeType": "video-clip",
  "name": "晓君总形象参考片",
  "data": {
    "url": ["https://libtv-res.liblib.art/upload-images/<uuid>/<sha1>.mov"],
    "alt": "晓君总形象.mov",
    "resourceMeta": { "items": [{
      "kind": "video", "mimeType": "video/quicktime", "byteSize": 7978891,
      "extension": "mov", "hashSha1": "<40位>", "width": 720, "height": 1280 }] }
  }
}
```

### 3.2 生成节点：媒体靠 `left` 引用边派生，**不能写进 params**

```json
{
  "nodeType": "video",
  "name": "seq2-p1",
  "left": ["v-sBmh27g9rm"],          // ← 引用素材节点（引用边）
  "params": {
    "model": "Seedance 2.0 Mini",     // 传完整展示名
    "modeType": "singleImage2video",
    "prompt": "…",
    "ratio": "9:16", "resolution": "720p", "duration": 15, "enableSound": "on"
  },
  "run": true
}
```

- 🔴 **禁止**在 `params` 里写 `imageList/videoList/audioList/*Order` —— 那些由引用边派生（写了会被拒）。
- `params` 会被归一化进节点的 `params.settings`。
- `run:true` 返回的是 **`status:"accepted"` + `task_id`（异步）**，不是阻塞等待。
  查结果：`task_status { project_id, task_id }` → `readiness: PROCESSING → …`；
  产物落到节点上，用 `read_node` / `inspect_media` / `show_generation_result` 看。
- 也可以用 `generate_video`（入口更"正统"，会自己收敛 mode）：`mode:"auto"` + `referenceImageNodes/referenceVideoNodes`。
- 🔴 **`generate_video` 用 `run:false` 预检也会真的建节点**（占住显示名）→ 随后 `run:true` 同名
  会报 `VIDEO_PREFLIGHT_FAILED: 已存在显示名为「x」的节点`。**每次提交都换新名字**。
- 🔴 **`generation_submit` 的 `source_node_keys` 必须是字符串**（`"v-xxx"`），传数组直接参数校验失败。

### 3.3 参数必须落在该 mode 的 settings 白名单内（**报错只说"不在允许范围"**）

`get_model` 的 `config.settings.<mode>` 就是白名单。实测：

- `singleImage2video`：`[ratio, resolution, duration, enableSound]` → 可控 ✅
- `videoEdit2video`（2.5 / Happy Horse）：**只有 `[resolution]`** → 传 `ratio/duration` 直接报
  `params.settings.duration=15 不在允许范围。可选: 0; params.settings.ratio="9:16" 不在允许范围。可选: adaptive`
- **Kling O3 `mixed2video`**：`[ratio, duration, quality_4k, enableSound, smartStoryboard]` → **ratio/duration 可控**
  （`settingsRules` 另定：`videoList` 非空时 `duration.max = 10`；参考视频须 3–10s、mp4/mov、高 720–2160）

---

## 4. 🔴 「视频参考」全模型实测不可用（2026-09-29 两轮共 12 次失败）

| # | 模型 | 入口 | modeType | 结果 |
|---|---|---|---|---|
| 1 | Seedance 2.0 Mini | `validate_generation_plan` | auto→mixed2video | ✅ `valid:true`（**注意：预检过≠能提交**） |
| 2 | Seedance 2.0 Mini | `generate_video` run=true | auto | ❌ `INVALID_ARGUMENT` |
| 3 | Seedance 2.0 Mini | `create_node` run=true | mixed2video | ❌ `INVALID_ARGUMENT` |
| 4 | Seedance 2.0 Mini | `update_node` run=true | （沿用） | ❌ `INVALID_ARGUMENT` |
| 5 | Seedance 2.0 Mini | `generation_submit` | mixed2video（最小参数） | ❌ `INVALID_ARGUMENT` |
| 6 | Seedance 2.5 | `generate_video` / `create_node` | mixed2video | ❌ `INVALID_ARGUMENT` |
| 7 | Seedance 2.5 | `generate_video` | videoEdit2video | ❌ 参数超范围 → 去掉后 `LibTV video: failed.` |
| 8 | **Kling O3** | `validate_generation_plan` | mixed2video | ✅ `valid:true`、`usableCount:1`（**预检过仍然提交失败**） |
| 9 | **Kling O3** | `generate_video` run=true | mixed2video（9:16 / 10s） | ❌ `LibTV video: failed.` |
| 10 | **Kling O3** | `generate_video` run=true | mixed2video（**换 H.264 mp4 参考片**） | ❌ `LibTV video: failed.`（**排除编码/封装因素**） |
| 11 | **Kling O3** | `generate_video` run=true | videoEdit2video（5s） | ❌ `LibTV video: failed.` |
| 12 | Kling O3 | `generation_submit` | mixed2video（`source_node_keys` 传字符串） | ❌ `INVALID_ARGUMENT: Task arguments were rejected` |
| — | Seedance 2.0 Mini | `create_node` run=true | **singleImage2video（图参考）** | ✅ **accepted，正常生成** |
| — | **Kling O3** | `generate_video` run=true | **singleImage2video（图参考）** | ✅ **completed，正常生成** |

**判定（已收敛）**：
1. **不是参数问题** —— Kling 的 mixed2video 白名单里有 `ratio/duration`，参数完全合规，预检 `valid:true`。
2. **不是素材格式问题** —— mov（7.4s）与转码后的 H.264 mp4 表现完全一致。
3. **是平台侧限制** —— 服务端对「视频作为生成输入」的资产化未打通：图片在提交时会被转成
   `asset://asset-*` 资产并成功入队；**视频走到这一步就 `LibTV video: failed.`**（`generate_video` 不外抛细节）。
4. 图中 `Kling` / `Hailuo` 还在 `videoGeneration.forbidden` 禁用名单内（`profiles/*.json`），本次是**特批样片实验**。

🔴 **推论：不要在 LibTV 上再试视频参考**（12 次已闭环）。
若确需视频参考，只能：① 回即梦；② 向 liblib 反馈「视频输入资产化失败」并确认是否需单独开通。

---

## 5. 不走样的约束（与即梦通道一致，换通道也不许变）

- 🔴 **`segment_materials` 一律不参与生成** —— 素材插片只在后期 `ffmpeg overlay` 叠加。
- 🔴 **素材严格按产品线归属**，跨线不得顶替；内容线当前无素材 → 素片出片。
- 🔴 ~~part2+ 用 part1 打码帧锁一致性~~ → **图参考模式下改为：全段共用同一张本人形象图 +
  同一段场景/着装文字**；part1 出片后可再抽帧作为 part2+ 的**补充参考图**（`image2video` 支持多图 1~9）。
- 🔴 结尾 CTA 钩子关键词取条目 `ctaKeyword`；禁词在**写文案阶段**先扫，FAIL 不发布、不降级。
- 🔴 **prompt 里的"参考视频/参考图片"措辞必须与实际参考形式一致**（图参考就写"参考图片"），
  否则模型可能按不存在的视频去理解。

---

## 6. 模型选型实测观感（2026-09-29 样片对比）

同一张 `晓君总形象.jpg`（围巾 + 深色毛衣，抽帧自 `晓君总形象.mov`）、同一段 prompt、同为 9:16：

| 维度 | **Kling O3**（10s） | **Seedance 2.0 Mini**（15s） |
|---|---|---|
| 场景重绘 | ❌ **几乎原样复刻参考图**（木质柜、桌面、手持笔），prompt 里写明的「办公桌 / 笔记本 / 显示器 / 台灯」**没建出来** | ✅ 按 prompt 重建了办公桌场景（显示器、台灯、笔记本都在） |
| 动作幅度 | ❌ **近乎静帧**，3 个时间点（1s / 5s / 9.5s）画面几乎一致，只有嘴部微动 | ✅ 有自然手势与身体姿态变化 |
| 着装 | ⚠️ 沿用参考图的围巾 + 毛衣 | ⚠️ 同样沿用参考图的围巾 + 毛衣 |
| 口播适用性 | ❌ 差（像"给照片加了点动效"） | ✅ 可用 |

🔴 **两条硬结论**：
1. **口播出片不要用 Kling O3** —— 它把图生视频做成了"微动照片"，不重绘场景、不做动作。
2. ⚠️ **「着装」和「场景」必须分开看，别混为一谈**（2026-09-30 二轮实测修正 ——
   本节原先写成"着装与背景一起带过来、prompt 不生效"，那是**把两者混了**，与上表第 1 行自相矛盾）：

   | 要素 | 能否靠 prompt 改 | 依据 |
   |---|---|---|
   | **着装**（衣服） | ❌ **改不掉**，两个模型都沿用参考图的衣服 | 09-29：围巾 + 毛衣原样带过来；09-30：米白衬衫原样带过来 |
   | **场景/背景** | ✅ **Seedance 能按 prompt 重建**（Kling 不能） | 09-30 实测：同一张「灰色无缝幕」参考图，Seedance 把背景换成了 prompt 里写的办公室 |

   → **要换着装只能换 `identityImage` 那张图**（靠文字没用）；
   **要换场景直接写 prompt，不必预生成场景图**（只有 Kling O3 才需要预生成场景图）。

---

## 7. 本地图 → 公网 URL：`apiz upload`（2026-09-30 实测）

图生图（`singleImage2video` 的参考图，以及 apiz 的 `--image-url`）**只吃公网 URL**，不吃本地路径。
把本地图换成 URL 最省事的路子是 **apiz 自己的 `upload` 子命令 —— 免费、不计积分**：

```bash
apiz upload <本地文件>          # 默认落到 storage/cli-uploads/<yyyymmdd>/
```

返回（🔴 **字段是 `public_url`，不是 `url`** —— 2026-09-30 就是因为写错这个键，
helper 空转了整整两轮重试，表现得像"上传很慢"）：

```json
{ "id": 25742,
  "public_url": "https://cdn-hk.51sux.com/storage/cli-uploads/20260930/<md5>.jpg",
  "file_key": "storage/cli-uploads/20260930/<md5>.jpg",
  "file_name": "…", "file_size": 173598, "content_type": "image/jpeg", "folder": "cli-uploads" }
```

封装在 `apiz_gen.upload_local(path)`（公共实现，**别再写第二份**）：按候选键
`public_url / url / publicUrl / downloadUrl / cdn_url` 逐个兜，并对（路径 + 大小 + mtime）缓存 ——
同一张图不重复上传。

⚠️ 上传不花钱，**可以放心重试**；这与 `generate` 的「提交只试一次，重试＝重复扣费」正好相反。

---

## 8. 官方形象是「插画」怎么接：⚠️ 本节结论已被 2026-10-04 实测**部分推翻**（见 §8.1）

> 🔴 **先读 §8.1**。本节的「插画锁不住脸」是 **apiz `nano-banana-pro` 图生图**上的结论，
> **不适用于 LibTV / Seedance** —— 拿它当「不许用插画做参考图」的依据是**错的**。
> 本节保留，只作为「apiz 图生图这条路不要用」的记录。

坑的形态：品牌方的形象资产是**插画**（例：牧子数智的 `营销素材/牧子琪形象.png`，
彩铅质感 + 客厅背景）。直接拿它当图参考 → LibTV 会连「插画风格 + 客厅背景」一起复刻。

但 2026-09-30 实测还挖出一层更硬的限制 —— **图参考根本不负责锁身份**：

> 拿插画当源图、同一段 prompt、同一个构图，连出 4 张
> （`fal-ai/nano-banana-pro` + apiz `--image-url`，9:16，共 240 积分）：
> **4 张是 4 个完全不同的人** —— 连人种都不稳定（3 张欧美面孔、1 张东亚面孔）、
> 发型/年龄/脸型全不对。场景倒是严格照 prompt 建出来了（笔记本/马克杯/绿植/浅木桌全在）。
>
> **判读**：模型把插画当"气质参考"，重新发明了一张脸。**插画 → 写实 ≠ 同一个人。**
> 这是模型能力边界，不是 prompt 能修的（prompt 里已明确写"严格沿用参考图五官、不改身份"）。

**正解 —— 身份源必须是「写实照片」**：

```
（若手上只有插画）
插画 ──找一张气质对的写实脸──► 人选定稿 ──► 冻成写实定妆图 = 唯一身份源
                                                    │
                              ┌─────────────────────┘
                              ▼
              写实定妆图 ──(apiz 图生图: 保脸换场景)──► 场景板 × N ──► LibTV 单图参考
```

捷径：**别自己造那张脸**。牧子数智本机已有现成的写实定妆照
（`output/_probe_out/_未采用-定妆照方案/定妆照/*.png`，1728×2304、正面、四张同一张脸，
米白丝衬衫 + 领夹麦 + 浅灰无缝背景）→ 直接拿来当身份源最省事也最一致。

实现：`800官网推广/scripts/gen_oral_portrait.py`，**两种模式别用错**：

| `--subject` | 源图 | 用途 |
|---|---|---|
| **`photo`（默认，产线用）** | 写实照片 | **保持那张脸 / 发型 / 着装，只换场景** —— 用它攒「场景板库」 |
| `illustration` | 插画 | 只用来"先找一张脸"，⚠️ **锁不住身份**，出图后人选定稿并立刻冻成写实图 |

- `--n=4` 出候选（挑脸）→ 人选定稿 → 落盘为**长期身份图**（`identityImage`）；
- `--src=<写实定妆图> --scene=bookshelf|meeting|window` → **换场景保脸**；
- photo 模式的 prompt 把「身份锁定」写成**最高优先级**，并明写
  「**宁可场景差一点，也不许动这张脸**」—— 这条比罗列五官更有用。

🔴 四条纪律：
1. **只有写实源能锁脸**；插画源只能用来找脸。
2. **换场景 → 改 prompt（Seedance）；换着装 → 换图**（见 §6 第 2 条）。
   ⚠️ 别倒过来：prompt 改不掉衣服，换图也白搭换不了场景。
3. **AI 生成的场景必须人眼验收**（脸有没有变 / 多手多字 / 一眼假）才许落库 ——
   无人值守任务**不得自动采纳**未验收的图。
4. ⚠️ **本条已作废（2026-10-04 实测推翻，见 §8.1）**：原写「插画**永远不直喂** LibTV」。
   实际 **Seedance 2.0 Mini 拿插画做单图参考锁脸成立**；`scripts/check_oral_assets.js` 的护栏
   也已改成「插画 + `identityImageLocked:true` = PASS」，别再拿这条拦插画。

---

## 8.1 🔴（2026-10-04 补）**插画做单图参考也能锁脸 —— 推翻本节前述结论**

上面那套「插画锁不住脸 → 必须用写实照」是在 **apiz `nano-banana-pro` 图生图**上得出的。
**LibTV 的 Seedance 2.0 Mini 是另一套机制**，2026-10-04 实测：

| 项 | 值 |
|---|---|
| 参考图 | `D:/牧子数智/营销素材/牧子琪形象.png`（**彩铅插画**，990×1706 rgba，sha1 `29b622ddc7e1…ac15f3`） |
| 模型 / 模式 | `Seedance 2.0 Mini` / `singleImage2video` → 9:16 / 720p / 15s |
| 结果 | ✅ **单条内与插画同一张脸**；连插画那件**白 T 造型**都带过来；插画里的客厅 / 白猫 / 落地灯**被丢掉**，场景按 prompt 重建成写实办公室；写实质感干净；口型在动 |
| 跨次一致性 | ✅ 同 prompt 连出两条 → **是同一个人** |

**用法（本线现行口径）**：插画**可以**直接当 `identityImage`，但 prompt 第一段**必须**带一句

> 参考图片中的这位女性（**参考图为手绘彩铅插画，请把她的外形还原为真实人物的写实摄影，
> 不要保留手绘、插画、绘画笔触质感**），……

—— 不带这句才可能输出插画风。`800官网推广` 的 `scripts/stage_oral_payload.js` 已按
「`identityImage === illustrationRef` 时自动插入该句」实现，不用手写。

带来两条认识修正：
1. **图参考不负责锁身份**这句只在 apiz 那条路成立；LibTV 单图参考（`{{Portrait 1}}` 人物位绑定）是锁的。
2. 插画自带**造型**（白 T + 披发 + 休闲感）→ 走插画这条就不必再用 `gen_oral_portrait.py` 花积分换造型。

⚠️ 唯一不变的是：**着装跟着参考图走、prompt 改不掉**（§6 第 2 条），插画穿什么，成片就穿什么。

---

## 9. 🔴 单图参考**锁得住脸**（2026-09-30 端到端实测 · 与 §8 的 apiz 结论互补）

§8 的"锁不住脸"是 **apiz 图生图**（`fal-ai/nano-banana-pro` + `--image-url`）的结论。
**LibTV 的 `singleImage2video` 是另一回事 —— 它锁得住。** 两者别混。

**实测**（`800官网推广/_临时/oral/2026-09-30/`）：

| 项 | 值 |
|---|---|
| 参考图 | `D:/牧子琪/定妆/牧子琪-定妆-基准.jpg`（写实定妆照，1728×2304，浅灰无缝背景） |
| 模型 / 模式 | `Seedance 2.0 Mini` / `singleImage2video` → 9:16 / 720p / 15s |
| prompt | 只描述**场景**（办公室桌）+"保持参考图同一张脸/发型/衣服" |
| 结果 | ✅ **第 0s / 7.5s / 14.5s 三帧同一个人**，五官/发型/米白衬衫/领夹麦/珍珠耳钉全部与参考图一致；**背景从"灰色无缝幕"被重建成真实办公室**；有自然手势 |

比对图：`_临时/oral/2026-09-30/face_cmp2.jpg`（左=基准图，中/右=成片第 0s / 14.5s）。

**机制（read_node 看出来的，值得记）**：平台把 `singleImage2video` **自动转成 `mixed2video`**，
并把参考图注册为 `asset://asset-<ts>-<rand>`，prompt 被平台**前置了 `{{Portrait 1}}` 占位符**：

```
"{{Portrait 1}} 参考图片中的这位女性（米白色衬衫…）正对镜头…"
```

→ `{{Portrait 1}}` 就是「**人物位绑定**」，这是它锁脸的原因。
（对照：`taskParams.imageList` 是**空的**，真正生效的是 `imageListV2` 与 `mixedList` ——
所以手工拼 payload 时别看 `imageList`。）

**推论**：
- ✅ **锁脸 = 拿现成写实定妆照直接当 LibTV 单图参考**，不用生成、不用转换。
- ✅ **换场景 = 写 prompt**（§6 第 2 条），场景**不用预生成图片**。
- ❌ 别再用 apiz 图生图去"造"一张脸或换场景 —— 那条路验证过，锁不住（§8）。
