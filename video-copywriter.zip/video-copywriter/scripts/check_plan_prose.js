#!/usr/bin/env node
/* check_plan_prose.js · 周计划文案去 AI 味检查（video-copywriter）
 *
 * 用途：把周计划各条 segments 导出为纯文本，交给 human-writing 的 check_prose.py 检查。
 *      用于「文案 AI 味太重」的例行复查（2026-09-21 晓君总要求：定稿前走一遍去 AI 味 skill）。
 *
 * 用法：
 *   node check_plan_prose.js <周计划.json> [--include-published]
 *
 * 判定口径（新写条目，即 status != "published"）：
 *   · 功能性冒号 0 处（只有引述别人原话才允许冒号）
 *   · 翻案腔 0 处（「不是 A 是 B」「你以为…其实」「不在于…而在于」）→ 直接写正面陈述
 *   · 语气词 ≥3 处（对吧 / 呢 / 啊 / 哈 / 其实 / 你看 / 你想想）—— 口语化硬要求
 *   · AI 腔症状 0 处（书面连接词 / 套话 / 破折号 / ≥42 字长句）—— 2026-10-10 新增（WARN）
 *   ⚠️ 已发布条目（status=published）改不动，默认跳过，不参与判定。
 *   ⚠️ 剩下的「排比三连 / 形容词堆砌」脚本查不了，靠人工「读出声」——
 *      清单见 references/anti-ai-tone.md。
 *
 * 脚本只做检查与报告，不改任何文件。
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const planPath = process.argv[2];
if (!planPath) {
  console.error('用法：node check_plan_prose.js <周计划.json> [--include-published]');
  process.exit(2);
}
const includePublished = process.argv.includes('--include-published');

// ---- python 候选链（本机 PATH 里没有 python，不要只认裸命令名）----
const resolvePython = () => {
  const cands = [
    process.env.VP_PYTHON,
    'C:/Users/admin/.workbuddy/binaries/python/envs/default/Scripts/python.exe',
    'C:/Users/admin/.workbuddy/binaries/python/versions/3.13.12/python.exe'
  ].filter(Boolean);
  for (const c of cands) if (fs.existsSync(c)) return c;
  console.warn('[WARN] 未找到托管 python，回退裸命令 python（可能失败）');
  return 'python';
};
const CHECKER = 'C:/Users/admin/.workbuddy/skills/human-writing/scripts/check_prose.py';

const plan = JSON.parse(fs.readFileSync(planPath, 'utf8'));
const lines = [];
const skipped = [];
const tone = {};
const bodies = {};
const segList = [];

for (const e of plan.entries || []) {
  const isPub = e.status === 'published';
  if (isPub && !includePublished) { skipped.push(e.seq); continue; }
  lines.push(`# seq${e.seq} ${e.date || ''} ${e.title || ''}${isPub ? ' [已发布]' : ''}`);
  (e.segments || []).forEach((s, i) => { lines.push(s); segList.push({ seq: e.seq, idx: i + 1, text: s }); });
  lines.push('');
  const body = (e.segments || []).join('');
  bodies[e.seq] = body;
  tone[e.seq] = (body.match(/对吧|呢|啊|哈|其实|你看|说实话|你想想|你说是不/g) || []).length;
}

const out = path.join(os.tmpdir(), 'plan_prose_check.txt');
fs.writeFileSync(out, lines.join('\n'), 'utf8');

console.log(`导出：${out}`);
console.log(skipped.length ? `已跳过已发布条目：seq${skipped.join(' / seq')}` : '（无已发布条目）');
console.log('\n语气词计数（要求 ≥3）：');
for (const [seq, n] of Object.entries(tone)) {
  console.log(`  seq${seq}: ${n} 处 ${n >= 3 ? '✓' : '✗ 需补语气词'}`);
}

// ---- AI 腔症状扫描（可正则化的四类，逐段查，WARN 不阻断）----
// 来源：2026-10-10 对标 space-video-script 固化，清单见 references/anti-ai-tone.md
const SYMPTOMS = [
  { name: '书面连接词', re: /不仅[^。！？；\n]{0,24}(?:而且|还|也)|首先[^。！？；\n]{0,12}其次|其次[^。！？；\n]{0,12}(?:最后|再者)/g, hint: '换口语过渡：「然后」「你看」「问题来了」' },
  { name: '套话', re: /值得注意的是|综上所述|综上|由此可见|毋庸置疑|这意味着|总而言之|总的来说|换句话说/g, hint: '直接删或换大白话' },
  { name: '破折号', re: /——|—{2,}/g, hint: '念不出来的标点改成口语插入' },
  { name: '长句无断', re: /[^。！？；，、\n]{42,}/g, hint: '一口气念不完，拆短句（一句一个意思）' }
];

console.log('\nAI 腔症状扫描（要求全部 0 处）：');
const symHits = [];
for (const s of segList) {
  const hits = [];
  for (const x of SYMPTOMS) {
    const m = s.text.match(x.re);
    if (m && m.length) hits.push(`${x.name}×${m.length}（${x.hint}）`);
  }
  if (hits.length) symHits.push({ seq: s.seq, idx: s.idx, hits });
}
if (!symHits.length) {
  console.log('  ✓ 未发现症状（仍需人工「读出声」复核 排比三连 / 形容词堆砌，见 references/anti-ai-tone.md）');
} else {
  for (const h of symHits) console.log(`  seq${h.seq} 段${h.idx}: ✗ ${h.hits.join('；')}`);
  console.log('  ⚠️ 命中项请对照 references/anti-ai-tone.md 逐条改后重跑。');
}

if (!fs.existsSync(CHECKER)) {
  console.error(`\n[ERROR] 找不到检查脚本：${CHECKER}`);
  process.exit(1);
}
const py = resolvePython();
console.log(`\n运行检查：${path.basename(CHECKER)}\n${'-'.repeat(60)}`);
const r = spawnSync(py, [CHECKER, out], { encoding: 'utf8' });
process.stdout.write(r.stdout || '');
if (r.stderr) process.stderr.write(r.stderr);
console.log('-'.repeat(60));
console.log('提示：上面「需要修改」里若只提到第 2-4 行（seq1 已发布），属预期 —— 新写条目应清零。');
