#!/usr/bin/env node
/**
 * 周计划 JSON 校验（账号无关，按 profile 适配）。
 *
 * 为什么需要它：
 *   `validate_package.js` 只校验「内容包」，而每日 05:00 的自动化实际是
 *   **直接读周计划当天条目进生产**（不生成内容包）——出口没有任何闸门。
 *   本脚本补的就是这一段：把生产必需的字段与硬约束前移到周计划生成时挡住。
 *
 * 用法：
 *   node validate_plan.js "<周计划.json>" --profile xiaojunzong
 *   node validate_plan.js "<周计划.json>" --profile xiaojunzong --schema-report
 *
 * 依据：video-copywriter/references/weekly-plan.md §3（周计划字段表）
 *      + video-pipeline/SKILL.md Step 1（生产实际消费的字段）
 *      + profiles/<账号>.json（requiredFields / sceneMode / weeklyLayout）
 *
 * 有 ERROR 退出码 1；只有 WARN 退出码 0。
 */
const fs = require('fs');
const path = require('path');

const SKILL_DIR = path.resolve(__dirname, '..');
const PROFILE_DIR = path.join(SKILL_DIR, 'profiles');
const argv = process.argv.slice(2);

const file = argv.find(a => !a.startsWith('--'));
const pIdx = argv.indexOf('--profile');
const profileName = pIdx >= 0 ? argv[pIdx + 1] : (process.env.VW_PROFILE || null);
const schemaReport = argv.includes('--schema-report');

if (!file) { console.error('用法: node validate_plan.js <周计划.json> --profile <账号>'); process.exit(2); }
if (!profileName) { console.error('需要 --profile <账号>'); process.exit(2); }
const profilePath = path.join(PROFILE_DIR, profileName + '.json');
if (!fs.existsSync(profilePath)) { console.error('profile 不存在: ' + profileName); process.exit(2); }

const profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
const plan = JSON.parse(fs.readFileSync(file, 'utf8'));
const entries = plan.entries || plan.items || (Array.isArray(plan) ? plan : []);

console.log(`profile: ${profile.displayName || profileName}  (${profileName})`);
console.log(`计划: ${path.basename(file)}  条目 ${entries.length} 条`);

const errors = [], warns = [];
const E = m => errors.push(m), W = m => warns.push(m);
const cn = s => String(s || '').replace(/\s/g, '').length;
const norm = s => String(s || '').replace(/[\\/]+/g, '/');

// ---- 素材产品线归属（2026-09-21 晓君总指令）----
// 现有素材基本都属「私域智能体」；「获客内容自动生产线」暂无素材，不许拿私域线素材顶替。
// 跨线顶替 = 拿别条线的证据冒充本条线的效果，属造假证据，必须拦。
const LINE_NAME = { 'content-line': '获客内容自动生产线', 'private-domain': '牧子AI·私域智能体' };
const MATERIAL_LINE_HINTS = [
  // content-line：2026-09-28 素材补齐（微云 MUZIAI/自动内容生产线/内容生产线素材/ → 营销素材/内容生产线素材/）
  // 台账 `营销素材/_素材归属清单.md` 已登记归属，本条线从「素片出片」升级为「按功能插真实录屏」。
  // ⚠️ 必须排在私域线规则之前：下列文件名含「工作流/知识库/提示词/素材库/视频号录屏」等词，
  //    若先命中 /录屏\/.../ 会被误判成 private-domain（跨线误报）。
  { re: /^内容生产线素材\//, line: 'content-line' },
  // 笔记录屏（2026-10-19 新增）：CTA「评论区打111，领取笔记」的画面证据，两条线各一份，不得互借。
  //   内容线 = 内容生产线素材/内容生产线落地笔记.mp4（上方规则已覆盖）
  //   私域线 = 录屏/私域智能体落地笔记.mp4（微云 MUZIAI/私域智能体/ 落盘，2026-10-19）
  { re: /录屏\/(私域智能体)?落地笔记/, line: 'private-domain' },
  { re: /(客户好评|聊天截图|自动跟进|朋友圈评论)\//, line: 'private-domain' },
  { re: /录屏\/.*(微信|后台多微信|自动跟进|24\s*小时在线|跟进计划|朋友圈同步|牧子琪|工作流|知识库|素材库|提示词|视频号录屏|标签变更|AI对话效果|Ai对话发文件|聊天录屏)/, line: 'private-domain' },
  // 私域线（2026-09-21 晓君总确认）：营销素材根目录下 客户好评/聊天截图/自动跟进/朋友圈评论/录屏/品牌物料
  // 全部属于私域线。新增素材线一律先登记 营销素材/_素材归属清单.md，再在此追加规则。
];
const lineOfMaterial = f => {
  const p = norm(f);
  for (const h of MATERIAL_LINE_HINTS) if (h.re.test(p)) return h.line;
  return null; // 未登记归属 -> 不判定，改出 WARN 提醒登记
};
const lineOfEntry = e => {
  if (e.productLine) return e.productLine;
  const t = `${e.column || ''} ${e.product_link || ''}`;
  if (/内容自动生产线|获客内容/.test(t)) return 'content-line';
  if (/私域智能体/.test(t)) return 'private-domain';
  return null;
};

// ============ 0. 字段别名映射（当前实产格式 → 标准字段名）============
// 实际周计划曾出现 type/opening/title/segments/ctaType 等自创名，
// 规范名见 weekly-plan.md §3。这里做兼容读取，缺哪个就报哪个。
// 顶层 productionDefaults 提供整周共用的 scene / outfit_action / platforms，
// 条目自身字段优先，缺则回落到顶层默认（避免同一段长文本在 7 条里重复 7 遍）。
const DEFAULTS = plan.productionDefaults || {};
const pick = (e, ...names) => {
  for (const n of names) if (e[n] !== undefined && e[n] !== null && e[n] !== '') return e[n];
  return undefined;
};
const toStd = e => ({
  weekday: pick(e, 'weekday'),
  date: pick(e, 'date'),
  column: pick(e, 'column', 'type'),                       // 周计划栏/类型
  content_type: pick(e, 'content_type', 'type'),
  hot_signal: pick(e, 'hot_signal', 'materialSource'),     // 选题依据
  angle: pick(e, 'angle_第一人称', 'angle'),
  product_link: pick(e, 'product_link'),
  title: pick(e, 'title', 'title_draft'),
  cover_title: pick(e, 'cover_title'),
  segments: pick(e, 'segments'),
  script: pick(e, 'script'),
  cta: pick(e, 'cta'),
  ctaType: pick(e, 'ctaType'),
  // 2026-10-04 修：条目级 ctaKeyword 是**设计上的覆盖点**（profile §extra.ctaMix/_ctaHookKeywordNote
  // 明确写「条目级 ctaKeyword 可覆盖本条」），但 toStd 之前没带这个字段 →
  // 第 336 行 `e.ctaKeyword || profile.extra.ctaHookKeyword` 永远取不到条目值，
  // 于是「按 profile 池校验」把已经换成新池的条目全判成 ERROR（09-29 起累积 7 条/周）。
  // 补上后：条目自带 ctaKeyword 优先，没写才回落 profile 池。
  ctaKeyword: pick(e, 'ctaKeyword'),
  scene: pick(e, 'scene') || DEFAULTS.scene,
  outfit_action: pick(e, 'outfit_action') || DEFAULTS.outfit_action,
  material: pick(e, 'material'),
  segment_materials: pick(e, 'segment_materials'),
  platforms: pick(e, 'platforms') || DEFAULTS.platforms,
  hold: e.hold
});

// ============ 1. 顶层结构 ============
for (const k of ['weekStart', 'weekEnd', 'account', 'profile', 'topic', 'approved', 'publishMode']) {
  if (plan[k] === undefined || plan[k] === null) E(`顶层缺字段: ${k}`);
}
if (plan.profile && plan.profile !== profileName) {
  E(`顶层 profile="${plan.profile}" 与 --profile ${profileName} 不一致（生产会读错账号配置）`);
}
if (plan.approved !== true && plan.publishMode === 'auto') {
  E('publishMode=auto 但 approved 不为 true——闸门口径是「生成即 approved=true，唯 hold 叫停」');
}
// weekStart 必须是周一
if (plan.weekStart) {
  const d = new Date(plan.weekStart + 'T00:00:00');
  if (d.getDay() !== 1) E(`weekStart=${plan.weekStart} 不是周一（${'日一二三四五六'[d.getDay()]}），日期锚点错会导致 05:00 找不到文件`);
  else console.log(`weekStart ✓ ${plan.weekStart}（周一）`);
}
if (!entries.length) { E('entries 为空'); }
if (entries.length && entries.length !== 7) W(`entries ${entries.length} 条，标准是 7 条（整周）`);

// ============ 2. 逐条：字段完整性 ============
// 生产必需（video-pipeline Step 1 实际消费的）
const PROD_REQUIRED = [
  ['title', '标题', 'title/title_draft'],
  ['cover_title', '封面两行文案', 'cover_title'],
  ['segments 或 script', '口播正文', 'segments[]/script'],
  ['scene', '场景', 'scene（model_generated 时为文字描述）'],
  ['outfit_action', '着装动作三要素', 'outfit_action'],
  ['cta', 'CTA 话术', 'cta（不是 ctaType 类型名）'],
  ['platforms', '发布平台', 'platforms'],
];
// 选题管理必需
const PICK_REQUIRED = [
  ['column', '栏目', 'column'],
  ['content_type', '内容类型', 'content_type'],
  ['hot_signal', '选题依据', 'hot_signal'],
  ['angle', '第一人称切入角度', 'angle_第一人称'],
];

// ============ 三线内容分工（2026-10-09 晓君总指令）============
// 每条短视频必须标注它属于哪条线（流量型 / 人设型 / 获客型），且用对应 muzi-* 技能生成。
// 三线职责（晓君总原话）：
//   流量型 flow     = 让人「看到」我 → 取悦用户、蹭热点、戳痛点、出圈
//   人设型 persona  = 让人「喜欢」我 → 产品好、人品好、服务/交付好
//   获客型 lead     = 让人「愿意链接我」→ 秀结果、秀过程、秀解决方案、引留资
const CONTENT_LINES = {
  flow: '流量型',
  persona: '人设型',
  lead: '获客型',
  product: '产品型',
};
const LINE_ALIASES = {
  '流量': 'flow', '流量型': 'flow',
  '人设': 'persona', '人设型': 'persona',
  '获客': 'lead', '获客型': 'lead',
  // 2026-10-19 晓君总指令：人设型可暂时撤下、换成产品型（product-suspense 制造悬念+演示）
  '产品': 'product', '产品型': 'product', '产品演示型': 'product', '演示型': 'product',
};
const normLine = v => {
  const s = String(v || '').trim();
  if (CONTENT_LINES[s]) return s;                          // 已是枚举值 flow/persona/lead/product
  return LINE_ALIASES[s] || null;                           // 中文别名 → 枚举值
};
// 旧 content_type（产品场景型/痛点型/案例转化型…）到三线的兜底映射，用于未写 line 的存量计划告警
const contentTypeToLine = t => {
  const s = String(t || '');
  if (/人设|故事|日常|复盘|观点|态度/.test(s)) return 'persona';
  if (/演示/.test(s)) return 'product';                    // 「产品演示型」= 产品型，不再落到获客型
  if (/痛点|案例|产品|转化|场景/.test(s)) return 'lead';
  if (/流量|认知|热点|涨粉|出圈/.test(s)) return 'flow';
  return null;
};

// ---- 口播规范：时长优先制（2026-10-11 晓君总指令，旧「字数三档」作废；2026-10-23 修正段长上限）----
// 总时长 30-45s ⇄ 220-330 字；语速基准 7.3 字/s（5 样本实测 6.74-7.35）。
// 🔴 单段上限 109→**101 字**（2026-10-23）：生成时长 = clamp(ceil(字数/7.3*1.08), 4, 15)，
//    101 字 ×1.08÷7.3 = 14.94 → 15s 刚好不撞上限；102 字 = 15.09 → 16s 被 clamp 到 15s，
//    该段净语速会被迫比别的段快 12%（10-21 seq3 p3 104 字实测 8.35 vs p2 7.43）。
//    旧值 109 与 +1s 固定余量时代配套，已作废。
// 规范只应有一处定义（skill §1 或 profile.scriptPolicy 逃生舱），校验器读取它，不自己发明。
const POLICY_SOURCE = profile.scriptPolicy ? `profile.${profileName}.scriptPolicy（覆盖 skill 默认）` : 'skill 默认（时长优先制）';
const POLICY = (() => {
  const def = { totalMin: 220, totalMax: 330, segMax: 101, rate: 7.3, videoSec: '30-45s' };
  const c = profile.scriptPolicy;
  if (!c || typeof c !== 'object') return def;
  return Object.assign({}, def, c);
})();
console.log(`口播规范来源: ${POLICY_SOURCE} → 总量 ${POLICY.totalMin}-${POLICY.totalMax} 字（${POLICY.videoSec}）/ 单段 ≤${POLICY.segMax} 字 / 语速 ${POLICY.rate} 字/s`);

const missProd = {}, missPick = {};
let schemaMismatch = 0;
entries.forEach((raw, i) => {
  const e = toStd(raw);
  const tag = `seq${raw.seq ?? i + 1} ${raw.date || ''}`;
  const fmtLabel = (raw.format || '').toLowerCase() === 'dialogue' ? '对话' : '口播';
  const key = k => k.split(' ')[0];

  for (const [k, label, std] of PROD_REQUIRED) {
    const hit = k === 'segments 或 script' ? (e.segments || e.script) : e[key(k)];
    if (hit === undefined || (Array.isArray(hit) && !hit.length)) {
      (missProd[key(k)] = missProd[key(k)] || []).push(tag);
      schemaMismatch++;
    }
  }
  for (const [k, label, std] of PICK_REQUIRED) {
    if (e[k] === undefined) { (missPick[k] = missPick[k] || []).push(tag); schemaMismatch++; }
  }

  // ---- 三线类型 line：每条必填，且必须是合法枚举（2026-10-09 晓君总指令）----
  {
    const line = normLine(raw.line);
    if (!line) {
      const guessed = contentTypeToLine(raw.content_type);
      if (guessed) {
        W(`${tag} 未标注 line（三线类型），按旧 content_type="${raw.content_type}" 兜底判定为「${CONTENT_LINES[guessed]}」——新计划必须显式写 line`);
      } else {
        E(`${tag} 缺 line 字段（三线类型：flow=流量型 / persona=人设型 / lead=获客型），每条视频必须对应某个类型`);
      }
    }
  }

  // ---- 标题 / 封面 ----
  if (e.title) {
    const t = cn(e.title);
    if (t < 8 || t > 18) E(`${tag} title ${t} 字，应在 8-18 字`);
  }
  if (e.cover_title) {
    if (!Array.isArray(e.cover_title) || e.cover_title.length !== 2) {
      E(`${tag} cover_title 必须是两行数组`);
    } else {
      e.cover_title.forEach((l, li) => {
        const c = cn(l);
        if (c < 5 || c > 12) E(`${tag} cover_title[${li}]「${l}」${c} 字，应在 5-12 字（封面会溢出或空荡）`);
        else if (c > 8) W(`${tag} cover_title[${li}] ${c} 字偏长，每行 5-8 字最均衡`);
      });
    }
  }

  // ---- 口播时长优先制：总量区间 + 单段上限（2026-10-11，不卡段数档位）----
  const segs = Array.isArray(e.segments) ? e.segments : null;
  if (segs && segs.length) {
    const total = segs.reduce((a, s) => a + cn(s), 0);
    const est = (total / POLICY.rate).toFixed(1);      // 实测语速 7.3 字/s
    if (total < POLICY.totalMin || total > POLICY.totalMax) {
      E(`${tag} ${fmtLabel} ${total} 字（${segs.length} 段，估算时长 ≈${est}s）不在 ${POLICY.totalMin}-${POLICY.totalMax} 字（${POLICY.videoSec}）区间`
        + '——不为凑字加废话、不为压字砍内容，按信息完整度重写');
    } else {
      console.log(`  ${tag} ${fmtLabel} ${total} 字 ✓ ${POLICY.totalMin}-${POLICY.totalMax}（≈${est}s）→ ${segs.length} 段`);
    }
    if (segs.length < 2) W(`${tag} 仅 ${segs.length} 段，30s 以上口播建议按语义分 2-4 段`);
    if (segs.length > 5) W(`${tag} ${segs.length} 段偏多，分段过碎影响段间一致性`);
    segs.forEach((s, si) => {
      const c = cn(s);
      if (c > POLICY.segMax) E(`${tag} 第${si + 1}段 ${c} 字 > ${POLICY.segMax}，单段上限 ${POLICY.segMax} 字（≈15s 安全区）`
        + ' —— 超了生成时会被 clamp 到 15s，该段语速被迫比别的段快 10%+（听感「这part赶」），请按语义拆段，别砍内容');
      else if (c < 25) W(`${tag} 第${si + 1}段仅 ${c} 字，分段过碎，口播会磕`);
    });
  }

  // ---- scene（model_generated 时是描述文本）----
  if (e.scene) {
    if (profile.sceneMode === 'model_generated') {
      if (/\.(jpe?g|png|webp|mov|mp4)$/i.test(e.scene)) {
        E(`${tag} profile 是 model_generated，scene 应写场景描述文本，不是文件名：${e.scene}`);
      } else if (cn(e.scene) < 6) {
        W(`${tag} scene 描述过短（${cn(e.scene)} 字），模型生成场景会不稳定`);
      }
    }
  }

  // ---- outfit_action 三要素 + 质感 + 禁饮用 ----
  if (e.outfit_action) {
    const oa = String(e.outfit_action);
    for (const t of ['【着装】', '【动作】', '【拍摄】']) if (!oa.includes(t)) E(`${tag} outfit_action 缺 ${t}`);
    const DRINK = ['喝水', '喝咖啡', '喝茶', '喝奶茶', '吃东西', '咀嚼', '饮用', '端杯喝'];
    const act = (oa.split('【动作】')[1] || '').split('【拍摄】')[0];
    for (const w of DRINK) {
      const idx = act.indexOf(w);
      if (idx >= 0 && !/不得|禁止|不要|不可/.test(act.slice(Math.max(0, idx - 4), idx + w.length + 2))) {
        E(`${tag} 【动作】含饮用/进食「${w}」——干扰口型，改「桌上可放杯具作道具，不得饮用」`);
      }
    }
    const FABRIC = ['精梳棉', '长绒棉', '纯棉', '羊毛', '羊绒', '真丝', '桑蚕丝', '醋酸', '天丝', '亚麻', '棉麻',
      '衬衫布', '针织', '斜纹', '珠地', '牛仔', '皮革', '呢料', '雪纺', '缎面', '莫代尔', '丝光棉', '垂感面料', '挺括面料'];
    const TAILOR = ['合身', '修身', '利落', '廓形', '微廓', '垂感', '挺括', '低饱和', '同色系', '撞色', '高级',
      '质感', '莫兰迪', '极简', '净版', '无褶皱', '垂坠', '剪裁', '版型', '配色'];
    const of = (oa.split('【着装】')[1] || '').split('【动作】')[0];
    if (!FABRIC.some(w => of.includes(w)) && !TAILOR.some(w => of.includes(w))) {
      E(`${tag} 【着装】缺质感描述（只写款式）——须补「面料 + 剪裁/配色」`);
    }
  }

  // ---- material 与 segment_materials 文件存在性 ----
  const materialDir = (profile.paths || {}).materialDir;
  const hasDir = materialDir && fs.existsSync(materialDir);
  for (const m of (Array.isArray(e.material) ? e.material : [])) {
    if (hasDir && !fs.existsSync(path.join(materialDir, norm(m).replace(/\//g, path.sep)))) {
      E(`${tag} material 文件不存在: ${m}`);
    }
  }
  for (const s of (Array.isArray(e.segment_materials) ? e.segment_materials : [])) {
    // 2026-10-04：视频插片上限 3s → 4s（落地 2026-09-29 口径「插片 1.5 倍速 + 3-4 秒」）。
    // 依据：条目 segment_materials 带 `speed: 1.5`，4s 素材按 1.5 倍速播 ≈2.67s 时间线，
    // 与旧「时间线 ≤3s」等价；图片仍 ≤1s。
    const max = s.type === 'image' ? 1 : s.type === 'video' ? 4 : null;
    if (max === null) E(`${tag} segment_materials.type 必须是 image 或 video，当前 "${s.type}"`);
    else if (s.seconds > max) E(`${tag} segment_materials segment${s.segment} seconds=${s.seconds} > ${max}（视频≤4s、图片≤1s）`);
    if (hasDir && s.file && !fs.existsSync(path.join(materialDir, norm(s.file).replace(/\//g, path.sep)))) {
      E(`${tag} segment_materials 素材不存在: ${s.file}`);
    }
    // 跨产品线顶替拦截（2026-09-21）
    // 🔴 2026-10-19 修：原来只取 lineOfEntry(e)，而 e 是 toStd() 之后的副本、不带 productLine，
    //    导致 myLine 恒为 null → 跨线拦截整条失效（实测 2026-10-22 私域线条目插内容线素材没被拦）。
    //    改为优先读原始 raw 上的 productLine，再回退 e / raw 的推断。
    const myLine = (raw && raw.productLine) || lineOfEntry(raw) || lineOfEntry(e);
    const mLine = s.file ? lineOfMaterial(s.file) : null;
    if (mLine && myLine && mLine !== myLine) {
      W(`${tag} 素材跨线：${s.file} 属「${LINE_NAME[mLine]}」，本条是「${LINE_NAME[myLine]}」——不许顶替该线证据；这条线没素材就不插`);
    } else if (!mLine && s.file) {
      W(`${tag} 素材归属未登记：${s.file} —— 先补进 plan.materialPolicy.lines 再用，避免串线`);
    }
  }
  // ---- 禁词扫描（口径红线落校验，不靠人记）----
  // 依据：项目 MEMORY §4 人设口径 + profile.forbiddenAssets（两处都要同步维护）
  const bodyText = [e.title, ...(e.cover_title || []), ...(e.segments || []), e.cta, e.angle_第一人称]
    .filter(Boolean).join('\n');
  const HARD_BANNED = [
    { re: /门店|店里/, why: '禁词（限定词，缩小适用面），改「客户 / 用户」' },
    { re: /淘房王/, why: '正确写法是「淘房网」' },
    { re: /10\s*年房地产|十年房地产/, why: '时间线口径禁用（只写 2010 创办淘房网、做了 15 年）' },
    { re: /200\s*万|30\s*岁出头/, why: '未确认收入数据，profile.forbiddenAssets 明令禁用' },
    { re: /(降低|省下|节省)[^。；]{0,8}人力成本|人力成本[^。；]{0,8}(降低|下降)\s*\d/, why: '未确认效果数据（官网口径是「节省 70% 人力」）' }
  ];
  const SOFT_BANNED = [
    { re: /AI销冠|私域运营|微信私域/, why: '品类冷词（09-20 实测最冷三行），正文优先「AI工具 / AI员工 / 获客 / 降本增效」' },
    { re: /便宜客源|低价客源|便宜流量|免费流量池/, why: '自造复合词，老板一看就懵（09-20 晓君总反馈「太深奥」）→ 改用日常说法（「老客户是现成的」「不用再花钱买流量」）' }
  ];
  for (const b of HARD_BANNED) if (b.re.test(bodyText)) E(`${tag} 命中禁用口径 ${b.re} —— ${b.why}`);
  for (const b of SOFT_BANNED) if (b.re.test(bodyText)) W(`${tag} 命中冷词 ${b.re} —— ${b.why}`);

  // ---- 文案风格（2026-09-21 晓君总反馈「AI 味太重」）：冒号 / 翻案腔 / 语气词 ----
  // 已发布条目跳过 —— 改不动了，别刷噪音（seq1 身上就留着这几项）
  if (raw.status !== 'published') {
    const colon = (bodyText.match(/[：:]/g) || []).length;
    if (colon) W(`${tag} 正文有 ${colon} 处冒号 —— 口播念出来像读稿，改成逗号或句号（只有引述别人原话才用冒号）`);

    const FANAN = [
      { re: /不是[^，。？！]{0,14}[，,](而)?是/, why: '「不是 A，是 B」翻案腔 → 直接写正面陈述（×「不是我们天天拍，是机器在干」✓「这活是一台机器在干」）' },
      { re: /(不在于|并非)[^，。？！]{0,14}[，,](而)?(在于|是)/, why: '翻案腔变体 → 直接下判断' },
      { re: /以为[^。？！]{0,24}其实/, why: '「你以为…其实」翻案腔 → 正面说' }
    ];
    for (const b of FANAN) if (b.re.test(bodyText)) W(`${tag} 疑似翻案腔 ${b.re} —— ${b.why}`);

    const TONE = (bodyText.match(/对吧|呢|啊|哈|其实|你看|说实话|你想想|你说是不/g) || []).length;
    if (TONE < 3) W(`${tag} 语气词只有 ${TONE} 处 —— 口语化不足（要求 3-5 处、接句尾），补「对吧 / 呢 / 啊 / 其实 / 你看」`);
  }

  // ---- 形态 format：solo / dialogue（2026-09-21 新增，晓君总要求内容分单人与双人）----
  const fmt = raw.format || 'solo';
  if (!['solo', 'dialogue'].includes(fmt)) {
    E(`${tag} format "${fmt}" 不合法，只能是 solo（单人口播）或 dialogue（双人对话）`);
  }
  if (fmt === 'dialogue') {
    if (!Array.isArray(raw.dialogue_lines) || !raw.dialogue_lines.length) {
      E(`${tag} format=dialogue 但没有 dialogue_lines（牧子琪的插话/附和台词要单列，否则生产端不知道谁说什么）`);
    }
    if (!raw.scene || !raw.outfit_action) {
      E(`${tag} format=dialogue 缺条目级 scene / outfit_action —— 双人同框的画面与着装与单人不同，必须按条覆盖`);
    }
    const partner = (profile.extra || {}).dialoguePartner;
    if (!partner) W(`${tag} 用了 dialogue，但 profile.extra.dialoguePartner 未定义合作出镜形象`);
    // 🔴 2026-10-23：真正决定生成时长的是**交织后的 spoken**，不是 segments 原文 ——
    //    dialogue 条目常把搭档台词单列在 dialogue_lines（按 seg 归段），生产端 _setup.js 会把它追加到该段末尾。
    //    只校验 segments 原文会漏掉这一层：10-21 seq3 p3 原文 84 字过关，交织后 104 字撞 15s 上限，
    //    净语速被迫比别的段快 12.4%（晓君总反馈「不同 part 语速不太一样」的根因就在这）。
    //    这里只报「原文过关、交织后超限」的增量情况（原文本身就超的，上面通用检查已报，不重复刷屏）。
    {
      const embedded = (raw.segments || []).some(s => /（牧子琪|\(牧子琪/.test(String(s)));
      const gatePass = String(((plan.dialogueGate || {}).status) || '') === 'pass';
      const lines = Array.isArray(raw.dialogue_lines) ? raw.dialogue_lines : [];
      if (!embedded && gatePass && lines.length && Array.isArray(raw.segments)) {
        raw.segments.forEach((s, si) => {
          const n = si + 1;
          const mine = lines.filter(x => Number(x.seg) === n);
          if (!mine.length) return;
          const before = cn(s);
          const merged = String(s) + mine.map(x => String(x.text || '').trim()).join('');
          const after = cn(merged);
          if (before <= POLICY.segMax && after > POLICY.segMax) {
            E(`${tag} 第${n}段交织后 ${after} 字（原文 ${before} + 牧子琪插话 ${after - before}）> ${POLICY.segMax} —— `
              + '生成会被 clamp 到 15s，该段语速被迫比别的段快 10%+（听感「这part赶」）；把插话挪到别的段，或按语义拆段');
          }
        });
      }
    }
  }

  // ---- CTA 钩子：话术必须真的落在最后一段（避免只写在字段里、正文没落）----
  // 🔴 2026-10-09 晓君总指令【口播意愿优先】：ctaType 标为「口播意愿 / 原声 / 本人意愿」的条目，
  //    收口以本人真实意愿为准（可不在词池内）→ 跳过词池校验；「落在末段正文」仍照校验。
  const ctaTypeStr = String(e.ctaType || '');
  const ctaByVoice = /口播意愿|原声|本人意愿/.test(ctaTypeStr);
  if (/钩子|资料|口播意愿|原声|本人意愿/.test(ctaTypeStr)) {
    if (!ctaByVoice) {
      const poolRaw = e.ctaKeyword || (profile.extra || {}).ctaHookKeyword || '111';
      const pool = (Array.isArray(poolRaw) ? poolRaw : [poolRaw]).map(String).filter(Boolean);
      if (!pool.some(k => String(e.cta || '').includes(k))) {
        E(`${tag} ctaType=${ctaTypeStr} 但 cta 话术里没有筛选关键词（候选：${pool.join(' / ')}）`);
      }
    }
    const last = Array.isArray(e.segments) ? String(e.segments[e.segments.length - 1] || '') : '';
    const core = String(e.cta || '').replace(/[。！？?！\s]/g, '').slice(0, 8);
    if (last && core && !last.replace(/[。！？?！\s]/g, '').includes(core)) {
      E(`${tag} cta 话术没落在最后一段正文里（正文与 cta 字段不一致，生产端会读字段、观众看不到）`);
    }
  }

});

if (schemaMismatch) {
  const fmt = (title, obj) => Object.entries(obj)
    .map(([k, v]) => `  · ${k} 缺失 × ${v.length} 条（${v.slice(0, 3).join(', ')}${v.length > 3 ? ' …' : ''}）`).join('\n');
  E(`字段缺失导致生产信息不完整（共 ${schemaMismatch} 处）：`);
  if (Object.keys(missProd).length) errors.push('【生产必需】\n' + fmt('', missProd));
  if (Object.keys(missPick).length) warns.push('【选题管理字段缺失，不影响生成但影响复盘】\n' + fmt('', missPick));
}

// ============ 3. 七日编排比例（三线框架，2026-10-09 起）============
// 每条已必须标 line（flow/persona/lead）。profile.weeklyLayout 写成三线配比，
// 例如「4 lead + 2 persona + 1 flow」。这里按 line 统计、比对，并做穿插检查。
// 2026-10-19：plan 级 weeklyLayout 优先于 profile 默认值 —— 单周换配比（如本周人设换产品）不必改 profile。
const layout = (plan && plan.weeklyLayout) || (profile.extra || {}).weeklyLayout || '';
const classify = t => {
  const s = String(t || '');
  if (/案例/.test(s)) return '案例';
  if (/人设/.test(s)) return '人设';
  if (/产品/.test(s)) return '产品';
  if (/流量|认知/.test(s)) return '流量';
  if (/痛点/.test(s)) return '痛点';
  return '其他';
};
const expected = {};
for (const m of layout.matchAll(/(\d+)\s*([^+0-9]+)/g)) {
  const kw = m[2].trim();
  const cls = classify(kw);
  if (cls !== '其他') expected[cls] = (expected[cls] || 0) + parseInt(m[1], 10);
}
// 三线配比（line 维度）——weeklyLayout 若写成 flow/persona/lead/product 或 流量型/人设型/获客型/产品型
const expectedLine = {};
for (const m of layout.matchAll(/(\d+)\s*(flow|persona|lead|product|流量型?|人设型?|获客型?|产品型?)/g)) {
  const l = normLine(m[2]);
  if (l) expectedLine[l] = (expectedLine[l] || 0) + parseInt(m[1], 10);
}
if (Object.keys(expected).length) {
  const actual = {};
  const seqCls = [];
  entries.forEach(e => { const c = classify(toStd(e).content_type); actual[c] = (actual[c] || 0) + 1; seqCls.push(c); });
  const diff = [];
  for (const k of new Set([...Object.keys(expected), ...Object.keys(actual)])) {
    if ((expected[k] || 0) !== (actual[k] || 0)) diff.push(`${k} 应 ${expected[k] || 0} 实 ${actual[k] || 0}`);
  }
  if (diff.length) W(`七日编排比例偏离 profile.weeklyLayout（${layout}）：${diff.join('；')}`);
  else console.log(`编排比例 ✓ ${layout}`);
  // 连排同类
  for (let i = 1; i < seqCls.length; i++) {
    if (seqCls[i] === seqCls[i - 1]) W(`seq${i + 1} 与 seq${i} 连着同类型（${seqCls[i]}），编排要求穿插`);
  }
}
if (Object.keys(expectedLine).length) {
  const actualLine = {};
  const seqLine = [];
  entries.forEach(e => { const l = normLine(e.line) || contentTypeToLine(toStd(e).content_type); if (l) { actualLine[l] = (actualLine[l] || 0) + 1; } seqLine.push(l); });
  const diffL = [];
  for (const k of new Set([...Object.keys(expectedLine), ...Object.keys(actualLine)])) {
    if ((expectedLine[k] || 0) !== (actualLine[k] || 0)) diffL.push(`${CONTENT_LINES[k]} 应 ${expectedLine[k] || 0} 实 ${actualLine[k] || 0}`);
  }
  if (diffL.length) W(`三线配比偏离（${layout}）：${diffL.join('；')}`);
  else console.log(`三线配比 ✓ ${Object.entries(expectedLine).map(([k, v]) => `${CONTENT_LINES[k]}${v}`).join(' / ')}`);
  for (let i = 1; i < seqLine.length; i++) {
    if (seqLine[i] && seqLine[i] === seqLine[i - 1]) W(`seq${i + 1} 与 seq${i} 连着同一条线（${CONTENT_LINES[seqLine[i]]}），三线要求穿插`);
  }
}

// ============ 3.5 场景轮换（2026-09-25 新增，晓君总问「为什么每次场景着装都一样」）============
// 依据：晓君总短视频文案与视频生产规范.md §23「场景同周 7 天尽量轮换不重复」
//     + brand-rules.md「必须匹配当前季节和场景着装」
// 口径：一条之内 4 段必须一致（段间一致性，靠 part2+ 传 part1 马赛克参考帧）；
//       一条之间必须轮换 —— 段间一致 ≠ 全周一致。
{
  const pd = plan.productionDefaults || {};
  const effScene = e => String((e && e.scene) || pd.scene || '');
  const effOutfit = e => String((e && e.outfit_action) || pd.outfit_action || '');
  const key = s => s.slice(0, 24);
  const scenes = entries.map(e => key(effScene(e))).filter(Boolean);
  const uniq = [...new Set(scenes)];
  const need = Math.min(4, entries.length);
  if (uniq.length < need) {
    W(`【R 场景轮换】本周 ${entries.length} 条只有 ${uniq.length} 种场景（要求 ≥${need}）——` +
      `依据规范 §23「场景同周 7 天尽量轮换不重复」。轮换表 video-copywriter/references/scene-rotation-xiaojunzong.md`);
  }
  for (let i = 1; i < entries.length; i++) {
    const a = entries[i - 1], b = entries[i];
    if (effScene(a) && effScene(a) === effScene(b)) W(`【R 场景轮换】seq${i} 与 seq${i + 1} 场景完全相同，相邻两条必须换景`);
    if (effOutfit(a) && effOutfit(a) === effOutfit(b)) W(`【R 场景轮换】seq${i} 与 seq${i + 1} 着装完全相同，相邻两条必须换装`);
  }
  // 顶层共用告警：条目级覆盖过少说明 productionDefaults 被当成「全周一套」
  const entryLevel = entries.filter(e => e.scene).length;
  if (entryLevel < Math.ceil(entries.length / 2)) {
    W(`【R 场景轮换】只有 ${entryLevel}/${entries.length} 条写了条目级 scene，其余回落 productionDefaults —— 顶层只是最后回落，不是全周共用一套`);
  }
}

// ============ 4. 去重：与已发内容/历史内容包比对 ============
const cwd = process.cwd();
const logCandidates = [path.join(cwd, 'output/published_log.json')];
const pkgDir = (profile.paths || {}).contentPackageDir;
const hist = [];
for (const f of logCandidates) {
  if (!fs.existsSync(f)) continue;
  try {
    const j = JSON.parse(fs.readFileSync(f, 'utf8'));
    const arr = Array.isArray(j) ? j : (j.records || j.entries || []);
    arr.forEach(r => hist.push({ src: 'published_log', date: r.date, title: r.note || r.title || '' }));
  } catch (e) { /* ignore */ }
}
if (pkgDir && fs.existsSync(pkgDir)) {
  for (const f of fs.readdirSync(pkgDir)) {
    if (!f.endsWith('.json') || f.endsWith('_segments.json')) continue;
    try {
      const j = JSON.parse(fs.readFileSync(path.join(pkgDir, f), 'utf8'));
      hist.push({ src: '内容包/' + f, date: j.date, title: j.title || '', head: String(j.script || '').replace(/\s/g, '').slice(0, 12) });
    } catch (e) { /* ignore */ }
  }
}
let dupCount = 0;
entries.forEach((raw, i) => {
  if (raw.status === 'published') return;      // 已发布的历史条目不再参与去重（它自己就是历史）
  const e = toStd(raw);
  const head = (Array.isArray(e.segments) && e.segments[0])
    ? String(e.segments[0]).replace(/\s/g, '').slice(0, 10) : '';
  for (const h of hist) {
    if (h.date && e.date && new Date(e.date) <= new Date(h.date)) {
      if (e.title && h.title && String(h.title).includes(String(e.title).slice(0, 6))) {
        W(`seq${i + 1} 标题与 ${h.src}(${h.date}) 高度相似，确认不是重复选题`);
        dupCount++;
      }
      if (head && h.head && head === h.head) { E(`seq${i + 1} 开场前 10 字与 ${h.src} 重复：${head}`); dupCount++; }
    }
  }
});
if (hist.length) console.log(`去重比对 ✓ 历史 ${hist.length} 条来源`);
else W('没有可比对的历史记录（published_log / 内容包目录为空），去重这一项失去依据');

// ============ 5. schema 对照报告 ============
if (schemaReport) {
  console.log('\n──────────────── schema 对照 ────────────────');
  const std = ['weekday', 'date', 'column', 'content_type', 'line', 'hot_signal', 'angle_第一人称',
    'product_link', 'title_draft', 'cta', 'function_no', 'scene', 'outfit_action', 'material'];
  const used = new Set();
  entries.forEach(e => Object.keys(e).forEach(k => used.add(k)));
  console.log('weekly-plan.md §3 规定字段 → 本计划是否具备：');
  for (const k of std) {
    const alt = { title_draft: 'title', cta: 'ctaType', hot_signal: 'materialSource', angle_第一人称: 'opening' }[k];
    const ok = used.has(k) ? '✓' : (alt && used.has(alt) ? `△ 以「${alt}」代替（语义不等价）` : '✗ 完全缺失');
    console.log(`  ${k.padEnd(14)} ${ok}`);
  }
  console.log('本计划自创字段（skill 未定义）：');
  for (const k of used) if (!std.includes(k)) console.log(`  + ${k}`);
}

// ============ 输出 ============
console.log('');
if (warns.length) { console.log(`WARN × ${warns.length}`); warns.forEach(w => console.log('  ⚠ ' + w)); }
if (errors.length) {
  console.log(`\nERROR × ${errors.length} —— 修完再交给生产环节`);
  errors.forEach(e => console.log('  ✗ ' + e));
  process.exit(1);
}
console.log('✅ 周计划校验通过');
