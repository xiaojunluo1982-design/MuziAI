#!/usr/bin/env node
/**
 * 通用内容包 JSON 校验（账号无关，按 profile 适配）。
 *
 * 用法：
 *   node validate_package.js "<内容包.json>" --profile muziqi
 *   node validate_package.js --list-profiles
 *
 * profile 决定：必填字段、路径（留空则跳过文件存在性检查）、功能主线是否必填素材。
 * 有 ERROR 时退出码 1（必须修完才能交给生产环节）；只有 WARN 时退出码 0。
 */
const fs = require('fs');
const path = require('path');

const SKILL_DIR = path.resolve(__dirname, '..');
const PROFILE_DIR = path.join(SKILL_DIR, 'profiles');

const argv = process.argv.slice(2);

// ---------- profile 列表 ----------
if (argv.includes('--list-profiles')) {
  const list = fs.readdirSync(PROFILE_DIR)
    .filter(f => f.endsWith('.json') && !f.startsWith('_'))
    .map(f => f.replace(/\.json$/, ''));
  console.log('可用 profile:');
  list.forEach(n => {
    const p = JSON.parse(fs.readFileSync(path.join(PROFILE_DIR, n + '.json'), 'utf8'));
    console.log(`  ${n.padEnd(14)} ${p.displayName || ''}`);
  });
  process.exit(0);
}

const file = argv.find(a => !a.startsWith('--'));
const pIdx = argv.indexOf('--profile');
const profileName = pIdx >= 0 ? argv[pIdx + 1] : (process.env.VW_PROFILE || null);

if (!file) { console.error('用法: node validate_package.js <内容包.json> --profile <账号>'); process.exit(2); }
if (!profileName) { console.error('需要 --profile <账号>，可用 --list-profiles 查看'); process.exit(2); }

const profilePath = path.join(PROFILE_DIR, profileName + '.json');
if (!fs.existsSync(profilePath)) {
  console.error(`profile 不存在: ${profileName}\n可用: ${fs.readdirSync(PROFILE_DIR).filter(f => f.endsWith('.json')).join(', ')}`);
  process.exit(2);
}

const profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
const P = profile.paths || {};
const pkg = JSON.parse(fs.readFileSync(file, 'utf8'));

console.log(`profile: ${profile.displayName || profileName}`);

const errors = [];
const warns = [];
const E = m => errors.push(m);
const W = m => warns.push(m);

const cn = s => (s || '').replace(/\s/g, '').length;
// 素材名可能混用 / 或 \，统一成本地分隔符再拼
const under = (dir, rel) => path.join(dir, String(rel).replace(/[\\/]+/g, path.sep));
const norm = a => a.map(s => String(s).replace(/[\\/]+/g, '/')).sort().join('|');
const hasDir = d => d && fs.existsSync(d);

// ---------- 1. 必填字段（按 profile） ----------
for (const k of (profile.requiredFields || [])) {
  if (pkg[k] === undefined || pkg[k] === null) E(`缺必填字段: ${k}（profile ${profileName} 要求）`);
}
// 废弃字段
for (const old of ['outfit', 'shooting_method']) {
  if (pkg[old] !== undefined) E(`使用了已废弃字段 "${old}"，请合并为 outfit_action 三要素`);
}

// ---------- 2. 口播时长优先制（2026-10-11 晓君总指令，旧「字数三档」作废） ----------
// 总时长 30-45s ⇄ 220-330 字；语速基准 7.3 字/s（实测）；profile.scriptPolicy 可作逃生舱覆盖
const n = cn(pkg.script);
const POLICY = Object.assign({ totalMin: 220, totalMax: 330, rate: 7.3, videoSec: '30-45s' }, profile.scriptPolicy || {});
const est = (n / POLICY.rate).toFixed(1);
if (n < POLICY.totalMin || n > POLICY.totalMax) {
  E(`script 字数 ${n}（估算 ≈${est}s）不在 ${POLICY.totalMin}-${POLICY.totalMax}（${POLICY.videoSec}）区间——不为凑字加废话、不为压字砍内容`);
} else {
  console.log(`script ${n} 字 ✓ ${POLICY.totalMin}-${POLICY.totalMax}（≈${est}s，${POLICY.videoSec}）`);
}

// ---------- 3. 标题 / 封面 ----------
const tl = cn(pkg.title);
if (tl < 8 || tl > 18) E(`title ${tl} 字，应在 8-18 字`);
if (!Array.isArray(pkg.cover_title) || pkg.cover_title.length !== 2) {
  E('cover_title 必须是两行数组');
} else {
  pkg.cover_title.forEach((l, i) => {
    const c = cn(l);
    if (c < 5 || c > 12) E(`cover_title[${i}] ${c} 字，应在 5-12 字`);
    else if (c > 8) W(`cover_title[${i}] ${c} 字偏长，制封面时每行 5-8 字最均衡`);
  });
}

// ---------- 3.5 开场钩子（2026-09-03 新增：禁自报家门开头 + 禁连日同款开场）----------
// 2026-09-04 通用化：通用层只保留「与账号无关」的自报家门句式；
// 账号专属的身份词一律从 profile.identity 读，换角色只改 profile，不动脚本。
const ID = profile.identity || {};
const GENERIC_SELF_INTRO = [/^大家好[，,]?我是/, /^Hi[，,]?我是/i];
const SELF_INTRO = [
  ...(ID.selfIntroPatterns || []).map(s => new RegExp(s)),
  ...GENERIC_SELF_INTRO,
];
const scriptTxt = String(pkg.script || '').replace(/\s/g, '');
if (!scriptTxt) {
  E('script 为空，无法校验开场');
} else {
  const hitIntro = SELF_INTRO.find(re => re.test(scriptTxt));
  if (hitIntro) {
    E(`开场是自报家门（命中 ${hitIntro}）：前 3 秒必须给"跟观众有关"的信息（痛点/反常识/悬念/具体场景），身份句挪到第 2-3 句或结尾落款`);
  }
  // 身份仍须交代，只是换位置；是否强制由 profile.identity.requireMention 决定（真人号可关掉）
  if (ID.requireMention !== false) {
    const mention = ID.mentionPattern
      ? new RegExp(ID.mentionPattern)
      : /我是.{0,12}AI|我这个AI|AI/;
    if (!mention.test(scriptTxt)) {
      W(`全篇没有身份交代（${ID.name || '该账号'}），观众得知道说话的是谁`);
    }
  }
  // 与同目录历史内容包比对开场 10 字
  const pkgDir = path.dirname(path.resolve(file));
  const head10 = scriptTxt.slice(0, 10);
  const dupes = [];
  if (fs.existsSync(pkgDir)) {
    for (const f of fs.readdirSync(pkgDir)) {
      if (!f.endsWith('.json') || f.endsWith('_segments.json') || f.endsWith('.bak')) continue;
      const fp = path.join(pkgDir, f);
      if (path.resolve(fp) === path.resolve(file)) continue;
      let o; try { o = JSON.parse(fs.readFileSync(fp, 'utf8')); } catch (e) { continue; }
      const os = String(o.script || '').replace(/\s/g, '');
      if (os.slice(0, 10) && os.slice(0, 10) === head10) dupes.push(f);
    }
  }
  if (dupes.length) {
    E(`开场前 10 字「${head10}」与历史内容包重复: ${dupes.join(', ')}（连日同款开场会让老粉免疫，必须换钩子）`);
  }
}
const angTxt = String(pkg.angle_第一人称 || '').replace(/\s/g, '');
if (angTxt && SELF_INTRO.find(re => re.test(angTxt))) {
  E('angle_第一人称 以自报家门开头，开场必须先给观众相关的钩子');
}

// ---------- 4. 朋友圈 / 小红书 ----------
const mc = cn(pkg.moments_copy);
if (mc < 100 || mc > 220) E(`moments_copy ${mc} 字，应在 100-220 字`);

const xhs = pkg.xiaohongshu || {};
if (!Array.isArray(xhs.title_options) || xhs.title_options.length !== 3) {
  E('xiaohongshu.title_options 应为 3 个');
} else {
  xhs.title_options.forEach((t, i) => {
    if (cn(t) > 20) E(`xiaohongshu.title_options[${i}] ${cn(t)} 字 > 20，小红书标题会截断`);
  });
}
if (!Array.isArray(xhs.hashtags) || xhs.hashtags.length < 5 || xhs.hashtags.length > 8) {
  E(`xiaohongshu.hashtags 应 5-8 个，当前 ${(xhs.hashtags || []).length} 个`);
} else {
  xhs.hashtags.forEach(h => { if (String(h).includes('#')) E(`hashtag "${h}" 不应带 #`); });
}

// ---------- 5. scene（目录已配置才查存在性） ----------
// 场景生成模式（2026-09-16 新增）：profile.sceneMode === 'model_generated' 时，
// scene 字段是「写进 prompt 的文字场景描述」，不是文件名，跳过文件存在性检查。
// （video-pipeline 的 xiaojunzong profile 已切到 model_generated，本脚本需对齐，否则每次误报。）
if (pkg.scene) {
  if (profile.sceneMode === 'model_generated') {
    console.log(`scene: ${pkg.scene}（模型生成场景，跳过文件检查）`);
  } else if (hasDir(P.sceneDir)) {
    const p = path.join(P.sceneDir, pkg.scene);
    if (!fs.existsSync(p)) E(`scene 文件不存在: ${p}`);
    else console.log(`scene ✓ ${pkg.scene}`);
  } else if (P.sceneDir === '') {
    console.log(`scene: ${pkg.scene}（profile 未配置 sceneDir，跳过文件检查）`);
  } else {
    E(`profile 配置的 sceneDir 不存在: ${P.sceneDir}`);
  }
}

// ---------- 6. outfit_action 三要素（出镜类） ----------
if (pkg.outfit_action !== undefined) {
  const oa = pkg.outfit_action || '';
  for (const tag of ['【着装】', '【动作】', '【拍摄】']) {
    if (!oa.includes(tag)) E(`outfit_action 缺 ${tag}`);
  }
  const DRINK = ['喝水', '喝咖啡', '喝茶', '喝奶茶', '吃东西', '咀嚼', '饮用', '端杯喝'];
  const actionPart = (oa.split('【动作】')[1] || '').split('【拍摄】')[0];
  for (const w of DRINK) {
    let idx = actionPart.indexOf(w);
    while (idx >= 0) {
      const around = actionPart.slice(Math.max(0, idx - 4), idx + w.length + 2);
      if (!/不得|禁止|不要|不可/.test(around)) {
        E(`【动作】含饮用/进食动作「${w}」——会干扰口型与音频。改成「桌上可放杯具作道具，不得饮用」`);
      }
      idx = actionPart.indexOf(w, idx + 1);
    }
  }
  // 质感铁律（2026-09-06 晓君总定）：着装必须有质感、有高级感、时尚
  // 只写款式（如「短袖T恤+休闲裤」）出不来高级感，须补「面料 + 剪裁/配色」
  const outfitPart = (oa.split('【着装】')[1] || '').split('【动作】')[0];
  const FABRIC = ['精梳棉', '长绒棉', '纯棉', '羊毛', '羊绒', '真丝', '桑蚕丝', '醋酸', '天丝',
    '亚麻', '棉麻', '衬衫布', '针织', '斜纹', '珠地', '牛仔', '皮革', '呢料', '雪纺', '缎面',
    '莫代尔', '丝光棉', '垂感面料', '挺括面料'];
  const TAILOR = ['合身', '修身', '利落', '廓形', '微廓', '垂感', '挺括', '低饱和', '同色系',
    '撞色', '高级', '质感', '莫兰迪', '极简', '净版', '无褶皱', '垂坠', '剪裁', '版型', '配色'];
  const hitF = FABRIC.filter(w => outfitPart.includes(w));
  const hitT = TAILOR.filter(w => outfitPart.includes(w));
  if (!hitF.length && !hitT.length) {
    E('【着装】缺质感描述（只写了款式）——铁律要求「有质感、高级感、时尚」，须补「面料 + 剪裁/配色」，如「长绒棉珠地面料，合身利落剪裁、低饱和米杏同色系」');
  } else if (!hitF.length) {
    W('【着装】缺面料词（精梳棉/真丝/羊毛混纺/天丝等），质感不足，建议补');
  } else if (!hitT.length) {
    W('【着装】缺剪裁或配色词（合身利落/垂感/低饱和/同色系等），建议补');
  }
} else if ((profile.requiredFields || []).includes('outfit_action')) {
  E('缺 outfit_action');
}

// ---------- 7. material 一致性 ----------
const mats = pkg.material || [];
const rvMats = (pkg.review_notes || {}).materials || [];
if (mats.length && rvMats.length && norm(mats) !== norm(rvMats)) {
  E('material 与 review_notes.materials 不一致');
}
const isFuncLine = profile.functionLineRequired &&
  new RegExp(profile.functionLinePattern || '$^').test(
    [pkg.column, pkg.content_type, pkg.style].filter(Boolean).join(' '));
if (isFuncLine && mats.length === 0) {
  E('功能主线类 material 必填（禁止无素材空讲），按账号的素材映射表选 2-3 个');
} else if (isFuncLine && mats.length === 1) {
  W('功能主线类只有 1 个素材——人设定了每条尽量全面（2-3 个），建议再补 1 个');
}
if (mats.length) {
  if (hasDir(P.materialDir)) {
    for (const m of mats) {
      if (!fs.existsSync(under(P.materialDir, m))) E(`素材文件不存在: ${under(P.materialDir, m)}`);
    }
  } else if (P.materialDir === '') {
    W('profile 未配置 materialDir，跳过素材文件存在性检查');
  } else {
    E(`profile 配置的 materialDir 不存在: ${P.materialDir}`);
  }
  console.log(`material ✓ ${mats.length} 个`);
}

// ---------- 8. segment_materials ----------
const segs = pkg.segment_materials || [];
const segments = hit ? hit[2] : 0;
for (const s of segs) {
  if (segments && (s.segment < 1 || s.segment > segments)) {
    E(`segment_materials.segment=${s.segment} 超出分段范围 1-${segments}`);
  }
  const max = s.type === 'image' ? 1 : s.type === 'video' ? 3 : null;
  if (max === null) E(`segment_materials.type 必须是 image 或 video，当前 "${s.type}"`);
  else if (s.seconds > max) {
    E(`segment ${s.segment} (${s.type}) seconds=${s.seconds} > ${max}，硬约束：视频≤3s、图片≤1s`);
  }
  if (hasDir(P.materialDir) && !fs.existsSync(under(P.materialDir, s.file || ''))) {
    E(`segment ${s.segment} 素材文件不存在: ${s.file}`);
  }
}
if (segs.length) console.log(`segment_materials ✓ ${segs.length} 条`);
if (isFuncLine && segs.length === 0) {
  W('功能主线类建议填 segment_materials，在写文案时就指定「第几段用哪个素材」');
}

// ---------- 9. 合规 ----------
const rn = pkg.review_notes || {};
if (rn.mentions_price === true && rn.publish_ready !== false) {
  E('涉及价格但未确认：mentions_price=true 时 publish_ready 必须为 false');
}
if (rn.mentions_customer_name === true) W('涉及客户名称，发布前需确认已获授权');
if (rn.mentions_specific_data === true) W('涉及具体数据，发布前需确认已获授权');

// ---------- 10. platforms ----------
if (pkg.platforms && pkg.platforms.length !== 4) {
  W(`platforms 通常为 ["抖音","视频号","小红书","朋友圈"]，当前 ${pkg.platforms.length} 个`);
}

// ---------- 11. 语气人设（按 profile 可选，活泼可爱性格） ----------
if (Array.isArray(profile.toneParticles) && profile.toneParticles.length && pkg.script) {
  const scriptText = typeof pkg.script === 'string' ? pkg.script : JSON.stringify(pkg.script);
  const toneHits = profile.toneParticles.filter(p => scriptText.includes(p));
  if (toneHits.length === 0) {
    W('口播全篇零语气词——人设是活泼可爱，建议自然穿插「对吧/是呀/呢/哈哈」等 3-6 处（不拦发布，下次注意）');
  } else {
    console.log(`语气词 ✓ ${toneHits.join('、')}`);
  }
}

// ---------- 输出 ----------
console.log('');
if (warns.length) {
  console.log(`WARN × ${warns.length}`);
  warns.forEach(w => console.log('  ⚠ ' + w));
}
if (errors.length) {
  console.log(`ERROR × ${errors.length} —— 修完再交给生产环节`);
  errors.forEach(e => console.log('  ✗ ' + e));
  process.exit(1);
}
console.log('✅ 内容包校验通过');
